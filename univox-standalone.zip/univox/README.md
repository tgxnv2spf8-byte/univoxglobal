# UNIVOX

Connect, learn, and explore with students worldwide. A React + Vite app for live
lessons, group chats, journal articles, and educational programs.

This project is fully standalone — it no longer depends on Base44. It runs on:

- **[Vite](https://vitejs.dev/)** + React 18 for the frontend
- **[Supabase](https://supabase.com/)** for auth, database (Postgres), and file storage
- **Vercel serverless functions** (`/api`) for the two things that need a server-side
  secret: AI requests and admin user deletion

## 1. Set up Supabase

1. Create a free project at [supabase.com](https://supabase.com).
2. In **SQL Editor**, run the contents of [`supabase/schema.sql`](./supabase/schema.sql).
   This creates all tables, row-level-security policies, and the `uploads` storage bucket.
3. In **Authentication → Providers**, enable Email, and enable Google if you want the
   "Continue with Google" button to work (add your OAuth client ID/secret there).
4. In **Authentication → Email Templates**, the sign-up flow in this app expects a
   6-digit **OTP code** rather than a magic link — edit the "Confirm signup" template
   to include `{{ .Token }}` instead of the default confirmation link.
5. Grab your project's **URL** and **anon public key** from **Project Settings → API**.
   You'll also want the **service_role key** from the same page (server-side only,
   never exposed to the browser).

## 2. Configure environment variables

Copy `.env.example` to `.env` and fill in:

```bash
VITE_SUPABASE_URL=...
VITE_SUPABASE_ANON_KEY=...
SUPABASE_SERVICE_ROLE_KEY=...
ANTHROPIC_API_KEY=...
```

`ANTHROPIC_API_KEY` powers the AI tutor, placement test, and journal recommendations
(`/api/invoke-llm`) — get one at [console.anthropic.com](https://console.anthropic.com).
Swap the provider in `api/invoke-llm.js` if you'd rather use a different one.

## 3. Run locally

```bash
npm install
npm run dev
```

## 4. Deploy to Vercel

1. Push this repo to GitHub/GitLab/Bitbucket and import it in Vercel, **or** run
   `vercel` from this directory.
2. Vercel auto-detects the Vite build (`npm run build` → `dist/`) and the
   `/api` serverless functions.
3. Add the same environment variables from step 2 in **Project Settings → Environment
   Variables**. `VITE_*` variables must be set before the build runs, since Vite
   inlines them at build time.
4. Deploy. `vercel.json` handles SPA client-side routing so refreshing on any page
   (e.g. `/profile`) works correctly.

## Making your own account an owner

`src/lib/roles.js` lists `OWNER_EMAILS` — sign up with one of those addresses (or
edit the file) and the app automatically grants the `owner` role on login, unlocking
the owner panel.

## Project structure

- `src/pages/` — one file per route (see `src/App.jsx` for the router)
- `src/components/` — shared and page-specific UI, including shadcn/ui primitives in
  `src/components/ui/`
- `src/api/base44Client.js` — the data-access layer. Every page calls
  `base44.entities.*` / `base44.auth.*` / `base44.integrations.*`; this file is where
  those calls talk to Supabase
- `supabase/schema.sql` — full database schema and RLS policies
- `api/` — Vercel serverless functions (AI proxy, admin user deletion)

## Known follow-ups

- The RLS policies in `supabase/schema.sql` are a best-effort translation of the
  original access rules. Review them against your actual product requirements
  before launch, especially for `badges`, `certificates`, `lessons`, and
  `timeline_events`, which had no explicit rules in the source project.
- Stripe fields exist on the `programs` table (`stripe_product_id`, etc.) but the
  checkout flow itself isn't wired up — see `src/lib/payments.js`.

// Vercel serverless function: POST /api/admin-delete-user
// Replaces base44.entities.User.delete(id). Deleting an auth user requires
// Supabase's service-role key, which must never be exposed to the browser,
// so this runs server-side and re-checks that the caller is an admin.

import { createClient } from '@supabase/supabase-js';

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const supabaseUrl = process.env.VITE_SUPABASE_URL || process.env.SUPABASE_URL;
  const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!supabaseUrl || !serviceRoleKey) {
    return res.status(500).json({ error: 'Supabase service-role credentials are not configured on the server' });
  }

  const { id } = req.body || {};
  if (!id) {
    return res.status(400).json({ error: 'A user "id" is required' });
  }

  const authHeader = req.headers.authorization || '';
  const callerToken = authHeader.replace(/^Bearer\s+/i, '');
  if (!callerToken) {
    return res.status(401).json({ error: 'Missing Authorization header' });
  }

  const admin = createClient(supabaseUrl, serviceRoleKey);

  // Verify the caller is who they say they are, and that they're an admin.
  const { data: callerData, error: callerError } = await admin.auth.getUser(callerToken);
  if (callerError || !callerData?.user) {
    return res.status(401).json({ error: 'Invalid session' });
  }

  const { data: callerProfile } = await admin
    .from('profiles')
    .select('role, roles')
    .eq('id', callerData.user.id)
    .maybeSingle();

  const isAdmin = callerProfile?.role === 'admin' || (callerProfile?.roles || []).includes('owner');
  if (!isAdmin) {
    return res.status(403).json({ error: 'Admin privileges required' });
  }

  const { error: deleteError } = await admin.auth.admin.deleteUser(id);
  if (deleteError) {
    return res.status(500).json({ error: deleteError.message });
  }

  return res.status(200).json({ success: true });
}

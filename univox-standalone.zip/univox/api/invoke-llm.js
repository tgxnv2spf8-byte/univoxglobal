// Vercel serverless function: POST /api/invoke-llm
// Replaces base44.integrations.Core.InvokeLLM. Keeps the AI provider's API key
// server-side — it must never be shipped to the browser.
//
// Requires the ANTHROPIC_API_KEY environment variable to be set in your
// Vercel project settings (https://console.anthropic.com/settings/keys).

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ error: 'ANTHROPIC_API_KEY is not configured on the server' });
  }

  const { prompt, response_json_schema: schema } = req.body || {};
  if (!prompt || typeof prompt !== 'string') {
    return res.status(400).json({ error: 'A "prompt" string is required' });
  }

  const finalPrompt = schema
    ? `${prompt}\n\nRespond with ONLY valid JSON (no markdown fences, no commentary) matching this JSON schema:\n${JSON.stringify(schema)}`
    : prompt;

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-6',
        max_tokens: 2048,
        messages: [{ role: 'user', content: finalPrompt }],
      }),
    });

    if (!response.ok) {
      const errBody = await response.text();
      return res.status(502).json({ error: `AI provider error: ${errBody}` });
    }

    const data = await response.json();
    const text = (data.content || [])
      .map((block) => (block.type === 'text' ? block.text : ''))
      .join('');

    if (!schema) {
      // No schema requested: the callers just use the raw string.
      return res.status(200).send(JSON.stringify(text));
    }

    // Schema requested: parse and return the JSON object directly, stripping
    // any accidental markdown code fences the model might add.
    const cleaned = text.replace(/```json|```/g, '').trim();
    try {
      const parsed = JSON.parse(cleaned);
      return res.status(200).json(parsed);
    } catch {
      return res.status(502).json({ error: 'AI response was not valid JSON', raw: text });
    }
  } catch (err) {
    return res.status(500).json({ error: err.message || 'AI request failed' });
  }
}

import { useEffect } from 'react';
import { Toaster } from "@/components/ui/toaster"
import { getStoredTheme, applyTheme } from '@/lib/theme';
import PageTransition from '@/components/PageTransition';
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import ScrollToTop from './components/ScrollToTop';
import ProtectedRoute from '@/components/ProtectedRoute';
import Layout from '@/components/Layout';
import { UserProgressProvider } from '@/lib/UserProgressContext';
import Welcome from './pages/Welcome';
import Home from './pages/Home';
import Onboarding from './pages/Onboarding';
import Programs from './pages/Programs';
import ProgramDetail from './pages/ProgramDetail';
import GroupDetail from './pages/GroupDetail';
import Chats from './pages/Chats';
import GroupChat from './pages/GroupChat';
import Progress from './pages/Progress';
import Profile from './pages/Profile';
import ResearchProgram from './pages/ResearchProgram';
import ArticleManager from './pages/ArticleManager';
import Notifications from './pages/Notifications';
import Schedule from './pages/Schedule';
import Journal from './pages/Journal';
import JournalArticle from './pages/JournalArticle';
import JournalAuthor from './pages/JournalAuthor';
import JournalSubmit from './pages/JournalSubmit';
import JournalMySubmissions from './pages/JournalMySubmissions';
import Vacation from './pages/Vacation';
import TeacherApplication from './pages/TeacherApplication';
import OwnerPanel from './pages/OwnerPanel';
import TeacherPanel from './pages/TeacherPanel';
import AITutor from './pages/AITutor';
import AnnouncementManager from './pages/AnnouncementManager';
import AnnouncementDetail from './pages/AnnouncementDetail';
import Login from './pages/Login';
import Register from './pages/Register';
import ForgotPassword from './pages/ForgotPassword';
import ResetPassword from './pages/ResetPassword';

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  // Show loading spinner while checking app public settings or auth
  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  // Handle authentication errors
  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      // Redirect to login automatically
      navigateToLogin();
      return null;
    }
  }

  // Render the main app
  return (
    <Routes>
      <Route path="/" element={<Welcome />} />
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />
      <Route path="/reset-password" element={<ResetPassword />} />
      <Route element={<ProtectedRoute unauthenticatedElement={<Navigate to="/login" replace />} />}>
        <Route element={<Layout />}>
          <Route path="/home" element={<Home />} />
          <Route path="/chats" element={<Chats />} />
          <Route path="/progress" element={<Progress />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/programs" element={<Programs />} />
          <Route path="/group/:id" element={<GroupDetail />} />
          <Route path="/announcements-manager" element={<AnnouncementManager />} />
          <Route path="/research" element={<ResearchProgram />} />
          <Route path="/article-manager" element={<ArticleManager />} />
          <Route path="/notifications" element={<Notifications />} />
          <Route path="/schedule" element={<Schedule />} />
          <Route path="/vacation" element={<Vacation />} />
          <Route path="/teacher-application" element={<TeacherApplication />} />
          <Route path="/owner" element={<OwnerPanel />} />
          <Route path="/teacher-panel" element={<TeacherPanel />} />
          <Route path="/announcements-manager" element={<AnnouncementManager />} />
          <Route path="/journal" element={<Journal />} />
          <Route path="/journal/author/:authorName" element={<JournalAuthor />} />
          <Route path="/journal/submit" element={<JournalSubmit />} />
          <Route path="/journal/submissions" element={<JournalMySubmissions />} />
        </Route>
        <Route path="/onboarding" element={<PageTransition><Onboarding /></PageTransition>} />
        <Route path="/ai-tutor" element={<PageTransition><AITutor /></PageTransition>} />
        <Route path="/program/:id" element={<PageTransition><ProgramDetail /></PageTransition>} />
        <Route path="/announcement/:id" element={<PageTransition><AnnouncementDetail /></PageTransition>} />
        <Route path="/chat/:id" element={<PageTransition><GroupChat /></PageTransition>} />
        <Route path="/journal/article/:id" element={<PageTransition><JournalArticle /></PageTransition>} />
      </Route>
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};


function App() {
  useEffect(() => {
    applyTheme(getStoredTheme());
  }, []);

  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <ScrollToTop />
          <UserProgressProvider>
            <AuthenticatedApp />
          </UserProgressProvider>
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App
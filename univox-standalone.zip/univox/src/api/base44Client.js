// Drop-in replacement for the old @base44/sdk client.
//
// The rest of the app imports `base44` from this file and calls
// `base44.entities.<Name>.list/filter/get/create/update/delete/subscribe`,
// `base44.auth.*`, and `base44.integrations.Core.*` — exactly like it did
// against Base44's hosted backend. This file re-implements that same
// surface on top of Supabase (Postgres + Auth + Storage), so none of the
// page/component code had to change.
//
// See /supabase/schema.sql for the tables this expects, and README.md /
// .env.example for the environment variables it needs.

import { supabase } from '@/lib/supabaseClient';

// Maps the old Base44 entity names to Postgres table names (see supabase/schema.sql).
const ENTITY_TABLES = {
  Announcement: 'announcements',
  AppNotification: 'app_notifications',
  Application: 'applications',
  Badge: 'badges',
  Certificate: 'certificates',
  Chat: 'chats',
  Group: 'groups',
  GroupMaterial: 'group_materials',
  JournalArticle: 'journal_articles',
  Lesson: 'lessons',
  Program: 'programs',
  TeacherApplication: 'teacher_applications',
  TimelineEvent: 'timeline_events',
  User: 'profiles',
  VacationSnap: 'vacation_snaps',
};

// Base44's `.list('-created_date', 20)` sort syntax: a leading "-" means descending.
function parseSort(sortStr) {
  if (!sortStr || typeof sortStr !== 'string') {
    return { column: 'created_date', ascending: false };
  }
  const ascending = !sortStr.startsWith('-');
  const column = ascending ? sortStr : sortStr.slice(1);
  return { column, ascending };
}

async function currentAuthUser() {
  const { data } = await supabase.auth.getUser();
  return data?.user ?? null;
}

function createEntityClient(table) {
  return {
    async list(sort = '-created_date', limit) {
      const { column, ascending } = parseSort(sort);
      let query = supabase.from(table).select('*').order(column, { ascending });
      if (limit) query = query.limit(limit);
      const { data, error } = await query;
      if (error) throw error;
      return data ?? [];
    },

    async filter(match = {}, sort, limit) {
      let query = supabase.from(table).select('*');
      Object.entries(match || {}).forEach(([key, value]) => {
        query = query.eq(key, value);
      });
      if (sort) {
        const { column, ascending } = parseSort(sort);
        query = query.order(column, { ascending });
      }
      if (limit) query = query.limit(limit);
      const { data, error } = await query;
      if (error) throw error;
      return data ?? [];
    },

    async get(id) {
      const { data, error } = await supabase.from(table).select('*').eq('id', id).maybeSingle();
      if (error) throw error;
      if (!data) {
        const err = new Error(`${table} record not found`);
        err.status = 404;
        throw err;
      }
      return data;
    },

    async create(payload) {
      const user = await currentAuthUser();
      const row = {
        ...payload,
        created_by_id: user?.id ?? null,
        created_by_name: user?.user_metadata?.full_name ?? user?.email ?? null,
      };
      const { data, error } = await supabase.from(table).insert(row).select().single();
      if (error) throw error;
      return data;
    },

    async update(id, payload) {
      const { data, error } = await supabase
        .from(table)
        .update({ ...payload, updated_date: new Date().toISOString() })
        .eq('id', id)
        .select()
        .single();
      if (error) throw error;
      return data;
    },

    async delete(id) {
      const { error } = await supabase.from(table).delete().eq('id', id);
      if (error) throw error;
      return true;
    },

    // Realtime subscription. Returns an unsubscribe function.
    subscribe(callback) {
      const channel = supabase
        .channel(`${table}-changes`)
        .on('postgres_changes', { event: '*', schema: 'public', table }, callback)
        .subscribe();
      return () => supabase.removeChannel(channel);
    },
  };
}

const entities = Object.fromEntries(
  Object.entries(ENTITY_TABLES).map(([name, table]) => [name, createEntityClient(table)])
);

// Deleting an auth user requires the Supabase service-role key, which must never
// reach the browser — so this proxies through a small Vercel serverless function.
entities.User.delete = async (id) => {
  const { data: { session } } = await supabase.auth.getSession();
  const res = await fetch('/api/admin-delete-user', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      ...(session?.access_token ? { Authorization: `Bearer ${session.access_token}` } : {}),
    },
    body: JSON.stringify({ id }),
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.error || 'Failed to delete user');
  }
  return true;
};

async function mapAuthUser(session) {
  const sessionUser = session?.user;
  if (!sessionUser) return null;
  const { data: profile } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', sessionUser.id)
    .maybeSingle();
  return {
    id: sessionUser.id,
    email: sessionUser.email,
    full_name: sessionUser.user_metadata?.full_name ?? null,
    ...profile,
  };
}

export const base44 = {
  entities,

  auth: {
    async me() {
      const { data, error } = await supabase.auth.getSession();
      if (error) throw error;
      const user = await mapAuthUser(data.session);
      if (!user) {
        const err = new Error('Not authenticated');
        err.status = 401;
        throw err;
      }
      return user;
    },

    async loginViaEmailPassword(email, password) {
      const { data, error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) throw error;
      return mapAuthUser(data.session);
    },

    async loginWithProvider(provider = 'google', redirectPath = '/home') {
      const { error } = await supabase.auth.signInWithOAuth({
        provider,
        options: { redirectTo: `${window.location.origin}${redirectPath}` },
      });
      if (error) throw error;
    },

    async register({ email, password }) {
      const { data, error } = await supabase.auth.signUp({ email, password });
      if (error) throw error;
      if (data.user) {
        // Create the matching profile row up front; profile fields (name, roles, etc.)
        // get filled in afterwards via updateMe() once the account is verified.
        await supabase.from('profiles').upsert({
          id: data.user.id,
          email,
          role: 'user',
          roles: ['student'],
          teacher_status: 'none',
        });
      }
      return mapAuthUser(data.session);
    },

    async updateMe(payload) {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user) {
        const err = new Error('Not authenticated');
        err.status = 401;
        throw err;
      }
      const { data, error } = await supabase
        .from('profiles')
        .update({ ...payload, updated_date: new Date().toISOString() })
        .eq('id', session.user.id)
        .select()
        .single();
      if (error) throw error;
      return { id: session.user.id, email: session.user.email, ...data };
    },

    async logout(redirectUrl) {
      await supabase.auth.signOut();
      if (redirectUrl) window.location.href = redirectUrl;
    },

    redirectToLogin(returnUrl) {
      window.location.href = `/login${returnUrl ? `?redirect=${encodeURIComponent(returnUrl)}` : ''}`;
    },

    setToken() {
      // No-op: Supabase manages its own session/token storage in localStorage.
    },

    async resetPasswordRequest(email) {
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${window.location.origin}/reset-password`,
      });
      if (error) throw error;
    },

    async resetPassword({ newPassword }) {
      // Supabase establishes a recovery session automatically from the emailed
      // link, so we just update the password on that active session.
      const { error } = await supabase.auth.updateUser({ password: newPassword });
      if (error) throw error;
    },

    async verifyOtp({ email, otpCode }) {
      const { data, error } = await supabase.auth.verifyOtp({
        email,
        token: otpCode,
        type: 'signup',
      });
      if (error) throw error;
      return { access_token: data.session?.access_token };
    },

    async resendOtp(email) {
      const { error } = await supabase.auth.resend({ type: 'signup', email });
      if (error) throw error;
    },
  },

  integrations: {
    Core: {
      async UploadFile({ file }) {
        const path = `${crypto.randomUUID()}-${file.name}`;
        const { error } = await supabase.storage.from('uploads').upload(path, file, {
          upsert: false,
          cacheControl: '3600',
        });
        if (error) throw error;
        const { data } = supabase.storage.from('uploads').getPublicUrl(path);
        return { file_url: data.publicUrl };
      },

      // Proxies to a Vercel serverless function so the LLM API key stays server-side.
      async InvokeLLM({ prompt, response_json_schema }) {
        const res = await fetch('/api/invoke-llm', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ prompt, response_json_schema }),
        });
        if (!res.ok) {
          const body = await res.json().catch(() => ({}));
          throw new Error(body.error || 'AI request failed');
        }
        return res.json();
      },
    },
  },
};

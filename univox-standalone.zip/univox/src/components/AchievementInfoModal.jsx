import { motion, AnimatePresence } from 'framer-motion';
import { Lock, X } from 'lucide-react';

export default function AchievementInfoModal({ item, onClose }) {
  return (
    <AnimatePresence>
      {item && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 z-[120] flex items-center justify-center p-6 bg-black/55 backdrop-blur-sm"
        >
          <motion.div
            initial={{ scale: 0.85, opacity: 0, y: 18 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.88, opacity: 0, y: 10 }}
            transition={{ type: 'spring', damping: 18, stiffness: 280 }}
            onClick={(e) => e.stopPropagation()}
            className="relative bg-card rounded-[1.75rem] p-7 max-w-xs w-full text-center shadow-float overflow-hidden"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-muted/40 to-transparent pointer-events-none" />
            <button
              onClick={onClose}
              className="absolute top-3 right-3 w-8 h-8 rounded-full bg-background/60 flex items-center justify-center no-tap-highlight z-10"
            >
              <X size={16} className="text-muted-foreground" />
            </button>

            <div className="relative">
              <div
                className="inline-flex items-center justify-center w-16 h-16 rounded-2xl mb-4 grayscale opacity-70"
                style={{ background: `${item.color}15` }}
              >
                <Lock size={26} style={{ color: item.color }} />
              </div>
              <p className="text-[10px] font-bold tracking-[0.2em] uppercase text-muted-foreground">Locked</p>
              <h3 className="text-lg font-extrabold mt-1">{item.title}</h3>
              <p className="text-sm text-muted-foreground mt-3 leading-relaxed">{item.reqText}</p>
              <button
                onClick={onClose}
                className="mt-6 w-full bg-primary text-primary-foreground rounded-2xl py-3 font-bold text-sm shadow-lg shadow-primary/25 no-tap-highlight"
              >
                Got it
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
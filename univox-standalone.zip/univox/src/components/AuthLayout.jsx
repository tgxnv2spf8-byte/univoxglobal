import React from "react";
import { motion } from "framer-motion";

export default function AuthLayout({ icon: Icon, title, subtitle, footer, children }) {
  return (
    <div className="min-h-screen flex flex-col bg-background bg-mesh">
      <div className="flex-1 flex flex-col justify-center px-6 py-10 max-w-md mx-auto w-full">
        <motion.div
          initial={{ opacity: 0, y: -12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="text-center mb-8"
        >
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-gradient-to-br from-primary to-secondary mb-3 shadow-lg shadow-primary/20">
            <Icon className="w-7 h-7 text-white" aria-hidden="true" />
          </div>
          <p className="text-xs font-bold tracking-[0.2em] text-primary uppercase">UNIVOX</p>
          <h1 className="text-2xl font-extrabold tracking-tight text-foreground mt-1">{title}</h1>
          {subtitle && <p className="text-sm text-muted-foreground mt-1.5 px-4">{subtitle}</p>}
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1, duration: 0.4 }}
          className="bg-card rounded-3xl shadow-card border border-border/40 p-6"
        >
          {children}
        </motion.div>

        {footer && (
          <p className="text-center text-sm text-muted-foreground mt-5">{footer}</p>
        )}
      </div>
    </div>
  );
}
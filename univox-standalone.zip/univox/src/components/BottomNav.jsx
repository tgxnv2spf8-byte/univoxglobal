import { NavLink } from 'react-router-dom';
import { Home, Calendar, Newspaper, MessageCircle, TrendingUp, User } from 'lucide-react';

const navItems = [
  { to: '/home', icon: Home, label: 'Home' },
  { to: '/schedule', icon: Calendar, label: 'Schedule' },
  { to: '/journal', icon: Newspaper, label: 'Journal' },
  { to: '/chats', icon: MessageCircle, label: 'Chats' },
  { to: '/progress', icon: TrendingUp, label: 'Progress' },
  { to: '/profile', icon: User, label: 'Profile' },
];

export default function BottomNav() {
  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 flex justify-center pb-[calc(0.75rem+var(--safe-bottom))] px-[calc(1rem+var(--safe-left))] pointer-events-none">
      <nav className="glass-strong flex items-center gap-1 rounded-[28px] shadow-float border border-white/50 px-2 py-2 max-w-md w-full pointer-events-auto no-tap-highlight">
        {navItems.map((item) => (
          <NavLink key={item.to} to={item.to} className="flex-1 no-tap-highlight">
            {({ isActive }) => (
              <div
                className={`flex flex-col items-center gap-0.5 py-2 rounded-[18px] transition-all duration-300 ${
                  isActive
                    ? 'bg-primary text-primary-foreground shadow-lg shadow-primary/30'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                <item.icon size={20} strokeWidth={isActive ? 2.5 : 2} />
                <span className={`text-[9px] tracking-wide ${isActive ? 'font-semibold' : 'font-medium'}`}>
                  {item.label}
                </span>
              </div>
            )}
          </NavLink>
        ))}
      </nav>
    </div>
  );
}
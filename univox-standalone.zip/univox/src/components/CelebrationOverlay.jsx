import { useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import confetti from 'canvas-confetti';
import { X, Award, Flame, Globe, Sparkles, Star } from 'lucide-react';

const iconMap = {
  Award,
  Flame,
  Globe,
  Sparkles,
  Star,
  default: Award,
};

export default function CelebrationOverlay({ achievement, onClose }) {
  const firedRef = useRef(false);

  useEffect(() => {
    if (!achievement || firedRef.current) return;
    firedRef.current = true;

    const colors = ['#1E4DFF', '#FF6FAE', '#FFD84D', '#FF8A3D'];
    const burst = (opts) => confetti({ ...opts, colors, scalar: 1, ticks: 200 });

    burst({ particleCount: 80, spread: 70, origin: { y: 0.6 } });
    setTimeout(() => burst({ particleCount: 60, spread: 60, angle: 60, origin: { x: 0, y: 0.7 } }), 150);
    setTimeout(() => burst({ particleCount: 60, spread: 60, angle: 120, origin: { x: 1, y: 0.7 } }), 300);
    setTimeout(() => burst({ particleCount: 50, spread: 100, origin: { y: 0.5 }, startVelocity: 45 }), 500);
    setTimeout(() => burst({ particleCount: 40, spread: 80, origin: { y: 0.6, x: 0.5 }, scalar: 1.2 }), 800);
  }, [achievement]);

  const isBadge = achievement?.type === 'badge';
  const Icon = iconMap[achievement?.icon_name] || iconMap.default;

  return (
    <AnimatePresence>
      {achievement && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[100] flex items-center justify-center p-6"
          style={{ background: 'rgba(0, 0, 0, 0.5)', backdropFilter: 'blur(8px)' }}
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.7, opacity: 0, y: 30 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.8, opacity: 0, y: 20 }}
            transition={{ type: 'spring', damping: 18, stiffness: 300 }}
            className="relative bg-card rounded-[2rem] p-8 max-w-sm w-full text-center shadow-float overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-secondary/10 to-accent/10 pointer-events-none" />
            <div className="absolute -top-12 -right-12 w-32 h-32 rounded-full bg-secondary/15" />
            <div className="absolute -bottom-8 -left-8 w-24 h-24 rounded-full bg-accent/15" />

            <button
              onClick={onClose}
              className="absolute top-4 right-4 w-8 h-8 rounded-full bg-background/60 flex items-center justify-center z-10 no-tap-highlight"
            >
              <X size={16} className="text-muted-foreground" />
            </button>

            <div className="relative">
              <motion.p
                initial={{ opacity: 0, y: -8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="text-xs font-bold uppercase tracking-[0.2em] text-secondary"
              >
                {isBadge ? 'New Badge Earned!' : 'Certificate Received!'}
              </motion.p>

              <motion.div
                initial={{ scale: 0, rotate: -30 }}
                animate={{ scale: 1, rotate: 0 }}
                transition={{ delay: 0.15, type: 'spring', damping: 12, stiffness: 200 }}
                className="inline-flex items-center justify-center w-24 h-24 rounded-3xl bg-gradient-to-br from-primary via-secondary to-accent text-white shadow-lg shadow-primary/30 my-5"
              >
                <Icon size={44} />
              </motion.div>

              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.3, type: 'spring' }}
                className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-2"
              >
                {[...Array(3)].map((_, i) => (
                  <motion.div
                    key={i}
                    animate={{ y: [0, -6, 0], rotate: [0, 15, 0] }}
                    transition={{ duration: 1.5, repeat: Infinity, delay: i * 0.2 }}
                    className="absolute"
                    style={{ left: `${(i - 1) * 30 - 6}px` }}
                  >
                    <Sparkles size={16} className="text-accent" />
                  </motion.div>
                ))}
              </motion.div>

              <motion.h2
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.35 }}
                className="text-2xl font-extrabold tracking-tight"
              >
                {achievement.title}
              </motion.h2>

              {achievement.description && (
                <motion.p
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.45 }}
                  className="text-sm text-muted-foreground mt-2 px-4"
                >
                  {achievement.description}
                </motion.p>
              )}

              {achievement.date_received && (
                <motion.p
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.55 }}
                  className="text-xs text-muted-foreground/70 mt-2"
                >
                  {achievement.date_received}
                </motion.p>
              )}

              <motion.button
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.6 }}
                onClick={onClose}
                className="mt-6 w-full bg-primary text-primary-foreground rounded-2xl py-3.5 font-bold text-sm shadow-lg shadow-primary/25 no-tap-highlight"
              >
                {isBadge ? 'Awesome!' : 'View Certificate'}
              </motion.button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
import { motion, AnimatePresence } from 'framer-motion';
import { X, Award, Globe } from 'lucide-react';

const pixelColors = ['#1E4DFF', '#FF6FAE', '#FFD84D', '#FF8A3D', '#1E4DFF', '#FF6FAE', '#FFD84D', '#FF8A3D'];

export default function CertificateModal({ certificate, userName, onClose }) {
  const today = new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
  const recipient = userName || 'UNIVOX Learner';

  return (
    <AnimatePresence>
      {certificate && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 z-[120] flex items-center justify-center p-4 bg-black/70 backdrop-blur-md"
        >
          <motion.div
            initial={{ scale: 0.8, opacity: 0, y: 24 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.85, opacity: 0, y: 16 }}
            transition={{ type: 'spring', damping: 20, stiffness: 260 }}
            onClick={(e) => e.stopPropagation()}
            className="relative w-full max-w-md"
          >
            {/* pixel / mosaic outer border */}
            <div className="rounded-[2rem] p-[3px]" style={{ background: `linear-gradient(135deg, ${pixelColors.join(', ')})` }}>
              <div className="rounded-[1.75rem] bg-white relative overflow-hidden shadow-float">
                {/* watermark world map */}
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-[0.06]">
                  <Globe size={260} className="text-primary" />
                </div>
                <div className="absolute -top-10 -right-10 w-40 h-40 rounded-full bg-primary/5" />
                <div className="absolute -bottom-12 -left-12 w-44 h-44 rounded-full bg-secondary/5" />

                <button
                  onClick={onClose}
                  className="absolute top-3 right-3 w-8 h-8 rounded-full bg-black/5 flex items-center justify-center no-tap-highlight z-10"
                >
                  <X size={16} className="text-foreground/60" />
                </button>

                <div className="relative px-7 py-9 text-center text-foreground">
                  {/* pixel accent bar */}
                  <div className="flex gap-0 justify-center mb-6">
                    {pixelColors.slice(0, 8).map((c, i) => (
                      <div key={i} className="w-5 h-1.5" style={{ background: c }} />
                    ))}
                  </div>

                  <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl mb-4 shadow-lg" style={{ background: `linear-gradient(135deg, ${pixelColors[0]}, ${pixelColors[1]})` }}>
                    <Award size={30} className="text-white" />
                  </div>

                  <p className="text-[11px] font-bold tracking-[0.35em] text-primary uppercase">UNIVOX</p>
                  <h2 className="font-editorial text-2xl font-bold mt-1 text-gradient-primary">Certificate of Achievement</h2>

                  <div className="mt-5 mx-auto w-16 h-px bg-foreground/15" />

                  <p className="text-xs text-muted-foreground mt-5 uppercase tracking-wider">Proudly Presented To</p>
                  <p className="text-xl font-extrabold mt-1.5 text-foreground">{recipient}</p>

                  <p className="text-sm text-muted-foreground mt-4 leading-relaxed px-2">
                    For successfully completing <span className="font-semibold text-foreground">{certificate.title}</span>{certificate.program ? <> in the <span className="font-semibold text-foreground">{certificate.program}</span> program</> : null}, demonstrating dedication and excellence in global learning.
                  </p>

                  <div className="flex items-end justify-between mt-8 px-1">
                    <div className="text-left">
                      <p className="font-editorial text-lg italic text-foreground/80" style={{ transform: 'rotate(-6deg)', display: 'inline-block' }}>UNIVOX</p>
                      <div className="w-24 h-px bg-foreground/30 mt-1" />
                      <p className="text-[10px] text-muted-foreground mt-1">Official Signature</p>
                    </div>
                    <div className="text-right">
                      <p className="text-xs font-semibold text-foreground">{today}</p>
                      <div className="w-24 h-px bg-foreground/30 mt-1 ml-auto" />
                      <p className="text-[10px] text-muted-foreground mt-1">Date Issued</p>
                    </div>
                  </div>

                  <div className="flex gap-0 justify-center mt-7">
                    {pixelColors.slice(0, 8).reverse().map((c, i) => (
                      <div key={i} className="w-5 h-1.5" style={{ background: c }} />
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
import { Outlet, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import BottomNav from './BottomNav';

export default function Layout() {
  const location = useLocation();
  return (
    <div className="min-h-screen bg-background bg-mesh flex justify-center">
      <div className="w-full max-w-md min-h-screen relative">
        <motion.div
          key={location.pathname}
          initial={{ opacity: 0, x: 16 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.28, ease: 'easeOut' }}
        >
          <Outlet />
        </motion.div>
      </div>
      <BottomNav />
    </div>
  );
}
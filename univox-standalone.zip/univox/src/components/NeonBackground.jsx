import { motion } from 'framer-motion';

const BARS = 'https://media.base44.com/images/public/6a51768d9b73d617045c18ee/e8a8830b3_IMG_1967.jpg';
const WEB = 'https://media.base44.com/images/public/6a51768d9b73d617045c18ee/f4d82da9e_IMG_1966.jpg';

export default function NeonBackground() {
  return (
    <div className="absolute inset-0 overflow-hidden">
      {/* Base layer — vertical neon bars (background) */}
      <div className="absolute inset-0">
        <img src={BARS} alt="" className="w-full h-full object-cover" style={{ filter: 'blur(16px) saturate(1.1)' }} />
        <div className="absolute inset-0 bg-black/45" />
      </div>

      {/* Main layer — pink web, slow ken-burns */}
      <motion.div
        className="absolute inset-0"
        initial={{ scale: 1.08, opacity: 0 }}
        animate={{ scale: 1.18, opacity: 1 }}
        transition={{ duration: 14, ease: 'linear', repeat: Infinity, repeatType: 'reverse' }}
      >
        <img src={WEB} alt="" className="w-full h-full object-cover" style={{ filter: 'saturate(1.15)' }} />
      </motion.div>

      {/* Readability + brand tint */}
      <div className="absolute inset-0 bg-black/25" />
      <div className="absolute inset-0 bg-gradient-to-br from-primary/15 via-transparent to-secondary/15 mix-blend-screen" />
    </div>
  );
}
import { useEffect, useRef, useState } from 'react';
import { Loader2 } from 'lucide-react';

const THRESHOLD = 70;
const MAX = 120;

export default function PullToRefresh({ onRefresh, className, children }) {
  const [pull, setPull] = useState(0);
  const [refreshing, setRefreshing] = useState(false);
  const [dragging, setDragging] = useState(false);
  const startY = useRef(0);
  const pulling = useRef(false);
  const pullRef = useRef(0);
  const onRefreshRef = useRef(onRefresh);
  onRefreshRef.current = onRefresh;

  useEffect(() => {
    const onTouchStart = (e) => {
      if (refreshing) return;
      if (window.scrollY <= 0) {
        startY.current = e.touches[0].clientY;
        pulling.current = true;
        setDragging(true);
      } else {
        pulling.current = false;
      }
    };
    const onTouchMove = (e) => {
      if (!pulling.current || refreshing) return;
      const dy = e.touches[0].clientY - startY.current;
      if (dy > 0) {
        const next = Math.min(dy * 0.5, MAX);
        pullRef.current = next;
        setPull(next);
      }
    };
    const onTouchEnd = () => {
      if (!pulling.current) return;
      pulling.current = false;
      setDragging(false);
      if (pullRef.current >= THRESHOLD) {
        setRefreshing(true);
        setPull(THRESHOLD);
        pullRef.current = THRESHOLD;
        Promise.resolve(onRefreshRef.current && onRefreshRef.current()).finally(() => {
          setRefreshing(false);
          setPull(0);
          pullRef.current = 0;
        });
      } else {
        setPull(0);
        pullRef.current = 0;
      }
    };
    window.addEventListener('touchstart', onTouchStart, { passive: true });
    window.addEventListener('touchmove', onTouchMove, { passive: true });
    window.addEventListener('touchend', onTouchEnd, { passive: true });
    return () => {
      window.removeEventListener('touchstart', onTouchStart);
      window.removeEventListener('touchmove', onTouchMove);
      window.removeEventListener('touchend', onTouchEnd);
    };
  }, [refreshing]);

  return (
    <div className={className}>
      <div
        className="flex items-center justify-center overflow-hidden"
        style={{ height: pull, transition: dragging ? 'none' : 'height 0.22s ease-out' }}
      >
        <Loader2
          size={22}
          className={`text-primary transition-opacity ${refreshing ? 'animate-spin' : ''}`}
          style={{ opacity: refreshing ? 1 : Math.min(pull / THRESHOLD, 1) }}
        />
      </div>
      {children}
    </div>
  );
}
import { useState } from 'react';
import { motion } from 'framer-motion';
import { X, ImagePlus, Loader2, Save, Send, Clock, Archive, Trash2, Star, Calendar, Link2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { CATEGORIES, LANGUAGES } from './announcementConfig';
import IOSSelect from '@/components/IOSSelect';

const blank = {
  title: '',
  short_description: '',
  full_description: '',
  cover_image_url: '',
  category: 'info',
  language: 'en',
  teacher: '',
  event_date: '',
  location_or_link: '',
  join_button_label: 'Join',
  join_target_group_id: '',
  status: 'draft',
  featured: false,
  scheduled_for: '',
};

export default function AnnouncementEditor({ announcement, groups, onDone }) {
  const [form, setForm] = useState({ ...blank, ...(announcement || {}) });
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(null);
  const isNew = !announcement?.id;

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const onCover = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      set('cover_image_url', file_url);
    } catch (err) {
      alert('Upload failed. Please try again.');
    }
    setUploading(false);
  };

  const persist = async (overrides) => {
    const payload = { ...form, ...overrides };
    if (!payload.title.trim()) {
      alert('Please add a title.');
      return;
    }
    setSaving(overrides.status || 'saving');
    try {
      if (isNew) {
        await base44.entities.Announcement.create(payload);
      } else {
        await base44.entities.Announcement.update(announcement.id, payload);
      }
      onDone();
    } catch (err) {
      alert('Could not save. Please try again.');
    }
    setSaving(null);
  };

  const remove = async () => {
    if (!confirm('Delete this announcement permanently?')) return;
    setSaving('deleting');
    await base44.entities.Announcement.delete(announcement.id).catch(() => {});
    onDone();
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 bg-black/40 flex justify-center"
      onClick={onDone}
    >
      <motion.div
        initial={{ y: '100%' }}
        animate={{ y: 0 }}
        exit={{ y: '100%' }}
        transition={{ type: 'spring', damping: 30, stiffness: 300 }}
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-md h-full bg-background overflow-y-auto rounded-t-[2rem] flex flex-col"
      >
        <div className="sticky top-0 z-10 glass-strong px-5 py-4 flex items-center justify-between border-b border-border/40">
          <h2 className="text-lg font-extrabold">{isNew ? 'New Announcement' : 'Edit Announcement'}</h2>
          <button onClick={onDone} className="w-9 h-9 rounded-full bg-card flex items-center justify-center no-tap-highlight"><X size={18} /></button>
        </div>

        <div className="px-5 py-5 space-y-5 pb-40">
          {/* Cover */}
          <div>
            <Label>Cover Image</Label>
            <label className="relative block h-36 rounded-2xl overflow-hidden bg-muted border border-dashed border-border cursor-pointer no-tap-highlight">
              {form.cover_image_url ? (
                <img src={form.cover_image_url} alt="" className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex flex-col items-center justify-center text-muted-foreground">
                  {uploading ? <Loader2 size={22} className="animate-spin" /> : <ImagePlus size={22} />}
                  <p className="text-xs mt-1 font-medium">{uploading ? 'Uploading…' : 'Tap to upload'}</p>
                </div>
              )}
              <input type="file" accept="image/*" onChange={onCover} className="hidden" />
            </label>
          </div>

          <Field label="Title" value={form.title} onChange={(v) => set('title', v)} placeholder="Announcement title" />

          <div>
            <Label>Short Description</Label>
            <textarea value={form.short_description} onChange={(e) => set('short_description', e.target.value)} placeholder="One-line summary shown on Home" rows={2} className="w-full bg-card rounded-2xl px-4 py-3 text-sm outline-none border border-transparent focus:border-primary/30 resize-none" />
          </div>

          <div>
            <Label>Full Description</Label>
            <textarea value={form.full_description} onChange={(e) => set('full_description', e.target.value)} placeholder="Full details shown on the detail page" rows={5} className="w-full bg-card rounded-2xl px-4 py-3 text-sm outline-none border border-transparent focus:border-primary/30 resize-none" />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Category</Label>
              <IOSSelect value={form.category} onChange={(v) => set('category', v)} options={CATEGORIES.map((c) => ({ value: c.id, label: `${c.emoji} ${c.label}` }))} className="w-full bg-card rounded-2xl px-3 py-3 text-sm font-medium border border-transparent" />
            </div>
            <div>
              <Label>Language</Label>
              <IOSSelect value={form.language} onChange={(v) => set('language', v)} options={LANGUAGES.map((l) => ({ value: l.id, label: `${l.flag} ${l.label}` }))} className="w-full bg-card rounded-2xl px-3 py-3 text-sm font-medium border border-transparent" />
            </div>
          </div>

          <Field label="Teacher (optional)" value={form.teacher || ''} onChange={(v) => set('teacher', v)} placeholder="e.g. Emma" />

          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Event Date (optional)</Label>
              <input type="datetime-local" value={toLocalInput(form.event_date)} onChange={(e) => set('event_date', fromLocalInput(e.target.value))} className="w-full bg-card rounded-2xl px-3 py-3 text-sm font-medium border border-transparent" />
            </div>
            <div>
              <Label>Schedule Publication</Label>
              <input type="datetime-local" value={toLocalInput(form.scheduled_for)} onChange={(e) => set('scheduled_for', fromLocalInput(e.target.value))} className="w-full bg-card rounded-2xl px-3 py-3 text-sm font-medium border border-transparent" />
            </div>
          </div>

          <div>
            <Label>Location or Meeting Link (optional)</Label>
            <div className="relative">
              <Link2 size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <input value={form.location_or_link || ''} onChange={(e) => set('location_or_link', e.target.value)} placeholder="https://meet.google.com/…  or a place" className="w-full bg-card rounded-2xl pl-11 pr-4 py-3 text-sm font-medium border border-transparent" />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <Field label="Join Button Label" value={form.join_button_label || 'Join'} onChange={(v) => set('join_button_label', v)} placeholder="Join" />
            <div>
              <Label>Join Target Group</Label>
              <IOSSelect value={form.join_target_group_id || ''} onChange={(v) => set('join_target_group_id', v)} placeholder="None" options={groups.map((g) => ({ value: g.id, label: g.name }))} className="w-full bg-card rounded-2xl px-3 py-3 text-sm font-medium border border-transparent" />
            </div>
          </div>

          <button
            onClick={() => set('featured', !form.featured)}
            className={`w-full flex items-center gap-3 p-4 rounded-2xl border-2 no-tap-highlight ${form.featured ? 'border-primary bg-primary/5' : 'border-transparent bg-card'}`}
          >
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${form.featured ? 'bg-accent/20' : 'bg-muted'}`}>
              <Star size={18} className={form.featured ? 'text-accent-foreground fill-accent' : 'text-muted-foreground'} />
            </div>
            <div className="flex-1 text-left">
              <p className="font-bold text-sm">Featured on Home Page</p>
              <p className="text-xs text-muted-foreground">Show this prominently for all users</p>
            </div>
            <div className={`w-11 h-6 rounded-full p-0.5 transition-colors ${form.featured ? 'bg-primary' : 'bg-muted'}`}>
              <div className={`w-5 h-5 rounded-full bg-white transition-transform ${form.featured ? 'translate-x-5' : ''}`} />
            </div>
          </button>
        </div>

        {/* Sticky action bar */}
        <div className="fixed bottom-0 left-0 right-0 max-w-md mx-auto px-5 py-4 glass-strong border-t border-border/40 space-y-2">
          <div className="grid grid-cols-2 gap-2">
            <button onClick={() => persist({ status: 'draft' })} disabled={!!saving} className="flex items-center justify-center gap-1.5 bg-card rounded-2xl py-3 text-sm font-bold no-tap-highlight disabled:opacity-50"><Save size={16} /> {saving === 'draft' ? 'Saving…' : 'Save Draft'}</button>
            <button onClick={() => persist({ status: 'published', published_date: new Date().toISOString() })} disabled={!!saving} className="flex items-center justify-center gap-1.5 bg-green-500 text-white rounded-2xl py-3 text-sm font-bold no-tap-highlight disabled:opacity-50"><Send size={16} /> {saving === 'published' ? 'Publishing…' : 'Publish Now'}</button>
          </div>
          <div className="grid grid-cols-3 gap-2">
            <button onClick={() => persist({ status: 'scheduled' })} disabled={!!saving || !form.scheduled_for} className="flex items-center justify-center gap-1 bg-card rounded-xl py-2.5 text-xs font-bold no-tap-highlight disabled:opacity-40"><Clock size={14} /> Schedule</button>
            <button onClick={() => persist({ status: 'archived' })} disabled={!!saving} className="flex items-center justify-center gap-1 bg-card rounded-xl py-2.5 text-xs font-bold no-tap-highlight disabled:opacity-40"><Archive size={14} /> Archive</button>
            {!isNew && <button onClick={remove} disabled={!!saving} className="flex items-center justify-center gap-1 bg-destructive/10 text-destructive rounded-xl py-2.5 text-xs font-bold no-tap-highlight disabled:opacity-40"><Trash2 size={14} /> Delete</button>}
            {isNew && <div />}
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}

function Label({ children }) {
  return <p className="text-xs font-bold text-muted-foreground uppercase tracking-wide mb-1.5">{children}</p>;
}

function Field({ label, value, onChange, placeholder }) {
  return (
    <div>
      <Label>{label}</Label>
      <input value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} className="w-full bg-card rounded-2xl px-4 py-3 text-sm font-medium border border-transparent focus:border-primary/30" />
    </div>
  );
}

function toLocalInput(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  if (isNaN(d)) return '';
  const off = d.getTimezoneOffset();
  return new Date(d - off * 60000).toISOString().slice(0, 16);
}
function fromLocalInput(local) {
  if (!local) return '';
  return new Date(local).toISOString();
}
import { motion } from 'framer-motion';
import { Eye, UserPlus, Users, Pencil, Copy, Send, PenLine, Archive, Trash2 } from 'lucide-react';
import { STATUS_STYLES, categoryEmoji, categoryLabel } from './announcementConfig';

export default function AnnouncementRow({ a, index, onEdit, onDuplicate, onPublish, onUnpublish, onArchive, onDelete }) {
  const status = STATUS_STYLES[a.status] || STATUS_STYLES.draft;
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.04, duration: 0.3 }}
      className="bg-card rounded-2xl p-3.5 shadow-soft"
    >
      <div className="flex gap-3">
        <div className="w-16 h-16 rounded-xl overflow-hidden flex-shrink-0 bg-muted">
          {a.cover_image_url ? (
            <img src={a.cover_image_url} alt="" className="w-full h-full object-cover" />
          ) : (
            <div className="w-full h-full flex items-center justify-center text-2xl">{categoryEmoji(a.category)}</div>
          )}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <p className="font-bold text-sm leading-tight line-clamp-2">{a.title}</p>
            <div className="flex items-center gap-1 flex-shrink-0">
              {a.featured && <span className="text-[9px]">⭐</span>}
              <span className={`text-[9px] font-bold rounded-full px-2 py-0.5 ${status.cls}`}>{status.label}</span>
            </div>
          </div>
          <p className="text-xs text-muted-foreground mt-0.5 line-clamp-1">{a.short_description || categoryLabel(a.category)}</p>
          <div className="flex items-center gap-2.5 mt-1.5 text-[10px] text-muted-foreground flex-wrap">
            <span className="flex items-center gap-0.5"><Eye size={11} /> {a.views || 0}</span>
            <span className="flex items-center gap-0.5"><UserPlus size={11} /> {a.joins || 0}</span>
            <span className="flex items-center gap-0.5"><Users size={11} /> {a.active_participants || 0}</span>
            {a.published_date && <span>· {new Date(a.published_date).toLocaleDateString()}</span>}
          </div>
        </div>
      </div>
      <div className="flex gap-1.5 mt-2.5 flex-wrap">
        <ActionBtn icon={Pencil} label="Edit" onClick={() => onEdit(a)} />
        <ActionBtn icon={Copy} label="Duplicate" onClick={() => onDuplicate(a)} />
        {a.status !== 'published' && <ActionBtn icon={Send} label="Publish" onClick={() => onPublish(a)} primary />}
        {a.status === 'published' && <ActionBtn icon={PenLine} label="Unpublish" onClick={() => onUnpublish(a)} />}
        {a.status !== 'archived' && <ActionBtn icon={Archive} label="Archive" onClick={() => onArchive(a)} />}
        <ActionBtn icon={Trash2} onClick={() => onDelete(a)} danger />
      </div>
    </motion.div>
  );
}

function ActionBtn({ icon: Icon, label, onClick, primary, danger }) {
  return (
    <button
      onClick={onClick}
      className={`flex items-center gap-1 rounded-xl px-2.5 py-2 text-[11px] font-bold no-tap-highlight ${
        primary ? 'bg-green-500 text-white' : danger ? 'bg-destructive/10 text-destructive' : 'bg-muted text-foreground/70'
      }`}
    >
      <Icon size={13} /> {label}
    </button>
  );
}
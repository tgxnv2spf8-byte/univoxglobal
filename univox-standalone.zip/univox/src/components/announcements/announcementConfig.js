export const CATEGORIES = [
  { id: 'info', label: 'Info', emoji: '📢' },
  { id: 'event', label: 'Event', emoji: '🎉' },
  { id: 'research', label: 'Research Project', emoji: '🔬' },
  { id: 'speaking_club', label: 'Speaking Club', emoji: '🗣️' },
  { id: 'new_program', label: 'New Program', emoji: '✨' },
  { id: 'update', label: 'Update', emoji: '🔔' },
];

export const LANGUAGES = [
  { id: 'en', label: 'English', flag: '🇬🇧' },
  { id: 'fr', label: 'French', flag: '🇫🇷' },
  { id: 'es', label: 'Spanish', flag: '🇪🇸' },
  { id: 'de', label: 'German', flag: '🇩🇪' },
  { id: 'ru', label: 'Russian', flag: '🇷🇺' },
  { id: 'pt', label: 'Portuguese', flag: '🇵🇹' },
  { id: 'zh', label: 'Chinese', flag: '🇨🇳' },
];

export const STATUS_STYLES = {
  draft: { label: 'Draft', cls: 'bg-muted text-muted-foreground' },
  published: { label: 'Published', cls: 'bg-green-500/15 text-green-600' },
  scheduled: { label: 'Scheduled', cls: 'bg-accent/20 text-accent-foreground' },
  archived: { label: 'Archived', cls: 'bg-destructive/15 text-destructive' },
};

export const categoryLabel = (id) => CATEGORIES.find((c) => c.id === id)?.label || 'Info';
export const categoryEmoji = (id) => CATEGORIES.find((c) => c.id === id)?.emoji || '📢';

export const isLive = (a) =>
  !!a && (a.status === 'published' ||
    (a.status === 'scheduled' && a.scheduled_for && new Date(a.scheduled_for) <= new Date()));
import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Sparkles } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import ArticleCard from './ArticleCard';

export default function AIRecommendations({ articles }) {
  const [recommended, setRecommended] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!articles || articles.length === 0) {
      setLoading(false);
      return;
    }

    const articleList = articles
      .slice(0, 20)
      .map((a, i) => `${i + 1}. "${a.title}" — Category: ${a.category}, Author: ${a.author_name}, Likes: ${a.likes || 0}`)
      .join('\n');

    base44.integrations.Core.InvokeLLM({
      prompt: `You are an AI recommendation engine for UNIVOX Journal, a student magazine. Based on the user's diverse interests in science, culture, fashion, and technology, select 3 articles from this list that would be most engaging and thought-provoking for a curious teenager.

Available articles:
${articleList}

Return ONLY the article numbers (1-20) separated by commas, e.g. "3,7,12". Pick a diverse mix of categories.`,
      response_json_schema: {
        type: 'object',
        properties: {
          picks: {
            type: 'array',
            items: { type: 'number' },
          },
        },
      },
    })
      .then((res) => {
        const picks = (res?.picks || []).map((n) => n - 1).filter((n) => n >= 0 && n < articles.length);
        setRecommended(picks.map((idx) => articles[idx]).filter(Boolean));
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [articles]);

  if (loading) {
    return (
      <div className="mt-8">
        <div className="px-5 mb-3 flex items-center gap-2">
          <div className="w-5 h-5 rounded-full bg-primary/10 flex items-center justify-center">
            <Sparkles size={11} className="text-primary animate-pulse" />
          </div>
          <h2 className="font-editorial text-lg font-bold">Recommended for You</h2>
        </div>
        <div className="flex gap-3 overflow-hidden px-5">
          {[1, 2].map((i) => (
            <div key={i} className="w-40 flex-shrink-0 aspect-[3/4] skeleton rounded-2xl" />
          ))}
        </div>
      </div>
    );
  }

  if (recommended.length === 0) return null;

  return (
    <div className="mt-8">
      <div className="px-5 mb-3 flex items-center gap-2">
        <div className="w-5 h-5 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
          <Sparkles size={11} className="text-white" />
        </div>
        <h2 className="font-editorial text-lg font-bold">Recommended for You</h2>
      </div>
      <div className="flex gap-3 overflow-x-auto scrollbar-hide px-5 pb-1">
        {recommended.map((article, i) => (
          <div key={article.id} className="w-40 flex-shrink-0">
            <ArticleCard article={article} index={i} />
          </div>
        ))}
      </div>
    </div>
  );
}
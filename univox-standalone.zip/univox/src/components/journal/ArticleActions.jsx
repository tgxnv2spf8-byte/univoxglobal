import { useState } from 'react';
import { motion } from 'framer-motion';
import { Heart, MessageCircle, Bookmark, Share2 } from 'lucide-react';

export default function ArticleActions({ article }) {
  const [liked, setLiked] = useState(false);
  const [saved, setSaved] = useState(false);

  const handleShare = async () => {
    if (navigator.share) {
      try { await navigator.share({ title: article.title }); } catch {}
    }
  };

  const actions = [
    { icon: Heart, label: (article.likes || 0) + (liked ? 1 : 0), active: liked, onClick: () => setLiked(!liked), color: '#EC4899' },
    { icon: MessageCircle, label: article.comments_count || 0, active: false, onClick: () => {}, color: '#3B82F6' },
    { icon: Bookmark, label: 'Save', active: saved, onClick: () => setSaved(!saved), color: '#EAB308' },
    { icon: Share2, label: 'Share', active: false, onClick: handleShare, color: '#6366F1' },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 flex justify-center pb-4 px-4 pointer-events-none">
      <div className="glass-strong flex items-center gap-1 rounded-full shadow-float border border-white/50 px-3 py-2 max-w-md w-full pointer-events-auto no-tap-highlight">
        {actions.map((a, i) => (
          <button
            key={i}
            onClick={a.onClick}
            className="flex-1 flex flex-col items-center gap-0.5 py-1.5 rounded-full transition-colors no-tap-highlight"
            style={a.active ? { background: `${a.color}15` } : {}}
          >
            <motion.div animate={a.active ? { scale: [1, 1.3, 1] } : {}}>
              <a.icon
                size={20}
                fill={a.active ? a.color : 'none'}
                style={{ color: a.active ? a.color : undefined }}
                className={a.active ? '' : 'text-muted-foreground'}
              />
            </motion.div>
            <span className="text-[10px] font-medium" style={{ color: a.active ? a.color : undefined }}>
              {a.label}
            </span>
          </button>
        ))}
      </div>
    </div>
  );
}
import { motion } from 'framer-motion';
import { Clock } from 'lucide-react';
import { Link } from 'react-router-dom';
import { getCategory } from './journalConfig';

export default function ArticleCard({ article, variant = 'default', index = 0 }) {
  const cat = getCategory(article.category);

  if (variant === 'featured') {
    return (
      <motion.div
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <Link to={`/journal/article/${article.id}`} className="block no-tap-highlight">
          <div className="relative w-full aspect-[4/5] rounded-[2rem] overflow-hidden shadow-float">
            <img src={article.cover_image_url} alt={article.title} className="w-full h-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
            <div className="absolute top-4 right-4">
              <span className="text-[10px] font-bold text-white/90 bg-white/20 backdrop-blur-md px-2.5 py-1 rounded-full">
                ★ Featured
              </span>
            </div>
            <div className="absolute bottom-0 left-0 right-0 p-6">
              <span
                className="inline-flex items-center gap-1 text-xs font-bold text-white px-3 py-1 rounded-full mb-3"
                style={{ background: cat.color }}
              >
                {cat.emoji} {cat.label}
              </span>
              <h2 className="font-editorial text-3xl font-bold text-white leading-tight">{article.title}</h2>
              {article.subtitle && (
                <p className="text-sm text-white/70 mt-2 leading-relaxed line-clamp-2">{article.subtitle}</p>
              )}
              <div className="flex items-center gap-2 mt-3 text-white/80">
                <span className="text-sm font-medium">{article.author_name}</span>
                <span>•</span>
                <span className="text-sm">{article.author_flag}</span>
                <span>•</span>
                <span className="text-sm flex items-center gap-1">
                  <Clock size={12} /> {article.reading_time_minutes} min
                </span>
              </div>
            </div>
          </div>
        </Link>
      </motion.div>
    );
  }

  if (variant === 'list') {
    return (
      <motion.div
        initial={{ opacity: 0, x: -16 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ delay: index * 0.06, duration: 0.3 }}
      >
        <Link to={`/journal/article/${article.id}`} className="flex gap-3 bg-card rounded-2xl overflow-hidden shadow-soft no-tap-highlight">
          <div className="w-24 h-24 flex-shrink-0 relative">
            <img src={article.cover_image_url} alt={article.title} className="w-full h-full object-cover" />
          </div>
          <div className="flex-1 py-2.5 pr-3 flex flex-col justify-center">
            <span className="text-[10px] font-bold" style={{ color: cat.color }}>
              {cat.emoji} {cat.label}
            </span>
            <h3 className="font-editorial text-sm font-bold leading-tight line-clamp-2 mt-0.5">{article.title}</h3>
            <div className="flex items-center gap-1.5 mt-1 text-xs text-muted-foreground">
              <Clock size={10} /> {article.reading_time_minutes} min
            </div>
          </div>
        </Link>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.06, duration: 0.3 }}
    >
      <Link to={`/journal/article/${article.id}`} className="block no-tap-highlight">
        <div className="bg-card rounded-2xl overflow-hidden shadow-soft">
          <div className="relative w-full aspect-[4/3] overflow-hidden">
            <img src={article.cover_image_url} alt={article.title} className="w-full h-full object-cover" />
            <span
              className="absolute top-2 left-2 text-[10px] font-bold text-white px-2 py-0.5 rounded-full"
              style={{ background: cat.color }}
            >
              {cat.emoji} {cat.label}
            </span>
          </div>
          <div className="p-3">
            <h3 className="font-editorial text-base font-bold leading-tight line-clamp-2">{article.title}</h3>
            <div className="flex items-center gap-1.5 mt-2 text-xs text-muted-foreground">
              <span className="font-medium truncate">{article.author_name}</span>
              <span>•</span>
              <span className="flex items-center gap-0.5 flex-shrink-0">
                <Clock size={10} /> {article.reading_time_minutes}m
              </span>
            </div>
          </div>
        </div>
      </Link>
    </motion.div>
  );
}
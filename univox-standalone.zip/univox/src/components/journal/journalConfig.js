export const categories = [
  { id: 'science', label: 'Science', emoji: '🔬', color: '#3B82F6' },
  { id: 'fashion', label: 'Fashion', emoji: '👗', color: '#EC4899' },
  { id: 'culture', label: 'Culture', emoji: '🌍', color: '#F97316' },
  { id: 'technology', label: 'Technology', emoji: '💻', color: '#6366F1' },
  { id: 'environment', label: 'Environment', emoji: '🌱', color: '#22C55E' },
  { id: 'art_design', label: 'Art & Design', emoji: '🎨', color: '#A855F7' },
  { id: 'languages', label: 'Languages', emoji: '📚', color: '#EAB308' },
  { id: 'psychology', label: 'Psychology', emoji: '🧠', color: '#14B8A6' },
];

export const getCategory = (id) => categories.find((c) => c.id === id) || categories[0];
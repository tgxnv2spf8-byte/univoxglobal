import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Check, X, Loader2, ChevronRight, Sparkles } from 'lucide-react';
import { base44 } from '@/api/base44Client';

const LEVEL_ORDER = ['A1', 'A2', 'B1', 'B2', 'C1', 'C2'];
const TEST_LENGTH = 12;

export default function PlacementTest({ language, onComplete }) {
  const [phase, setPhase] = useState('loading');
  const [pool, setPool] = useState([]);
  const [pos, setPos] = useState(7);
  const [current, setCurrent] = useState(null);
  const [selected, setSelected] = useState(null);
  const [history, setHistory] = useState([]);
  const [results, setResults] = useState(null);

  useEffect(() => {
    generateQuestions();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const generateQuestions = async () => {
    setPhase('loading');
    try {
      const res = await base44.integrations.Core.InvokeLLM({
        prompt: `You are a language assessment expert for ${language} learners. Generate 15 multiple-choice placement questions spanning CEFR levels A1, A2, B1, B2, C1, C2 (about 2-3 per level, ordered from easiest to hardest). Mix the skills: grammar, vocabulary, reading. Keep each prompt short and clear. Each question must have exactly 4 options and the correct option index (0-3).`,
        response_json_schema: {
          type: 'object',
          properties: {
            questions: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  prompt: { type: 'string' },
                  options: { type: 'array', items: { type: 'string' } },
                  answer_index: { type: 'number' },
                  level: { type: 'string' },
                  skill: { type: 'string' },
                },
                required: ['prompt', 'options', 'answer_index', 'level', 'skill'],
              },
            },
          },
        },
      });
      const qs = (res.questions || []).filter((q) => q.options?.length === 4);
      if (qs.length < 6) throw new Error('not enough questions');
      const sorted = qs.sort((a, b) => LEVEL_ORDER.indexOf(a.level) - LEVEL_ORDER.indexOf(b.level));
      setPool(sorted);
      const start = Math.min(7, sorted.length - 1);
      setPos(start);
      setCurrent(sorted[start]);
      setPhase('test');
    } catch (e) {
      setPool([]);
      setPhase('test');
      setCurrent(null);
    }
  };

  const answer = (optIdx) => {
    if (selected !== null || !current) return;
    setSelected(optIdx);
    const correct = optIdx === current.answer_index;
    const entry = { correct, level: current.level, skill: current.skill };
    setHistory((h) => {
      const nh = [...h, entry];
      if (nh.length >= TEST_LENGTH) {
        evaluate(nh);
      } else {
        setTimeout(() => {
          const nextPos = correct ? Math.min(pos + 1, pool.length - 1) : Math.max(pos - 1, 0);
          setPos(nextPos);
          setCurrent(pool[nextPos]);
          setSelected(null);
        }, 700);
      }
      return nh;
    });
  };

  const evaluate = async (hist) => {
    setPhase('evaluating');
    const summary = hist.map((h) => ({ level: h.level, skill: h.skill, correct: h.correct }));
    try {
      const res = await base44.integrations.Core.InvokeLLM({
        prompt: `A learner of ${language} took an adaptive placement test. Here are their answers (level, skill, whether correct): ${JSON.stringify(summary)}. Determine the learner's overall CEFR level (one of A1, A2, B1, B2, C1, C2). Identify strengths (skills with high accuracy) and areas to improve (skills with low accuracy, 2-4 items each). Recommend a starting lesson topic. Return JSON.`,
        response_json_schema: {
          type: 'object',
          properties: {
            level: { type: 'string' },
            level_name: { type: 'string' },
            strengths: { type: 'array', items: { type: 'string' } },
            areas_to_improve: { type: 'array', items: { type: 'string' } },
            recommended_lesson: { type: 'string' },
          },
        },
      });
      setResults(res);
    } catch (e) {
      setResults({
        level: 'B1',
        level_name: 'Intermediate',
        strengths: ['Vocabulary', 'Reading'],
        areas_to_improve: ['Grammar', 'Speaking'],
        recommended_lesson: 'B1 essentials: present perfect & conditionals',
      });
    }
    setPhase('result');
  };

  if (phase === 'loading') {
    return (
      <div className="fixed inset-0 z-50 bg-background flex flex-col items-center justify-center px-6">
        <Loader2 size={32} className="animate-spin text-primary mb-4" />
        <p className="text-sm font-semibold text-foreground/80">Preparing your placement test…</p>
        <p className="text-xs text-muted-foreground mt-1">Generating adaptive questions for {language}.</p>
      </div>
    );
  }

  if (phase === 'evaluating') {
    return (
      <div className="fixed inset-0 z-50 bg-background flex flex-col items-center justify-center px-6">
        <Loader2 size={32} className="animate-spin text-primary mb-4" />
        <p className="text-sm font-semibold text-foreground/80">Calculating your level…</p>
      </div>
    );
  }

  if (phase === 'result' && results) {
    return (
      <div className="fixed inset-0 z-50 bg-background overflow-y-auto">
        <div className="min-h-full px-6 pt-14 pb-10 flex flex-col">
          <motion.div initial={{ scale: 0.6, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ type: 'spring', duration: 0.5 }} className="text-6xl text-center mb-3">🎉</motion.div>
          <h1 className="text-2xl font-extrabold text-center tracking-tight">Your placement test is complete!</h1>
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="mt-6 rounded-3xl p-6 bg-gradient-to-br from-primary to-secondary text-primary-foreground text-center shadow-card">
            <p className="text-xs font-bold uppercase tracking-widest opacity-80">Your estimated level</p>
            <p className="text-4xl font-extrabold mt-1">{results.level}</p>
            <p className="opacity-90 font-semibold mt-0.5">{results.level_name || ''}</p>
          </motion.div>

          <div className="mt-5 grid grid-cols-2 gap-3">
            <div className="rounded-2xl p-4 bg-card shadow-soft">
              <p className="text-xs font-bold text-green-600 uppercase tracking-wide mb-2">Strengths</p>
              <ul className="space-y-1.5">
                {(results.strengths || []).map((s) => (
                  <li key={s} className="flex items-center gap-2 text-sm font-medium">
                    <Check size={14} className="text-green-600" /> {s}
                  </li>
                ))}
              </ul>
            </div>
            <div className="rounded-2xl p-4 bg-card shadow-soft">
              <p className="text-xs font-bold text-secondary uppercase tracking-wide mb-2">Areas to improve</p>
              <ul className="space-y-1.5">
                {(results.areas_to_improve || []).map((s) => (
                  <li key={s} className="flex items-center gap-2 text-sm font-medium">
                    <X size={14} className="text-secondary" /> {s}
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="mt-4 rounded-2xl p-4 bg-primary/5 border border-primary/15">
            <div className="flex items-center gap-2 mb-1">
              <Sparkles size={16} className="text-primary" />
              <p className="text-xs font-bold text-primary uppercase tracking-wide">Recommended start</p>
            </div>
            <p className="text-sm font-semibold">{results.recommended_lesson}</p>
          </div>

          <div className="flex-1" />
          <button
            onClick={() => onComplete({ level: results.level, level_name: results.level_name, results })}
            className="mt-6 w-full bg-primary text-primary-foreground rounded-2xl py-4 text-base font-bold shadow-card flex items-center justify-center gap-2 no-tap-highlight"
          >
            Continue <ChevronRight size={18} />
          </button>
        </div>
      </div>
    );
  }

  // test phase
  if (!current) {
    return (
      <div className="fixed inset-0 z-50 bg-background flex flex-col items-center justify-center px-6">
        <p className="text-sm font-semibold text-foreground/80">Couldn't generate questions.</p>
        <button onClick={() => onComplete({ level: 'B1', level_name: 'Intermediate' })} className="mt-4 text-primary font-bold">Skip</button>
      </div>
    );
  }

  const progress = (history.length / TEST_LENGTH) * 100;

  return (
    <div className="fixed inset-0 z-50 bg-background flex flex-col">
      <div className="pt-14 px-6">
        <div className="flex items-center justify-between mb-1">
          <p className="text-xs font-bold tracking-widest text-primary uppercase">Placement Test · {language}</p>
          <span className="text-xs font-semibold text-muted-foreground">{history.length}/{TEST_LENGTH}</span>
        </div>
        <div className="h-1.5 bg-muted rounded-full overflow-hidden">
          <motion.div className="h-full bg-gradient-to-r from-primary to-secondary rounded-full" animate={{ width: `${progress}%` }} transition={{ duration: 0.3 }} />
        </div>
      </div>

      <div className="flex-1 px-6 pt-6 pb-8 flex flex-col">
        <AnimatePresence mode="wait">
          <motion.div
            key={`${pos}-${history.length}`}
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -30 }}
            transition={{ duration: 0.3 }}
            className="flex-1 flex flex-col"
          >
            <div className="flex items-center gap-2 mb-3">
              <span className="text-xs font-bold bg-primary/10 text-primary px-2.5 py-1 rounded-full">{current.level}</span>
              <span className="text-xs font-semibold text-muted-foreground capitalize">{current.skill}</span>
            </div>
            <h2 className="text-xl font-extrabold leading-snug mb-6">{current.prompt}</h2>
            <div className="space-y-2.5">
              {current.options.map((opt, i) => {
                const isCorrect = selected !== null && i === current.answer_index;
                const isWrong = selected === i && i !== current.answer_index;
                return (
                  <button
                    key={i}
                    onClick={() => answer(i)}
                    disabled={selected !== null}
                    className={`w-full text-left p-4 rounded-2xl border-2 transition-all flex items-center justify-between no-tap-highlight ${
                      isCorrect ? 'border-green-500 bg-green-50' : isWrong ? 'border-destructive bg-destructive/5' : selected !== null ? 'border-transparent bg-card opacity-60' : 'border-transparent bg-card shadow-soft'
                    }`}
                  >
                    <span className="font-medium text-sm">{opt}</span>
                    {isCorrect && <Check size={18} className="text-green-600" />}
                    {isWrong && <X size={18} className="text-destructive" />}
                  </button>
                );
              })}
            </div>
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}
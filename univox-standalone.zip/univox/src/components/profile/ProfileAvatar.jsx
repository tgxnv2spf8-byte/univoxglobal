import { useRef, useState } from 'react';
import { Camera } from 'lucide-react';
import { base44 } from '@/api/base44Client';

export default function ProfileAvatar({ user, onUpdated }) {
  const fileRef = useRef(null);
  const [uploading, setUploading] = useState(false);

  const avatarUrl = user?.avatar_url;
  const initial = (user?.full_name || 'S')[0]?.toUpperCase();

  const handleFile = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      const updated = await base44.auth.updateMe({ avatar_url: file_url });
      onUpdated?.(updated);
    } catch (err) {
      console.error(err);
    } finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = '';
    }
  };

  return (
    <div className="relative w-24 h-24">
      <div className="w-24 h-24 rounded-full border-4 border-background overflow-hidden shadow-float bg-card flex items-center justify-center">
        {avatarUrl ? (
          <img src={avatarUrl} alt={user?.full_name || 'Avatar'} className="w-full h-full object-cover" />
        ) : initial ? (
          <span className="text-4xl font-extrabold text-primary">{initial}</span>
        ) : (
          <img
            src="https://images.unsplash.com/photo-1544717305-2782549b5136?w=200&q=80&auto=format"
            alt=""
            className="w-full h-full object-cover"
          />
        )}
      </div>
      <button
        onClick={() => fileRef.current?.click()}
        disabled={uploading}
        className="absolute bottom-0 right-0 w-9 h-9 rounded-full bg-primary text-primary-foreground flex items-center justify-center shadow-lg border-2 border-background no-tap-highlight disabled:opacity-50"
        aria-label="Change avatar"
      >
        <Camera size={16} />
      </button>
      <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={handleFile} />
    </div>
  );
}
import { useState } from 'react';
import { Switch } from '@/components/ui/switch';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { Mail, MessageCircle, Globe, Check, Trash2, Loader2, Sun, Moon } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useTheme } from '@/lib/theme';
import IOSSelect from '@/components/IOSSelect';

function ToggleRow({ label, desc, defaultOn }) {
  const [on, setOn] = useState(defaultOn);
  return (
    <div className="flex items-center justify-between py-3">
      <div className="flex-1 pr-3">
        <p className="text-sm font-medium">{label}</p>
        {desc && <p className="text-xs text-muted-foreground mt-0.5">{desc}</p>}
      </div>
      <Switch checked={on} onCheckedChange={setOn} />
    </div>
  );
}

function LanguagePanel() {
  const [lang, setLang] = useState('en');
  const languages = [
    { code: 'en', label: 'English' },
    { code: 'es', label: 'Español' },
    { code: 'fr', label: 'Français' },
  ];
  return (
    <div className="py-1">
      <IOSSelect value={lang} onChange={setLang} className="w-full text-sm" options={languages.map((l) => ({ value: l.code, label: l.label }))} />
    </div>
  );
}

function DeleteAccount() {
  const [open, setOpen] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [done, setDone] = useState(false);

  const confirm = async () => {
    setDeleting(true);
    try {
      const me = await base44.auth.me();
      if (me?.id) await base44.entities.User.delete(me.id).catch(() => {});
    } catch (e) {}
    setDeleting(false);
    setDone(true);
    setTimeout(() => base44.auth.logout('/'), 800);
  };

  return (
    <AlertDialog open={open} onOpenChange={setOpen}>
      <AlertDialogTrigger asChild>
        <button className="w-full flex items-center justify-center gap-2 bg-destructive/10 text-destructive rounded-xl py-3 text-sm font-bold no-tap-highlight">
          <Trash2 size={16} /> Delete Account
        </button>
      </AlertDialogTrigger>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Delete your account?</AlertDialogTitle>
          <AlertDialogDescription>
            This action is permanent and cannot be undone. You will immediately lose all student achievements, certificates, and active program enrollments.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel disabled={deleting}>Cancel</AlertDialogCancel>
          <AlertDialogAction
            disabled={deleting || done}
            onClick={(e) => { e.preventDefault(); confirm(); }}
            className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
          >
            {deleting ? <Loader2 size={14} className="animate-spin" /> : done ? 'Deleted' : 'Delete forever'}
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}

function AppearancePanel() {
  const { theme, setTheme } = useTheme();
  const options = [
    { id: 'light', label: 'Light', icon: Sun, color: '#FFD84D' },
    { id: 'dark', label: 'Dark', icon: Moon, color: '#1E4DFF' },
  ];
  return (
    <div className="space-y-3 py-1">
      <p className="text-xs text-muted-foreground">Choose how UNIVOX looks to you.</p>
      <div className="grid grid-cols-2 gap-3">
        {options.map((o) => {
          const active = theme === o.id;
          const I = o.icon;
          return (
            <button
              key={o.id}
              onClick={() => setTheme(o.id)}
              className={`rounded-2xl p-4 flex flex-col items-center gap-2 border-2 transition-all no-tap-highlight ${active ? 'border-primary bg-primary/5' : 'border-transparent bg-muted/40'}`}
            >
              <div className="w-11 h-11 rounded-xl flex items-center justify-center" style={{ background: `${o.color}15` }}>
                <I size={20} style={{ color: o.color }} />
              </div>
              <p className="text-sm font-semibold">{o.label}</p>
              {active && <p className="text-[10px] text-primary font-bold">Active</p>}
            </button>
          );
        })}
      </div>
    </div>
  );
}

export default function SettingPanelContent({ type, userEmail }) {
  if (type === 'Notifications') {
    return (
      <div className="divide-y divide-border/40">
        <ToggleRow label="Lesson reminders" desc="Get notified before your lessons" defaultOn />
        <ToggleRow label="Group messages" desc="Messages from your study groups" defaultOn />
        <ToggleRow label="Announcements" desc="Important updates from UNIVOX" defaultOn />
        <ToggleRow label="Sound" desc="Play sound for new notifications" defaultOn={false} />
      </div>
    );
  }
  if (type === 'Language') return <LanguagePanel />;
  if (type === 'Appearance') return <AppearancePanel />;
  if (type === 'Privacy') {
    return (
      <div className="divide-y divide-border/40">
        <ToggleRow label="Public profile" desc="Allow others to see your profile" defaultOn />
        <ToggleRow label="Online status" desc="Show when you're active" defaultOn />
        <ToggleRow label="Read receipts" desc="Show others when you read messages" defaultOn={false} />
      </div>
    );
  }
  if (type === 'Account') {
    return (
      <div className="space-y-3 py-1">
        <div className="bg-muted/40 rounded-xl p-3">
          <p className="text-xs text-muted-foreground">Email</p>
          <p className="text-sm font-medium mt-0.5 break-all">{userEmail || '—'}</p>
        </div>
        <div className="bg-muted/40 rounded-xl p-3">
          <p className="text-xs text-muted-foreground">Plan</p>
          <p className="text-sm font-medium mt-0.5">UNIVOX Premium (active)</p>
        </div>
        <div className="pt-2">
          <DeleteAccount />
          <p className="text-[11px] text-muted-foreground text-center mt-2 leading-relaxed">Permanently remove your account, achievements and enrollments.</p>
        </div>
      </div>
    );
  }
  if (type === 'Help') {
    return (
      <div className="space-y-3 py-1">
        <div className="bg-gradient-to-br from-primary/10 to-secondary/10 rounded-xl p-4">
          <p className="text-sm font-semibold">Need help? Reach the creators.</p>
          <p className="text-xs text-muted-foreground mt-1 leading-relaxed">Contact us directly — we're happy to help.</p>
        </div>
        <a href="mailto:sofia.molok@icloud.com" className="flex items-center gap-3 bg-card rounded-xl p-3.5 shadow-soft no-tap-highlight">
          <div className="w-9 h-9 rounded-lg bg-primary/15 flex items-center justify-center"><Mail size={16} className="text-primary" /></div>
          <div className="flex-1">
            <p className="text-sm font-medium">Sophia</p>
            <p className="text-xs text-muted-foreground">sofia.molok@icloud.com · Creator</p>
          </div>
        </a>
        <a href="mailto:campios@icloud.com" className="flex items-center gap-3 bg-card rounded-xl p-3.5 shadow-soft no-tap-highlight">
          <div className="w-9 h-9 rounded-lg bg-secondary/15 flex items-center justify-center"><Mail size={16} className="text-secondary" /></div>
          <div className="flex-1">
            <p className="text-sm font-medium">Stefania</p>
            <p className="text-xs text-muted-foreground">campios@icloud.com · Creator</p>
          </div>
        </a>
      </div>
    );
  }
  return null;
}
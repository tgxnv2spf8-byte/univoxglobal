import { Clock, Crown, Lock } from 'lucide-react';

export default function TrialAccessCard() {
  return (
    <div className="bg-gradient-to-br from-primary/10 to-secondary/10 border border-primary/15 rounded-3xl p-4 shadow-soft">
      <div className="flex items-center gap-2 mb-2">
        <Clock size={16} className="text-primary" />
        <p className="text-sm font-bold">14-Day Free Trial</p>
        <span className="ml-auto text-[10px] font-bold bg-green-500/15 text-green-600 rounded-full px-2 py-0.5">FREE NOW</span>
      </div>
      <p className="text-xs text-muted-foreground leading-relaxed">
        Join this community free for 14 days. After the trial, access to lessons is limited until you subscribe.
      </p>
      <div className="mt-3 flex items-center justify-between gap-2">
        <span className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
          <Lock size={12} /> Limited access after 14 days
        </span>
        <button
          disabled
          className="flex items-center gap-1.5 rounded-xl px-3 py-2 text-xs font-bold bg-muted text-muted-foreground no-tap-highlight cursor-not-allowed"
        >
          <Crown size={13} /> Subscription coming soon
        </button>
      </div>
    </div>
  );
}
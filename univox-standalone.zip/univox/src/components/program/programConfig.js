import { BigBen, EiffelTower, PalmTree, Sailboat, Pagoda, OnionDome, Flask, Atom } from './silhouettes';

export const programs = [
  { slug: 'english', title: 'English', Silhouette: BigBen, color: '#1E4DFF', flag: '🇬🇧', description: "The world's language. Connect anywhere, with anyone." },
  { slug: 'french', title: 'French', Silhouette: EiffelTower, color: '#FF6FAE', flag: '🇫🇷', description: 'The language of love, art and elegance.' },
  { slug: 'spanish', title: 'Spanish', Silhouette: PalmTree, color: '#FFD84D', flag: '🇪🇸', description: 'Vibrant and warm, spoken across two continents.' },
  { slug: 'portuguese', title: 'Portuguese', Silhouette: Sailboat, color: '#FF8A3D', flag: '🇵🇹', description: 'The language of explorers and ocean rhythms.' },
  { slug: 'chinese', title: 'Chinese', Silhouette: Pagoda, color: '#1E4DFF', flag: '🇨🇳', description: 'Ancient and modern — the language of the future.' },
  { slug: 'russian', title: 'Russian', Silhouette: OnionDome, color: '#FF6FAE', flag: '🇷🇺', description: 'A vast culture across eleven time zones.' },
  { slug: 'science', title: 'Science', Silhouette: Flask, color: '#FFD84D', flag: '🔬', description: 'Discover how the world really works.' },
  { slug: 'research', title: 'Research', Silhouette: Atom, color: '#FF8A3D', flag: '🔬', description: 'Dive deep into frontier science projects.' },
];

export const getProgram = (slug) => programs.find((p) => p.slug === slug);
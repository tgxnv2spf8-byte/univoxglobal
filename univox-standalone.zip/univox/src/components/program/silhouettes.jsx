// Black landmark silhouettes for program cards. viewBox 0 0 64 64.
// Use fill="currentColor" — set text color to black/tint on colored cards.

export function BigBen({ className }) {
  return (
    <svg viewBox="0 0 64 64" className={className} fill="currentColor" xmlns="http://www.w3.org/2000/svg">
      <path fillRule="evenodd" d="M32 4 L37 16 H34 V18 H39 V60 H25 V18 H30 V16 H27 Z M32 27 m-4.5 0 a4.5 4.5 0 1 0 9 0 a4.5 4.5 0 1 0 -9 0 M30 42 h4 v6 h-4 z" />
    </svg>
  );
}

export function EiffelTower({ className }) {
  return (
    <svg viewBox="0 0 64 64" className={className} fill="currentColor" xmlns="http://www.w3.org/2000/svg">
      <path fillRule="evenodd" d="M32 3 L30 13 L28 21 L25 30 L20 42 L24 42 L26.5 36 L37.5 36 L40 42 L44 42 L39 30 L36 21 L34 13 Z M18 42 L23 62 L27 62 L27 53 L37 53 L37 62 L41 62 L46 42 Z M27.5 53 L32 46 L36.5 53 Z" />
    </svg>
  );
}

export function PalmTree({ className }) {
  return (
    <svg viewBox="0 0 64 64" className={className} fill="currentColor" xmlns="http://www.w3.org/2000/svg">
      <path d="M30 60 L34 60 L33 28 L31 28 Z M32 27 Q22 28 9 36 Q21 29 32 27 Z M32 27 Q19 20 7 16 Q20 22 32 27 Z M32 27 Q25 14 20 6 Q29 16 32 27 Z M32 27 Q33 12 36 4 Q36 16 32 27 Z M32 27 Q39 14 44 6 Q35 16 32 27 Z M32 27 Q45 20 57 16 Q44 22 32 27 Z M32 27 Q42 28 55 36 Q43 29 32 27 Z" />
    </svg>
  );
}

export function Sailboat({ className }) {
  return (
    <svg viewBox="0 0 64 64" className={className} fill="currentColor" xmlns="http://www.w3.org/2000/svg">
      <path d="M6 44 H58 L50 56 H14 Z M31 12 H33 V44 H31 Z M34 14 L34 42 L51 42 Z M30 14 L30 42 L19 42 Z M31 7 H34 V10 H31 Z" />
    </svg>
  );
}

export function Pagoda({ className }) {
  return (
    <svg viewBox="0 0 64 64" className={className} fill="currentColor" xmlns="http://www.w3.org/2000/svg">
      <path d="M30 2 H34 L40 10 H24 Z M29 10 H35 V15 H29 Z M22 15 H42 L48 25 H16 Z M27 25 H37 V31 H27 Z M12 31 H52 L60 45 H4 Z M26 45 H38 V52 H26 Z M24 52 H40 V58 H24 Z" />
    </svg>
  );
}

export function OnionDome({ className }) {
  return (
    <svg viewBox="0 0 64 64" className={className} fill="currentColor" xmlns="http://www.w3.org/2000/svg">
      <path d="M32 6 C22 6 18 20 24 29 L24 34 H40 L40 29 C46 20 42 6 32 6 Z M31 1 H33 V4 H36 V6 H33 V9 H31 V6 H28 V4 H31 Z M24 34 H40 V58 H24 Z M22 58 H42 V62 H22 Z" />
    </svg>
  );
}

export function Flask({ className }) {
  return (
    <svg viewBox="0 0 64 64" className={className} fill="currentColor" xmlns="http://www.w3.org/2000/svg">
      <path fillRule="evenodd" d="M28 8 H36 V22 L46 52 Q47 58 41 58 H23 Q17 58 18 52 L28 22 Z M29 8 H35 V6 H29 Z M34 40 m-2 0 a2 2 0 1 0 4 0 a2 2 0 1 0 -4 0" />
    </svg>
  );
}

export function Atom({ className }) {
  return (
    <svg viewBox="0 0 64 64" className={className} fill="none" stroke="currentColor" strokeWidth="3" xmlns="http://www.w3.org/2000/svg">
      <circle cx="32" cy="32" r="5" fill="currentColor" stroke="none" />
      <ellipse cx="32" cy="32" rx="24" ry="10" />
      <ellipse cx="32" cy="32" rx="24" ry="10" transform="rotate(60 32 32)" />
      <ellipse cx="32" cy="32" rx="24" ry="10" transform="rotate(120 32 32)" />
    </svg>
  );
}
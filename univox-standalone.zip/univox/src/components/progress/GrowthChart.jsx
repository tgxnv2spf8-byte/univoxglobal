import { ComposedChart, Bar, Line, XAxis, YAxis, ResponsiveContainer, Tooltip, CartesianGrid } from 'recharts';

const renderDot = (data) => (props) => {
  const { cx, cy, index } = props;
  if (index === data.length - 1) {
    return (
      <g key={`dot-${index}`}>
        <circle cx={cx} cy={cy} r={10} fill="#FF6FAE" stroke="#fff" strokeWidth={2.5} />
        <path d={`M${cx} ${cy - 4.5} L${cx - 3.5} ${cy + 1.5} L${cx + 3.5} ${cy + 1.5} Z`} fill="#fff" />
      </g>
    );
  }
  return <circle key={`dot-${index}`} cx={cx} cy={cy} r={4} fill="#fff" stroke="#FF6FAE" strokeWidth={2.5} />;
};

export default function GrowthChart({ data }) {
  const maxVal = Math.max(...data.map((d) => d.hours), 1);
  return (
    <ResponsiveContainer width="100%" height={200}>
      <ComposedChart data={data} barCategoryGap="32%" margin={{ top: 10, right: 6, left: 6, bottom: 0 }}>
        <defs>
          <linearGradient id="growthBar" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#FF6FAE" />
            <stop offset="100%" stopColor="#1E4DFF" />
          </linearGradient>
          <linearGradient id="growthLine" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor="#1E4DFF" />
            <stop offset="100%" stopColor="#FF6FAE" />
          </linearGradient>
        </defs>
        <CartesianGrid vertical={false} stroke="rgba(0,0,0,0.05)" />
        <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: '#9ca3af' }} />
        <YAxis hide domain={[0, maxVal * 1.25]} />
        <Tooltip
          cursor={{ fill: 'rgba(255, 111, 174, 0.06)' }}
          contentStyle={{ borderRadius: 14, border: 'none', boxShadow: '0 6px 24px rgba(0,0,0,0.12)', fontSize: 12, fontWeight: 600 }}
          formatter={(v) => [`${v}h`, 'Hours']}
        />
        <Bar dataKey="hours" fill="url(#growthBar)" radius={[10, 10, 0, 0]} animationDuration={900} />
        <Line dataKey="hours" stroke="url(#growthLine)" strokeWidth={3} dot={renderDot(data)} activeDot={{ r: 6, fill: '#FF6FAE', stroke: '#fff', strokeWidth: 2 }} animationDuration={1100} />
      </ComposedChart>
    </ResponsiveContainer>
  );
}
import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown, Save, Plus, FileText, Megaphone, Users, Check, X, Loader2, Video, Clock } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import IOSSelect from '@/components/IOSSelect';

const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
const SUBTABS = ['Info', 'Materials', 'Announcements', 'Students'];

export default function ManagedGroupCard({ group }) {
  const [open, setOpen] = useState(false);
  const [tab, setTab] = useState('Info');
  const [form, setForm] = useState({ name: group.name, level: group.level || 'B1', day_of_week: group.day_of_week || 'Monday', time: group.time || '18:00', meet_link: group.meet_link || '' });
  const [saving, setSaving] = useState(false);

  const save = async () => {
    setSaving(true);
    await base44.entities.Group.update(group.id, { ...form });
    setSaving(false);
  };

  return (
    <div className="bg-card rounded-3xl shadow-soft overflow-hidden">
      <button onClick={() => setOpen((o) => !o)} className="w-full flex items-center gap-3 p-4 no-tap-highlight">
        <div className="w-11 h-11 rounded-2xl bg-primary/10 flex items-center justify-center"><Users size={18} className="text-primary" /></div>
        <div className="flex-1 text-left min-w-0">
          <p className="font-bold text-sm truncate">{group.name}</p>
          <p className="text-xs text-muted-foreground">{group.program_title} · {group.level} · {group.day_of_week} {group.time}</p>
        </div>
        <ChevronDown size={18} className={`text-muted-foreground/50 transition-transform ${open ? 'rotate-180' : ''}`} />
      </button>

      <AnimatePresence>
        {open && (
          <motion.div initial={{ height: 0 }} animate={{ height: 'auto' }} exit={{ height: 0 }} className="overflow-hidden">
            <div className="px-4 pb-4">
              <div className="flex gap-1.5 mb-4">
                {SUBTABS.map((s) => (
                  <button key={s} onClick={() => setTab(s)} className={`flex-1 py-1.5 rounded-lg text-[11px] font-bold no-tap-highlight ${tab === s ? 'bg-primary text-primary-foreground' : 'bg-muted/50 text-muted-foreground'}`}>{s}</button>
                ))}
              </div>

              {tab === 'Info' && (
                <div className="space-y-3">
                  <Labeled label="Group name"><input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="tinput" /></Labeled>
                  <div className="grid grid-cols-2 gap-2.5">
                    <Labeled label="Level"><input value={form.level} onChange={(e) => setForm({ ...form, level: e.target.value })} className="tinput" /></Labeled>
                    <Labeled label="Day">
                      <IOSSelect value={form.day_of_week} onChange={(v) => setForm({ ...form, day_of_week: v })} options={DAYS.map((d) => ({ value: d, label: d }))} className="tinput w-full" />
                    </Labeled>
                    <Labeled label="Time"><input value={form.time} onChange={(e) => setForm({ ...form, time: e.target.value })} className="tinput" /></Labeled>
                    <Labeled label="Members"><div className="tinput opacity-60">{group.member_count || 0}</div></Labeled>
                  </div>
                  <Labeled label="Google Meet link">
                    <div className="relative">
                      <Video size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-primary" />
                      <input value={form.meet_link} onChange={(e) => setForm({ ...form, meet_link: e.target.value })} placeholder="https://meet.google.com/..." className="tinput pl-9" />
                    </div>
                  </Labeled>
                  <button onClick={save} disabled={saving} className="w-full bg-primary text-primary-foreground rounded-xl py-2.5 text-xs font-bold flex items-center justify-center gap-1.5 disabled:opacity-50 no-tap-highlight">
                    {saving ? <Loader2 size={14} className="animate-spin" /> : <Save size={14} />} Save changes
                  </button>
                </div>
              )}

              {tab === 'Materials' && <MaterialsTab group={group} />}
              {tab === 'Announcements' && <AnnouncementsTab group={group} />}
              {tab === 'Students' && <StudentsTab group={group} />}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      <style>{`.tinput{width:100%;background:hsl(var(--background));border-radius:0.75rem;padding:0.55rem 0.75rem;font-size:0.8rem;font-weight:500;outline:none;border:1px solid hsl(var(--border)/0.5)}`}</style>
    </div>
  );
}

function Labeled({ label, children }) {
  return <div><p className="text-[10px] font-bold text-foreground/60 uppercase mb-1">{label}</p>{children}</div>;
}

function MaterialsTab({ group }) {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);

  const load = () => base44.entities.GroupMaterial.filter({ group_id: group.id }).then(setItems).catch(() => {}).finally(() => setLoading(false));
  useEffect(() => { load(); }, []);

  const upload = async (e) => {
    const f = e.target.files?.[0];
    if (!f) return;
    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file: f });
      await base44.entities.GroupMaterial.create({ group_id: group.id, title: f.name, file_url, type: f.name.split('.').pop().toUpperCase() });
      load();
    } finally { setUploading(false); e.target.value = ''; }
  };

  return (
    <div>
      <label className="w-full flex items-center justify-center gap-1.5 bg-primary/10 text-primary rounded-xl py-2.5 text-xs font-bold cursor-pointer no-tap-highlight">
        {uploading ? <Loader2 size={14} className="animate-spin" /> : <Plus size={14} />} Upload material
        <input type="file" className="hidden" onChange={upload} />
      </label>
      <div className="mt-3 space-y-2">
        {items.length === 0 && !loading && <p className="text-xs text-muted-foreground text-center py-3">No materials yet</p>}
        {items.map((m) => (
          <a key={m.id} href={m.file_url} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2.5 bg-background rounded-xl p-2.5 no-tap-highlight">
            <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center"><FileText size={14} className="text-primary" /></div>
            <p className="text-xs font-medium truncate flex-1">{m.title}</p>
            <span className="text-[9px] font-bold text-muted-foreground">{m.type}</span>
          </a>
        ))}
      </div>
    </div>
  );
}

function AnnouncementsTab({ group }) {
  const [items, setItems] = useState([]);
  const [title, setTitle] = useState('');
  const [desc, setDesc] = useState('');
  const [posting, setPosting] = useState(false);

  const load = () => base44.entities.Announcement.filter({ group_id: group.id }).then(setItems).catch(() => {});
  useEffect(() => { load(); }, []);

  const post = async () => {
    if (!title.trim()) return;
    setPosting(true);
    await base44.entities.Announcement.create({ title: title.trim(), description: desc.trim(), group_id: group.id, type: 'teacher', date: new Date().toLocaleDateString() });
    setTitle(''); setDesc(''); setPosting(false); load();
  };

  return (
    <div>
      <div className="space-y-2">
        <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Announcement title" className="tinput" />
        <textarea value={desc} onChange={(e) => setDesc(e.target.value)} placeholder="Details..." rows={2} className="tinput resize-none" />
      </div>
      <button onClick={post} disabled={posting || !title.trim()} className="w-full mt-2.5 bg-primary text-primary-foreground rounded-xl py-2.5 text-xs font-bold flex items-center justify-center gap-1.5 disabled:opacity-50 no-tap-highlight">
        <Megaphone size={14} /> Post
      </button>
      <div className="mt-3 space-y-2">
        {items.map((a) => (
          <div key={a.id} className="bg-background rounded-xl p-2.5">
            <p className="text-xs font-bold">{a.title}</p>
            {a.description && <p className="text-[11px] text-muted-foreground mt-0.5">{a.description}</p>}
          </div>
        ))}
      </div>
    </div>
  );
}

function StudentsTab({ group }) {
  const [apps, setApps] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = () => base44.entities.Application.filter({ group_name: group.name }).then((a) => setApps(a || [])).catch(() => {}).finally(() => setLoading(false));
  useEffect(() => { load(); }, []);

  const accept = async (app) => {
    await base44.entities.Application.update(app.id, { status: 'approved' });
    await base44.entities.Group.update(group.id, { member_count: (group.member_count || 0) + 1 });
    load();
  };
  const remove = async (app) => {
    if (!confirm('Remove this student?')) return;
    await base44.entities.Application.update(app.id, { status: 'rejected' });
    await base44.entities.Group.update(group.id, { member_count: Math.max(0, (group.member_count || 0) - 1) });
    load();
  };

  const members = apps.filter((a) => a.status === 'approved');
  const pending = apps.filter((a) => a.status === 'pending');

  return (
    <div>
      {pending.length > 0 && (
        <div className="mb-3">
          <p className="text-[10px] font-bold text-foreground/60 uppercase mb-1.5">Pending · {pending.length}</p>
          <div className="space-y-2">
            {pending.map((a) => (
              <div key={a.id} className="flex items-center gap-2 bg-background rounded-xl p-2.5">
                <p className="text-xs font-medium flex-1 truncate">{a.created_by_id?.slice(-6) || 'Applicant'}</p>
                <button onClick={() => accept(a)} className="w-7 h-7 rounded-lg bg-green-500 text-white flex items-center justify-center no-tap-highlight"><Check size={13} /></button>
                <button onClick={() => remove(a)} className="w-7 h-7 rounded-lg bg-destructive text-destructive-foreground flex items-center justify-center no-tap-highlight"><X size={13} /></button>
              </div>
            ))}
          </div>
        </div>
      )}
      <p className="text-[10px] font-bold text-foreground/60 uppercase mb-1.5">Members · {members.length}</p>
      <div className="space-y-2">
        {members.length === 0 && !loading && <p className="text-xs text-muted-foreground text-center py-3">No students yet</p>}
        {members.map((a) => (
          <div key={a.id} className="flex items-center gap-2 bg-background rounded-xl p-2.5">
            <Users size={13} className="text-muted-foreground" />
            <p className="text-xs font-medium flex-1">Student</p>
            <button onClick={() => remove(a)} className="w-7 h-7 rounded-lg bg-destructive/10 text-destructive flex items-center justify-center no-tap-highlight"><X size={13} /></button>
          </div>
        ))}
      </div>
    </div>
  );
}
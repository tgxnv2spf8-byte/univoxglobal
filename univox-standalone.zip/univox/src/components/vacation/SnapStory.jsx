import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, ChevronLeft, MapPin } from 'lucide-react';

export default function SnapStory({ snap, onClose }) {
  const photos = (snap.photo_urls || '').split(',').filter(Boolean);
  const start = Math.min(Math.max(snap._start || 0, 0), Math.max(photos.length - 1, 0));
  const [index, setIndex] = useState(start);

  if (!photos.length) {
    onClose();
    return null;
  }

  const goNext = () => (index < photos.length - 1 ? setIndex(index + 1) : onClose());
  const goPrev = () => index > 0 && setIndex(index - 1);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[100] bg-black flex items-center justify-center"
    >
      {/* Progress bars */}
      <div className="absolute top-0 left-0 right-0 z-20 flex gap-1 px-3 pt-3">
        {photos.map((_, i) => (
          <div key={i} className="flex-1 h-1 rounded-full bg-white/25 overflow-hidden">
            <div className={`h-full bg-white transition-all duration-300 ${i <= index ? 'w-full' : 'w-0'}`} />
          </div>
        ))}
      </div>

      {/* Header */}
      <div className="absolute top-6 left-0 right-0 z-20 flex items-center gap-2 px-4">
        <span className="text-2xl">{snap.author_flag || '🌍'}</span>
        <div className="flex-1 min-w-0">
          <p className="text-white font-bold text-sm truncate">{snap.author_name || 'Traveler'}</p>
          <p className="text-white/80 text-xs flex items-center gap-1 truncate">
            <MapPin size={11} /> {snap.location}
          </p>
        </div>
        <button onClick={onClose} className="w-9 h-9 rounded-full bg-white/15 flex items-center justify-center no-tap-highlight">
          <X size={18} className="text-white" />
        </button>
      </div>

      {/* Photo with swipe */}
      <AnimatePresence mode="wait">
        <motion.img
          key={index}
          src={photos[index]}
          alt=""
          initial={{ opacity: 0, scale: 1.02 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.98 }}
          transition={{ duration: 0.25 }}
          drag="x"
          dragConstraints={{ left: 0, right: 0 }}
          onDragEnd={(e, info) => {
            if (info.offset.x < -60) goNext();
            else if (info.offset.x > 60) goPrev();
          }}
          className="max-w-full max-h-full object-contain"
        />
      </AnimatePresence>

      {/* Caption */}
      {snap.caption && (
        <div className="absolute bottom-10 left-0 right-0 z-20 px-6 text-center">
          <p className="text-white text-base font-medium drop-shadow-lg leading-relaxed">{snap.caption}</p>
        </div>
      )}

      {/* Tap zones */}
      <button onClick={goPrev} className="absolute left-0 top-0 bottom-0 w-1/4 z-10 no-tap-highlight" aria-label="Previous" />
      <button onClick={goNext} className="absolute right-0 top-0 bottom-0 w-1/4 z-10 no-tap-highlight" aria-label="Next" />

      {index > 0 && (
        <button onClick={goPrev} className="absolute left-3 top-1/2 -translate-y-1/2 z-20 w-10 h-10 rounded-full bg-white/15 flex items-center justify-center no-tap-highlight">
          <ChevronLeft size={22} className="text-white" />
        </button>
      )}
    </motion.div>
  );
}
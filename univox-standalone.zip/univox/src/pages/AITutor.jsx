import { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Send, ArrowLeft, Sparkles, Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';

export default function AITutor() {
  const navigate = useNavigate();
  const [messages, setMessages] = useState([
    { role: 'assistant', text: "Hi! I'm your AI Tutor. 🤖\nAsk me anything, request practice exercises, or tell me what you'd like to improve — I'll guide your learning." },
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef(null);

  useEffect(() => {
    scrollRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  const send = async () => {
    if (!input.trim() || loading) return;
    const userMsg = input.trim();
    setMessages((m) => [...m, { role: 'user', text: userMsg }]);
    setInput('');
    setLoading(true);
    try {
      const res = await base44.integrations.Core.InvokeLLM({
        prompt: `You are a friendly, encouraging AI language tutor inside the UNIVOX app. Help the learner with questions, practice, and study recommendations. Be concise, warm and practical. Use short paragraphs. Learner message: "${userMsg}"`,
      });
      const text = typeof res === 'string' ? res : res.response || res.text || res.output || 'Sorry, I could not generate a response.';
      setMessages((m) => [...m, { role: 'assistant', text }]);
    } catch (e) {
      setMessages((m) => [...m, { role: 'assistant', text: "Sorry, I couldn't respond right now. Please try again." }]);
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen max-w-md mx-auto flex flex-col bg-background relative">
      <header className="px-5 pt-[calc(0.75rem+var(--safe-top))] pb-3 flex items-center gap-3 border-b border-border/40 glass sticky top-0 z-10">
        <button onClick={() => navigate(-1)} className="w-9 h-9 rounded-full bg-card flex items-center justify-center shadow-soft no-tap-highlight">
          <ArrowLeft size={16} />
        </button>
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
            <Sparkles size={18} className="text-primary-foreground" />
          </div>
          <div>
            <p className="font-bold leading-tight">AI Tutor</p>
            <p className="text-xs text-muted-foreground">Personalized guidance, anytime</p>
          </div>
        </div>
      </header>

      <div className="flex-1 overflow-y-auto px-5 py-4 space-y-3 pb-32">
        {messages.map((m, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-[80%] rounded-3xl px-4 py-3 text-sm whitespace-pre-wrap leading-relaxed ${
                m.role === 'user'
                  ? 'bg-primary text-primary-foreground rounded-br-lg'
                  : 'bg-card shadow-soft rounded-bl-lg'
              }`}
            >
              {m.text}
            </div>
          </motion.div>
        ))}
        {loading && (
          <div className="flex items-center gap-2 text-muted-foreground text-sm">
            <Loader2 size={16} className="animate-spin" /> Thinking…
          </div>
        )}
        <div ref={scrollRef} />
      </div>

      <div className="fixed bottom-0 left-0 right-0 max-w-md mx-auto px-5 py-3 bg-glass border-t border-border/40">
        <div className="flex items-center gap-2">
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && send()}
            placeholder="Ask your tutor anything…"
            className="flex-1 bg-card rounded-full px-5 py-3 text-sm outline-none border border-transparent focus:border-primary/30 shadow-soft"
          />
          <button
            onClick={send}
            disabled={loading || !input.trim()}
            className="w-12 h-12 rounded-full bg-primary text-primary-foreground flex items-center justify-center shadow-card no-tap-highlight disabled:opacity-40"
          >
            <Send size={18} />
          </button>
        </div>
      </div>
    </div>
  );
}
import { useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ChevronLeft, Calendar, Link2, User, Star, Check, Loader2, Globe } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { CATEGORIES, LANGUAGES, categoryLabel, categoryEmoji } from '@/components/announcements/announcementConfig';

export default function AnnouncementDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [a, setA] = useState(null);
  const [group, setGroup] = useState(null);
  const [loading, setLoading] = useState(true);
  const [joined, setJoined] = useState(false);
  const [joining, setJoining] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const ann = await base44.entities.Announcement.get(id);
        setA(ann);
        if (ann.join_target_group_id) {
          const g = await base44.entities.Group.get(ann.join_target_group_id).catch(() => null);
          setGroup(g);
        }
        // increment views once
        base44.entities.Announcement.update(id, { views: (ann.views || 0) + 1 }).catch(() => {});
      } catch (e) {
        setA(null);
      }
      setLoading(false);
    })();
  }, [id]);

  const join = async () => {
    if (joining || joined) return;
    setJoining(true);
    try {
      if (group) {
        await base44.entities.Application.create({
          group_name: group.name,
          teacher: group.teacher || '',
          status: 'approved',
          program_name: group.program_title || '',
          day_of_week: group.day_of_week || '',
          time: group.time || '',
        }).catch(() => {});
        await base44.entities.Group.update(group.id, { member_count: (group.member_count || 0) + 1 }).catch(() => {});
      }
      await base44.entities.Announcement.update(a.id, {
        joins: (a.joins || 0) + 1,
        active_participants: (a.active_participants || 0) + 1,
      }).catch(() => {});
      setJoined(true);
    } catch (e) {
      alert('Could not join right now. Please try again.');
    }
    setJoining(false);
    if (a?.location_or_link && /^https?:\/\//i.test(a.location_or_link)) {
      window.open(a.location_or_link, '_blank', 'noopener');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen pb-28">
        <div className="h-56 skeleton" />
        <div className="px-5 mt-4 space-y-3"><div className="h-6 w-2/3 skeleton rounded" /><div className="h-4 w-full skeleton rounded" /><div className="h-4 w-4/5 skeleton rounded" /></div>
      </div>
    );
  }

  if (!a) {
    return (
      <div className="min-h-screen pb-28 flex flex-col items-center justify-center px-5 text-center">
        <p className="text-4xl mb-3">🔍</p>
        <p className="font-bold text-lg">Announcement not found</p>
        <Link to="/home" className="mt-5 bg-primary text-primary-foreground rounded-2xl px-6 py-3 text-sm font-bold no-tap-highlight">Back to Home</Link>
      </div>
    );
  }

  const lang = LANGUAGES.find((l) => l.id === a.language);
  const isExternalLink = a.location_or_link && /^https?:\/\//i.test(a.location_or_link);

  return (
    <div className="min-h-screen pb-28">
      <header className="absolute top-0 left-0 right-0 z-20 px-5 pt-12 pb-3">
        <button onClick={() => navigate(-1)} className="w-10 h-10 rounded-full glass-strong flex items-center justify-center shadow-soft no-tap-highlight"><ChevronLeft size={22} /></button>
      </header>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="relative h-56 bg-muted overflow-hidden"
      >
        {a.cover_image_url ? (
          <img src={a.cover_image_url} alt="" className="w-full h-full object-cover" />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-7xl bg-gradient-to-br from-primary/20 to-secondary/20">{categoryEmoji(a.category)}</div>
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
        <div className="absolute bottom-4 left-5 right-5 flex items-center gap-2 flex-wrap">
          <span className="text-[10px] font-bold bg-white/90 text-foreground rounded-full px-2.5 py-1">{categoryEmoji(a.category)} {categoryLabel(a.category)}</span>
          {a.featured && <span className="text-[10px] font-bold bg-accent text-accent-foreground rounded-full px-2.5 py-1 flex items-center gap-0.5"><Star size={10} className="fill-accent-foreground" /> Featured</span>}
          {lang && <span className="text-[10px] font-bold bg-black/50 text-white rounded-full px-2.5 py-1">{lang.flag} {lang.label}</span>}
        </div>
      </motion.div>

      <div className="px-5 -mt-4 relative">
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} className="bg-card rounded-3xl p-5 shadow-card">
          <h1 className="text-2xl font-extrabold tracking-tight leading-tight">{a.title}</h1>
          {a.short_description && <p className="text-muted-foreground text-sm mt-2">{a.short_description}</p>}

          <div className="flex flex-col gap-2 mt-4 text-sm">
            {a.teacher && (
              <div className="flex items-center gap-2 text-muted-foreground"><User size={15} className="text-primary" /> <span className="font-medium text-foreground">Teacher: {a.teacher}</span></div>
            )}
            {a.event_date && (
              <div className="flex items-center gap-2 text-muted-foreground"><Calendar size={15} className="text-primary" /> <span className="font-medium text-foreground">{new Date(a.event_date).toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' })}</span></div>
            )}
            {a.location_or_link && (
              <div className="flex items-center gap-2 text-muted-foreground"><Link2 size={15} className="text-primary" /> <span className="font-medium text-foreground break-all">{a.location_or_link}</span></div>
            )}
            <div className="flex items-center gap-2 text-muted-foreground"><Globe size={15} className="text-primary" /> <span className="font-medium text-foreground">{categoryLabel(a.category)}</span></div>
          </div>

          {a.full_description && (
            <div className="mt-5 pt-5 border-t border-border/40">
              <p className="text-sm leading-relaxed whitespace-pre-wrap">{a.full_description}</p>
            </div>
          )}

          <div className="mt-6">
            {joined ? (
              <div className="w-full bg-green-500/15 text-green-600 rounded-2xl py-3.5 font-bold flex items-center justify-center gap-2"><Check size={18} /> Joined{group ? ` ${group.name}` : ''}!</div>
            ) : (
              <button
                onClick={join}
                disabled={joining}
                className="w-full bg-primary text-primary-foreground rounded-2xl py-3.5 font-bold flex items-center justify-center gap-2 no-tap-highlight disabled:opacity-50"
              >
                {joining ? <Loader2 size={18} className="animate-spin" /> : null}
                {joining ? 'Joining…' : (a.join_button_label || 'Join')}
              </button>
            )}
            {group && !joined && <p className="text-xs text-muted-foreground text-center mt-2">You'll be added to <b>{group.name}</b>{isExternalLink ? ' and the meeting will open' : ''}.</p>}
          </div>

          <div className="flex items-center gap-4 mt-5 pt-4 border-t border-border/40 text-xs text-muted-foreground">
            <span>👁 {a.views || 0} views</span>
            <span>👥 {a.joins || 0} joins</span>
            <span>🧑‍🤝‍🧑 {a.active_participants || 0} participants</span>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
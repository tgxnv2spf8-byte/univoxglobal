import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { AnimatePresence } from 'framer-motion';
import { ChevronLeft, Plus, Megaphone, Eye, UserPlus, Layers, FileText } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { isAdminOrOwner } from '@/lib/roles';
import AnnouncementRow from '@/components/announcements/AnnouncementRow';
import AnnouncementEditor from '@/components/announcements/AnnouncementEditor';

const FILTERS = [
  { id: 'all', label: 'All' },
  { id: 'draft', label: 'Drafts' },
  { id: 'published', label: 'Published' },
  { id: 'scheduled', label: 'Scheduled' },
  { id: 'archived', label: 'Archived' },
];

export default function AnnouncementManager() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [items, setItems] = useState([]);
  const [groups, setGroups] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');
  const [editing, setEditing] = useState(null);
  const [showEditor, setShowEditor] = useState(false);

  useEffect(() => {
    base44.auth.me().then((u) => {
      setUser(u);
      if (!isAdminOrOwner(u)) navigate('/home');
    }).catch(() => navigate('/home'));
    load();
    const unsub = base44.entities.Announcement.subscribe(() => load());
    return () => unsub && unsub();
  }, []);

  const load = async () => {
    const [a, g] = await Promise.all([
      base44.entities.Announcement.list('-updated_date').catch(() => []),
      base44.entities.Group.list().catch(() => []),
    ]);
    setItems(a || []);
    setGroups(g || []);
    setLoading(false);
  };

  const openNew = () => { setEditing(null); setShowEditor(true); };
  const openEdit = (a) => { setEditing(a); setShowEditor(true); };

  const duplicate = async (a) => {
    const { id, created_date, updated_date, created_by_id, views, joins, active_participants, ...rest } = a;
    await base44.entities.Announcement.create({
      ...rest,
      title: `${a.title} (Copy)`,
      status: 'draft',
      views: 0,
      joins: 0,
      active_participants: 0,
      published_date: '',
    });
    load();
  };
  const publish = async (a) => {
    await base44.entities.Announcement.update(a.id, { status: 'published', published_date: new Date().toISOString() });
    load();
  };
  const unpublish = async (a) => {
    await base44.entities.Announcement.update(a.id, { status: 'draft' });
    load();
  };
  const archive = async (a) => {
    await base44.entities.Announcement.update(a.id, { status: 'archived' });
    load();
  };
  const remove = async (a) => {
    if (!confirm('Delete this announcement permanently?')) return;
    await base44.entities.Announcement.delete(a.id);
    load();
  };

  const filtered = items.filter((a) => (filter === 'all' ? true : a.status === filter));
  const stats = [
    { label: 'Total', value: items.length, icon: Layers, color: '#1E4DFF' },
    { label: 'Published', value: items.filter((a) => a.status === 'published').length, icon: FileText, color: '#22c55e' },
    { label: 'Views', value: items.reduce((s, a) => s + (a.views || 0), 0), icon: Eye, color: '#FF6FAE' },
    { label: 'Joins', value: items.reduce((s, a) => s + (a.joins || 0), 0), icon: UserPlus, color: '#FF8A3D' },
  ];

  if (!user) return null;

  return (
    <div className="min-h-screen pb-28">
      <header className="px-5 pt-12 pb-3 flex items-center gap-3">
        <button onClick={() => navigate('/owner')} className="w-10 h-10 rounded-full bg-card flex items-center justify-center no-tap-highlight"><ChevronLeft size={22} /></button>
        <div className="flex-1">
          <h1 className="text-2xl font-extrabold tracking-tight flex items-center gap-2"><Megaphone size={20} className="text-primary" /> Announcements</h1>
          <p className="text-muted-foreground text-xs">Manage content — syncs live to all users</p>
        </div>
        <button onClick={openNew} className="w-11 h-11 rounded-full bg-primary text-primary-foreground flex items-center justify-center shadow-card no-tap-highlight"><Plus size={22} /></button>
      </header>

      <div className="px-5 mt-2 grid grid-cols-4 gap-2.5">
        {stats.map((s) => (
          <div key={s.label} className="bg-card rounded-2xl p-3 text-center shadow-soft">
            <s.icon size={16} className="mx-auto" style={{ color: s.color }} />
            <p className="text-xl font-extrabold mt-1" style={{ color: s.color }}>{s.value}</p>
            <p className="text-[9px] text-muted-foreground font-medium">{s.label}</p>
          </div>
        ))}
      </div>

      <div className="px-5 mt-4 flex gap-1.5 overflow-x-auto scrollbar-hide">
        {FILTERS.map((f) => (
          <button key={f.id} onClick={() => setFilter(f.id)} className={`px-3.5 py-2 rounded-full text-xs font-bold whitespace-nowrap no-tap-highlight ${filter === f.id ? 'bg-primary text-primary-foreground' : 'bg-card text-muted-foreground'}`}>{f.label}</button>
        ))}
      </div>

      <div className="px-5 mt-4 space-y-2.5">
        {loading
          ? [1, 2, 3].map((i) => <div key={i} className="h-28 rounded-2xl skeleton" />)
          : filtered.length === 0
            ? <div className="text-center py-14"><p className="text-sm text-muted-foreground">No announcements here yet.</p></div>
            : filtered.map((a, i) => (
                <AnnouncementRow
                  key={a.id}
                  a={a}
                  index={i}
                  onEdit={openEdit}
                  onDuplicate={duplicate}
                  onPublish={publish}
                  onUnpublish={unpublish}
                  onArchive={archive}
                  onDelete={remove}
                />
              ))}
      </div>

      <AnimatePresence>
        {showEditor && (
          <AnnouncementEditor
            announcement={editing}
            groups={groups}
            onDone={() => { setShowEditor(false); setEditing(null); load(); }}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
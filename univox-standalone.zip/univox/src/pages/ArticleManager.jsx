import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, Plus, Trash2, X, Loader2, Check, Eye, EyeOff, FlaskConical } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { isOwner } from '@/lib/roles';
import { categories } from '@/components/journal/journalConfig';

const EMPTY = {
  title: '', subtitle: '', author_name: '', author_country: '', author_flag: '',
  author_age: '', author_program: '', category: 'science', cover_image_url: '',
  excerpt: '', content: '', reading_time_minutes: 5, pull_quote: '', references: '',
  featured: false, status: 'approved',
};

export default function ArticleManager() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [articles, setArticles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(EMPTY);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    base44.auth.me().then((u) => { setUser(u); if (!isOwner(u)) navigate('/home'); }).catch(() => navigate('/home'));
    load();
  }, []);

  const load = () => {
    setLoading(true);
    base44.entities.JournalArticle.list('-created_date', 100)
      .then(setArticles)
      .catch(() => setArticles([]))
      .finally(() => setLoading(false));
  };

  const openNew = () => { setForm(EMPTY); setEditing('new'); };
  const openEdit = (a) => { setForm({ ...EMPTY, ...a, author_age: a.author_age || '' }); setEditing(a); };

  const save = async () => {
    if (!form.title.trim() || !form.author_name.trim()) return;
    setSaving(true);
    const payload = {
      title: form.title.trim(),
      subtitle: form.subtitle,
      author_name: form.author_name.trim(),
      author_country: form.author_country,
      author_flag: form.author_flag,
      author_age: form.author_age ? Number(form.author_age) : null,
      author_program: form.author_program,
      category: form.category,
      cover_image_url: form.cover_image_url,
      excerpt: form.excerpt,
      content: form.content,
      reading_time_minutes: Number(form.reading_time_minutes) || 5,
      pull_quote: form.pull_quote,
      references: form.references,
      featured: !!form.featured,
      status: form.status,
    };
    try {
      if (editing === 'new') {
        await base44.entities.JournalArticle.create(payload);
      } else {
        await base44.entities.JournalArticle.update(editing.id, payload);
      }
      setEditing(null);
      load();
    } catch (e) {}
    setSaving(false);
  };

  const publish = async (a) => { await base44.entities.JournalArticle.update(a.id, { status: 'published' }); load(); };
  const unpublish = async (a) => { await base44.entities.JournalArticle.update(a.id, { status: 'approved' }); load(); };
  const remove = async (a) => { if (!confirm(`Delete "${a.title}"?`)) return; await base44.entities.JournalArticle.delete(a.id).catch(() => {}); load(); };

  if (!user) return null;

  return (
    <div className="min-h-screen pb-28">
      <header className="px-5 pt-[calc(0.75rem+var(--safe-top))] pb-3 flex items-center gap-3">
        <button onClick={() => navigate('/owner')} className="w-10 h-10 rounded-full bg-card flex items-center justify-center no-tap-highlight"><ChevronLeft size={22} /></button>
        <div>
          <h1 className="text-2xl font-extrabold tracking-tight flex items-center gap-2"><FlaskConical size={20} className="text-primary" /> Article Manager</h1>
          <p className="text-muted-foreground text-xs">Create & publish Research Magazine articles</p>
        </div>
      </header>

      <div className="px-5 mt-3">
        <button onClick={openNew} className="w-full bg-primary text-primary-foreground rounded-2xl p-4 flex items-center gap-3 shadow-card no-tap-highlight">
          <div className="w-11 h-11 rounded-xl bg-white/20 flex items-center justify-center"><Plus size={20} /></div>
          <div className="flex-1 text-left"><p className="font-bold text-sm">New Article</p><p className="text-xs opacity-80">Create a magazine article</p></div>
        </button>
      </div>

      <div className="px-5 mt-5 space-y-3">
        {loading ? (
          [1, 2, 3].map((i) => <div key={i} className="h-20 skeleton rounded-2xl" />)
        ) : articles.length === 0 ? (
          <div className="text-center py-12"><p className="text-sm text-muted-foreground">No articles yet — create your first one.</p></div>
        ) : (
          articles.map((a, i) => (
            <motion.div key={a.id} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.04 }} className="bg-card rounded-2xl p-3.5 shadow-soft">
              <div className="flex items-center gap-3">
                {a.cover_image_url ? <img src={a.cover_image_url} alt="" className="w-12 h-12 rounded-xl object-cover" /> : <div className="w-12 h-12 rounded-xl bg-primary/15 flex items-center justify-center"><FlaskConical size={18} className="text-primary" /></div>}
                <div className="flex-1 min-w-0">
                  <p className="font-bold text-sm truncate">{a.title}</p>
                  <p className="text-xs text-muted-foreground truncate">{a.author_name} · {a.category}</p>
                </div>
                <StatusBadge status={a.status} />
              </div>
              <div className="flex gap-1.5 mt-2.5">
                <button onClick={() => openEdit(a)} className="text-[10px] font-bold bg-primary/10 text-primary rounded-lg px-2.5 py-1 no-tap-highlight">Edit</button>
                {a.status === 'published' ? (
                  <button onClick={() => unpublish(a)} className="text-[10px] font-bold bg-muted text-muted-foreground rounded-lg px-2.5 py-1 no-tap-highlight flex items-center gap-1"><EyeOff size={11} /> Unpublish</button>
                ) : (
                  <button onClick={() => publish(a)} className="text-[10px] font-bold bg-green-500/15 text-green-600 rounded-lg px-2.5 py-1 no-tap-highlight flex items-center gap-1"><Eye size={11} /> Publish</button>
                )}
                <button onClick={() => remove(a)} className="text-[10px] font-bold bg-destructive/10 text-destructive rounded-lg px-2.5 py-1 no-tap-highlight flex items-center gap-1"><Trash2 size={11} /> Delete</button>
              </div>
            </motion.div>
          ))
        )}
      </div>

      <AnimatePresence>
        {editing && (
          <EditorSheet form={form} setForm={setForm} saving={saving} onClose={() => setEditing(null)} onSave={save} />
        )}
      </AnimatePresence>
    </div>
  );
}

function StatusBadge({ status }) {
  const map = { under_review: ['Review', 'bg-accent/20 text-accent-foreground'], approved: ['Approved', 'bg-primary/10 text-primary'], published: ['Published', 'bg-green-500/15 text-green-600'] };
  const [label, cls] = map[status] || map.under_review;
  return <span className={`text-[10px] font-bold rounded-full px-2.5 py-1 ${cls}`}>{label}</span>;
}

function EditorSheet({ form, setForm, saving, onClose, onSave }) {
  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-[100] flex items-end justify-center" style={{ background: 'rgba(0,0,0,0.5)' }} onClick={onClose}>
      <motion.div initial={{ y: '100%' }} animate={{ y: 0 }} exit={{ y: '100%' }} transition={{ type: 'spring', damping: 28, stiffness: 300 }} onClick={(e) => e.stopPropagation()} className="bg-background w-full max-w-md rounded-t-[2rem] p-5 pb-8 max-h-[92vh] overflow-y-auto">
        <div className="w-10 h-1 rounded-full bg-border mx-auto mb-4" />
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-extrabold">{form.id ? 'Edit Article' : 'New Article'}</h2>
          <button onClick={onClose} className="w-9 h-9 rounded-full bg-card flex items-center justify-center no-tap-highlight"><X size={18} /></button>
        </div>

        <div className="space-y-3">
          <Field label="Title"><input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} className="inp" /></Field>
          <Field label="Subtitle"><input value={form.subtitle} onChange={(e) => setForm({ ...form, subtitle: e.target.value })} className="inp" /></Field>
          <div className="grid grid-cols-2 gap-2">
            <Field label="Author name"><input value={form.author_name} onChange={(e) => setForm({ ...form, author_name: e.target.value })} className="inp" /></Field>
            <Field label="Author country"><input value={form.author_country} onChange={(e) => setForm({ ...form, author_country: e.target.value })} className="inp" /></Field>
          </div>
          <div className="grid grid-cols-3 gap-2">
            <Field label="Flag"><input value={form.author_flag} onChange={(e) => setForm({ ...form, author_flag: e.target.value })} placeholder="🇪🇸" className="inp" /></Field>
            <Field label="Age"><input type="number" value={form.author_age} onChange={(e) => setForm({ ...form, author_age: e.target.value })} className="inp" /></Field>
            <Field label="Program"><input value={form.author_program} onChange={(e) => setForm({ ...form, author_program: e.target.value })} className="inp" /></Field>
          </div>
          <Field label="Category">
            <div className="flex gap-1.5 flex-wrap">
              {categories.map((c) => (
                <button key={c.id} onClick={() => setForm({ ...form, category: c.id })} className={`px-3 py-1.5 rounded-full text-xs font-bold no-tap-highlight ${form.category === c.id ? 'bg-primary text-primary-foreground' : 'bg-card text-muted-foreground'}`}>{c.emoji} {c.label}</button>
              ))}
            </div>
          </Field>
          <Field label="Cover image URL"><input value={form.cover_image_url} onChange={(e) => setForm({ ...form, cover_image_url: e.target.value })} className="inp" /></Field>
          <Field label="Excerpt"><textarea value={form.excerpt} onChange={(e) => setForm({ ...form, excerpt: e.target.value })} rows={2} className="inp resize-none" /></Field>
          <Field label="Content"><textarea value={form.content} onChange={(e) => setForm({ ...form, content: e.target.value })} rows={6} className="inp resize-none" /></Field>
          <Field label="Pull quote"><input value={form.pull_quote} onChange={(e) => setForm({ ...form, pull_quote: e.target.value })} className="inp" /></Field>
          <Field label="References"><textarea value={form.references} onChange={(e) => setForm({ ...form, references: e.target.value })} rows={2} className="inp resize-none" /></Field>
          <div className="grid grid-cols-2 gap-2">
            <Field label="Reading time (min)"><input type="number" value={form.reading_time_minutes} onChange={(e) => setForm({ ...form, reading_time_minutes: e.target.value })} className="inp" /></Field>
            <Field label="Status">
              <div className="flex gap-1.5 flex-wrap">
                {[{ v: 'under_review', l: 'Review' }, { v: 'approved', l: 'Approved' }, { v: 'published', l: 'Published' }].map((s) => (
                  <button key={s.v} onClick={() => setForm({ ...form, status: s.v })} className={`px-3 py-1.5 rounded-full text-xs font-bold no-tap-highlight ${form.status === s.v ? 'bg-primary text-primary-foreground' : 'bg-card text-muted-foreground'}`}>{s.l}</button>
                ))}
              </div>
            </Field>
          </div>
          <label className="flex items-center gap-2 text-xs font-medium">
            <input type="checkbox" checked={form.featured} onChange={(e) => setForm({ ...form, featured: e.target.checked })} /> Featured article
          </label>
        </div>

        <button onClick={onSave} disabled={saving || !form.title.trim() || !form.author_name.trim()} className="mt-5 w-full bg-primary text-primary-foreground rounded-2xl py-3.5 font-bold text-sm flex items-center justify-center gap-2 disabled:opacity-40 no-tap-highlight">
          {saving ? <><Loader2 size={16} className="animate-spin" /> Saving...</> : <><Check size={16} /> Save Article</>}
        </button>
      </motion.div>
    </motion.div>
  );
}

function Field({ label, children }) {
  return (
    <div>
      <label className="text-xs font-bold text-foreground/70 uppercase tracking-wide block mb-1.5">{label}</label>
      {children}
    </div>
  );
}
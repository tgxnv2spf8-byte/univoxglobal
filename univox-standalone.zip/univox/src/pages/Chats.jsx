import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Search, Globe, Users, Plane, Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useUserProgress } from '@/lib/UserProgressContext';

const GLOBAL_CHAT_NAME = 'UNIVOX Students';

export default function Chats() {
  const navigate = useNavigate();
  const { joinedGroups } = useUserProgress();
  const [search, setSearch] = useState('');
  const [openingGlobal, setOpeningGlobal] = useState(false);

  const openGlobal = async () => {
    setOpeningGlobal(true);
    try {
      let chat = (await base44.entities.Chat.filter({ name: GLOBAL_CHAT_NAME }))[0];
      if (!chat) {
        chat = await base44.entities.Chat.create({
          name: GLOBAL_CHAT_NAME,
          chat_type: 'general',
          avatar_color: '#1E4DFF',
          last_message: 'Welcome to the UNIVOX community! 👋',
          last_message_time: 'now',
        });
      }
      navigate(`/chat/${chat.id}`);
    } catch (e) {}
    setOpeningGlobal(false);
  };

  const groups = joinedGroups || [];
  const filtered = groups.filter((g) => g.name?.toLowerCase().includes(search.toLowerCase()));
  const showGlobal = GLOBAL_CHAT_NAME.toLowerCase().includes(search.toLowerCase());

  return (
    <div className="min-h-screen pb-28">
      <header className="px-5 pt-[calc(0.75rem+var(--safe-top))] pb-2 flex items-start justify-between gap-3">
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight">Chats</h1>
          <p className="text-muted-foreground text-sm mt-1">Stay connected with your groups</p>
        </div>
        <Link to="/vacation" className="flex items-center gap-1.5 bg-gradient-to-br from-primary to-secondary text-primary-foreground rounded-2xl px-3.5 py-2.5 text-xs font-bold shadow-soft no-tap-highlight flex-shrink-0">
          <Plane size={14} /> Vacation
        </Link>
      </header>

      <div className="px-5 mt-4">
        <div className="relative">
          <Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search chats..."
            className="w-full bg-card rounded-2xl pl-11 pr-4 py-3 text-sm font-medium outline-none border border-transparent focus:border-primary/30 transition-colors"
          />
        </div>
      </div>

      <div className="px-5 mt-4 space-y-1.5">
        {/* Global community chat */}
        {showGlobal && (
          <motion.button
            initial={{ opacity: 0, x: -16 }}
            animate={{ opacity: 1, x: 0 }}
            onClick={openGlobal}
            disabled={openingGlobal}
            className="w-full flex items-center gap-3 p-2.5 rounded-2xl hover:bg-card transition-colors no-tap-highlight text-left"
          >
            <div className="w-12 h-12 rounded-2xl flex items-center justify-center flex-shrink-0 text-white bg-gradient-to-br from-primary to-secondary">
              {openingGlobal ? <Loader2 size={18} className="animate-spin" /> : <Globe size={20} />}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between gap-2">
                <p className="font-semibold text-sm truncate">{GLOBAL_CHAT_NAME}</p>
                <span className="text-[10px] font-bold bg-secondary/15 text-secondary rounded-full px-2 py-0.5 flex-shrink-0">COMMUNITY</span>
              </div>
              <p className="text-xs text-muted-foreground truncate mt-0.5">Welcome to the global community! 👋</p>
            </div>
          </motion.button>
        )}

        {filtered.map((g, i) => (
          <motion.div
            key={g.id}
            initial={{ opacity: 0, x: -16 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.05, duration: 0.3 }}
          >
            <Link to={g.chatId ? `/chat/${g.chatId}` : '/chats'} className="flex items-center gap-3 p-2.5 rounded-2xl hover:bg-card transition-colors no-tap-highlight">
              <div className="w-12 h-12 rounded-2xl flex items-center justify-center flex-shrink-0 text-white" style={{ background: g.color || '#1E4DFF' }}>
                <Users size={20} />
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-sm truncate">{g.name}</p>
                <p className="text-xs text-muted-foreground truncate mt-0.5">
                  {g.program_title || ''}{g.day_of_week ? ` · ${g.day_of_week} ${g.time || ''}` : ''}
                </p>
              </div>
            </Link>
          </motion.div>
        ))}

        {groups.length === 0 && !search && (
          <div className="text-center py-12">
            <div className="w-16 h-16 rounded-full bg-card flex items-center justify-center mx-auto mb-3">
              <Users size={26} className="text-muted-foreground/50" />
            </div>
            <p className="text-sm font-semibold text-foreground/70">No group chats yet</p>
            <p className="text-xs text-muted-foreground mt-1">Join a program to start chatting with your group.</p>
            <Link to="/programs" className="inline-flex items-center gap-1.5 mt-4 bg-primary text-primary-foreground rounded-full px-4 py-2 text-xs font-bold no-tap-highlight">
              Browse Programs
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}
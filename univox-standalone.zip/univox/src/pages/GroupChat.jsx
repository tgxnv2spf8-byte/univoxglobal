import { useEffect, useState, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, Send, FileText, BookOpen, Presentation, Link as LinkIcon, PenTool, Video, Clock, Mail, MessageCircle, Users } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useUserProgress } from '@/lib/UserProgressContext';

const materials = [
  { title: 'Lesson 12 — Presentation.pdf', type: 'PDF', icon: FileText, color: '#FF6FAE' },
  { title: 'Vocabulary List — Travel', type: 'Vocabulary', icon: BookOpen, color: '#1E4DFF' },
  { title: 'Speaking Practice Slides', type: 'Presentation', icon: Presentation, color: '#FF8A3D' },
  { title: 'Useful Links — BBC Learning English', type: 'Link', icon: LinkIcon, color: '#FFD84D' },
  { title: 'Homework — Essay Draft', type: 'Homework', icon: PenTool, color: '#1E4DFF' },
];

const tabs = ['Materials', 'Group', 'Lesson', 'Teacher'];

export default function GroupChat() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [chat, setChat] = useState(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('Group');
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [teacherInput, setTeacherInput] = useState('');
  const [teacherSent, setTeacherSent] = useState(false);
  const [meetLink, setMeetLink] = useState('');
  const [groupProgram, setGroupProgram] = useState('');
  const { attendLesson } = useUserProgress();
  const messagesEndRef = useRef(null);

  useEffect(() => {
    base44.entities.Chat.get(id).then(async (c) => {
      setChat(c);
      try {
        const g = await base44.entities.Group.filter({ name: c.name });
        if (g && g[0]) {
          setMeetLink(g[0].meet_link || '');
          setGroupProgram(g[0].program_title || '');
        }
      } catch {}
    }).catch(() => {}).finally(() => setLoading(false));
  }, [id]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const sendMessage = () => {
    if (!input.trim()) return;
    setMessages(prev => [...prev, {
      id: Date.now(),
      sender: 'You',
      text: input.trim(),
      time: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false }),
      isOwn: true,
    }]);
    setInput('');
  };

  if (loading) {
    return (
      <div className="min-h-screen">
        <div className="h-20 skeleton" />
        <div className="p-5 space-y-3">
          {[1, 2, 3, 4].map(i => <div key={i} className="h-16 skeleton rounded-2xl" />)}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-background max-w-md mx-auto">
      <header className="glass-strong sticky top-0 z-20 border-b border-border/30">
        <div className="flex items-center gap-3 px-4 pt-[calc(0.75rem+var(--safe-top))] pb-3">
          <button onClick={() => navigate('/chats')} className="w-9 h-9 flex items-center justify-center no-tap-highlight">
            <ChevronLeft size={24} />
          </button>
          <div className="flex-1 min-w-0">
            <p className="font-bold text-base truncate">{chat?.name || 'Group Chat'}</p>
            <p className="text-xs text-muted-foreground">{chat?.teacher ? `Teacher ${chat.teacher}` : 'Group chat'}</p>
          </div>
        </div>
        <div className="flex px-4 gap-1 pb-1">
          {tabs.map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`flex-1 py-2 text-xs font-semibold rounded-lg transition-colors no-tap-highlight ${activeTab === tab ? 'text-primary' : 'text-muted-foreground'}`}
            >
              {tab}
              {activeTab === tab && <motion.div layoutId="tabIndicator" className="h-0.5 bg-primary rounded-full mt-1" />}
            </button>
          ))}
        </div>
      </header>

      <div className="flex-1 overflow-y-auto">
        <AnimatePresence mode="wait">
          {activeTab === 'Group' && (
            <motion.div key="group" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="px-4 py-4 space-y-3">
              {messages.length === 0 && (
                <div className="text-center py-16">
                  <div className="w-16 h-16 rounded-full bg-card flex items-center justify-center mx-auto mb-3">
                    <MessageCircle size={26} className="text-muted-foreground/50" />
                  </div>
                  <p className="text-sm font-semibold text-foreground/70">No messages yet</p>
                  <p className="text-xs text-muted-foreground mt-1">Be the first to say hello 👋</p>
                </div>
              )}
              {messages.map((msg) => (
                <div key={msg.id} className={`flex ${msg.isOwn ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[75%] ${msg.isOwn ? 'items-end' : 'items-start'} flex flex-col`}>
                    {!msg.isOwn && <p className="text-xs font-semibold text-muted-foreground ml-3 mb-0.5">{msg.sender}</p>}
                    <div className={`rounded-2xl px-3.5 py-2.5 text-sm ${msg.isOwn ? 'bg-primary text-primary-foreground rounded-br-md' : 'bg-card text-foreground rounded-bl-md'}`}>
                      {msg.text}
                    </div>
                    <p className={`text-[10px] text-muted-foreground mt-0.5 ${msg.isOwn ? 'mr-1' : 'ml-1'}`}>{msg.time}</p>
                  </div>
                </div>
              ))}
              <div ref={messagesEndRef} />
            </motion.div>
          )}

          {activeTab === 'Materials' && (
            <motion.div key="materials" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="px-4 py-4 space-y-2.5">
              {materials.map((m, i) => (
                <motion.div key={i} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.06 }} className="bg-card rounded-2xl p-3.5 flex items-center gap-3 shadow-soft">
                  <div className="w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: `${m.color}15` }}>
                    <m.icon size={20} style={{ color: m.color }} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-sm truncate">{m.title}</p>
                    <p className="text-xs text-muted-foreground">{m.type}</p>
                  </div>
                </motion.div>
              ))}
            </motion.div>
          )}

          {activeTab === 'Lesson' && (
            <motion.div key="lesson" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="px-5 py-8 flex flex-col items-center text-center">
              <div className="w-20 h-20 rounded-3xl bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-white shadow-float mb-5">
                <Video size={36} />
              </div>
              <h2 className="text-xl font-extrabold">Join the Lesson</h2>
              <p className="text-sm text-muted-foreground mt-1.5 max-w-xs leading-relaxed">
                Your teacher is waiting on Google Meet. Tap below to join the live lesson.
              </p>
              {chat?.next_lesson_day && (
                <div className="mt-4 flex items-center gap-2 bg-primary/5 rounded-xl px-4 py-2.5">
                  <Clock size={14} className="text-primary" />
                  <span className="text-xs font-medium text-primary">Next: {chat.next_lesson_day} • {chat.next_lesson_time}</span>
                </div>
              )}
              {meetLink ? (
                <a
                  href={meetLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() => attendLesson(groupProgram)}
                  className="mt-7 w-full flex items-center justify-center gap-2 bg-primary text-primary-foreground rounded-2xl py-4 font-bold text-base shadow-lg shadow-primary/25 no-tap-highlight"
                >
                  <Video size={18} /> Join Lesson
                </a>
              ) : (
                <div className="mt-7 w-full flex items-center justify-center gap-2 bg-muted text-muted-foreground rounded-2xl py-4 font-bold text-base text-center px-4">
                  Your teacher hasn't added the lesson link yet
                </div>
              )}
            </motion.div>
          )}

          {activeTab === 'Teacher' && (
            <motion.div key="teacher" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="px-4 py-5 space-y-4">
              <div className="bg-gradient-to-br from-primary/10 to-secondary/10 rounded-2xl p-5 text-center">
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-white text-xl font-bold mx-auto mb-3">
                  {(chat?.teacher || 'T')[0]}
                </div>
                <p className="font-bold text-base">{chat?.teacher || 'Your Teacher'}</p>
                <p className="text-xs text-muted-foreground mt-0.5 flex items-center justify-center gap-1"><Users size={12} /> Your group's teacher</p>
              </div>
              <div className="flex items-start gap-3 bg-card rounded-2xl p-4 shadow-soft">
                <div className="w-9 h-9 rounded-lg bg-accent/15 flex items-center justify-center flex-shrink-0">
                  <MessageCircle size={16} className="text-accent-foreground" style={{ color: '#FF8A3D' }} />
                </div>
                <div>
                  <p className="text-sm font-semibold">Ask your teacher</p>
                  <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">If you have a question, you can write to your teacher here. They'll get back to you soon.</p>
                </div>
              </div>
              {teacherSent ? (
                <div className="bg-green-500/10 text-green-600 rounded-2xl p-4 text-sm font-medium text-center">
                  Message sent! Your teacher will reply soon.
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <input
                    value={teacherInput}
                    onChange={(e) => setTeacherInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && teacherInput.trim() && setTeacherSent(true)}
                    placeholder="Write a message to your teacher..."
                    className="flex-1 bg-card rounded-full px-4 py-2.5 text-sm outline-none border border-transparent focus:border-primary/30 transition-colors"
                  />
                  <button
                    onClick={() => teacherInput.trim() && setTeacherSent(true)}
                    disabled={!teacherInput.trim()}
                    className="w-10 h-10 rounded-full bg-primary text-primary-foreground flex items-center justify-center disabled:opacity-40 no-tap-highlight"
                  >
                    <Send size={17} />
                  </button>
                </div>
              )}
              <a href="mailto:teacher@univox.app" className="flex items-center gap-3 bg-card rounded-2xl p-3.5 shadow-soft no-tap-highlight">
                <div className="w-9 h-9 rounded-lg bg-primary/15 flex items-center justify-center"><Mail size={16} className="text-primary" /></div>
                <div className="flex-1">
                  <p className="text-sm font-medium">teacher@univox.app</p>
                  <p className="text-xs text-muted-foreground">Or email your teacher directly</p>
                </div>
              </a>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {activeTab === 'Group' && (
        <div className="glass-strong border-t border-border/30 p-3 pb-5 sticky bottom-0">
          <div className="flex items-center gap-2">
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
              placeholder="Type a message..."
              className="flex-1 bg-card rounded-full px-4 py-2.5 text-sm outline-none border border-transparent focus:border-primary/30 transition-colors"
            />
            <button onClick={sendMessage} disabled={!input.trim()} className="w-10 h-10 rounded-full bg-primary text-primary-foreground flex items-center justify-center disabled:opacity-40 no-tap-highlight">
              <Send size={17} />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
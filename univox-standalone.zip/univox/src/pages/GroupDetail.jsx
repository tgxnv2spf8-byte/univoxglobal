import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ChevronLeft, Clock, User, Users, GraduationCap, Calendar, Check, Loader2, MessageCircle } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { programs as programCfg } from '@/components/program/programConfig';
import { useUserProgress } from '@/lib/UserProgressContext';
import { useTimezone, convertLesson } from '@/lib/timezone';

export default function GroupDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { joinGroup, joinedGroups } = useUserProgress();
  const [group, setGroup] = useState(null);
  const [loading, setLoading] = useState(true);
  const [joining, setJoining] = useState(false);
  const { tz } = useTimezone();

  const program = group ? programCfg.find((p) => p.title === group.program_title) : null;
  const joinedEntry = (joinedGroups || []).find((g) => g.id === id);
  const joined = !!joinedEntry;
  const chatId = joinedEntry?.chatId || null;

  useEffect(() => {
    base44.entities.Group.get(id)
      .then((g) => { setGroup(g); setLoading(false); })
      .catch(() => setLoading(false));
  }, [id]);

  const join = async () => {
    if (!group || joining) return;
    setJoining(true);
    try {
      const cid = await joinGroup(group);
      navigate(`/chat/${cid || ''}`);
    } catch (err) {
      console.error(err);
    } finally {
      setJoining(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen">
        <div className="h-40 skeleton" />
        <div className="p-5 space-y-3">
          {[1, 2, 3].map((i) => <div key={i} className="h-16 skeleton rounded-2xl" />)}
        </div>
      </div>
    );
  }

  if (!group) {
    return (
      <div className="min-h-screen flex items-center justify-center px-5">
        <p className="text-muted-foreground">Group not found.</p>
      </div>
    );
  }

  const accent = program?.color || '#1E4DFF';
  const conv = group ? convertLesson(group.day_of_week || 'Monday', group.time || '18:00', tz) : { day: '', time: '' };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.35 }}
      className="min-h-screen pb-32"
    >
      <div className="relative h-48 overflow-hidden" style={{ background: accent }}>
        <div className="absolute inset-0" style={{ background: 'linear-gradient(160deg, rgba(255,255,255,0.18), rgba(0,0,0,0.22))' }} />
        {program?.Silhouette && <program.Silhouette className="absolute -right-3 top-6 w-36 h-36 text-black/50" />}
        <button
          onClick={() => navigate(-1)}
          className="absolute top-12 left-5 w-10 h-10 rounded-full glass flex items-center justify-center no-tap-highlight"
        >
          <ChevronLeft size={22} />
        </button>
        <motion.div
          initial={{ opacity: 0, y: 18 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15, duration: 0.45 }}
          className="absolute bottom-0 left-0 right-0 p-6"
        >
          <div className="text-2xl mb-1">{group?.flag_emoji || program?.flag || '📚'}</div>
          <h1 className="text-3xl font-extrabold tracking-tight text-white drop-shadow-lg">{group.name}</h1>
          <p className="text-white/75 text-xs mt-1">{group.program_title}</p>
        </motion.div>
      </div>

      <div className="px-5 mt-6">
        <div className="grid grid-cols-2 gap-3">
          <InfoTile icon={GraduationCap} label="Level" value={group.level || 'B1'} color={accent} />
          <InfoTile icon={Calendar} label="Day" value={conv.day || '—'} color={accent} />
          <InfoTile icon={Clock} label="Time" value={conv.time || '—'} color={accent} />
          <InfoTile icon={Users} label="Members" value={String(group.member_count || 0)} color={accent} />
        </div>

        {group.teacher && (
          <motion.div
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="mt-3 bg-card rounded-3xl p-4 shadow-soft flex items-center gap-3"
          >
            <div className="w-12 h-12 rounded-2xl flex items-center justify-center text-white text-lg font-bold" style={{ background: accent }}>
              {group.teacher[0]}
            </div>
            <div>
              <p className="text-xs text-muted-foreground">Teacher</p>
              <p className="font-bold text-sm">{group.teacher}</p>
            </div>
          </motion.div>
        )}
      </div>

      {/* Sticky join bar */}
      <div className="fixed bottom-0 left-0 right-0 z-40 px-5 pb-6 pt-4 bg-gradient-to-t from-background via-background/95 to-transparent">
        {joined ? (
          <button
            onClick={() => chatId && navigate(`/chat/${chatId}`)}
            className="w-full bg-card text-foreground rounded-2xl py-4 font-bold text-base flex items-center justify-center gap-2 shadow-card no-tap-highlight"
          >
            <Check size={18} className="text-green-500" /> You're a member · Open Chat
          </button>
        ) : (
          <button
            onClick={join}
            disabled={joining}
            className="w-full bg-primary text-primary-foreground rounded-2xl py-4 font-bold text-base flex items-center justify-center gap-2 shadow-lg shadow-primary/25 disabled:opacity-50 no-tap-highlight"
          >
            {joining ? <><Loader2 size={18} className="animate-spin" /> Joining...</> : <><Users size={18} /> Join Group</>}
          </button>
        )}
      </div>
    </motion.div>
  );
}

function InfoTile({ icon: Icon, label, value, color }) {
  return (
    <div className="bg-card rounded-3xl p-4 shadow-soft">
      <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: `${color}15` }}>
        <Icon size={16} style={{ color }} />
      </div>
      <p className="text-[11px] text-muted-foreground mt-2.5">{label}</p>
      <p className="font-bold text-sm mt-0.5">{value}</p>
    </div>
  );
}
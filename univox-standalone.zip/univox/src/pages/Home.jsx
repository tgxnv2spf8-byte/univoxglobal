import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Bell, ChevronRight, Video, Calendar, Megaphone, Sun, Users, Sparkles, FlaskConical } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { programs as programCfg } from '@/components/program/programConfig';
import { isLive, categoryLabel, categoryEmoji } from '@/components/announcements/announcementConfig';
import { useUserProgress } from '@/lib/UserProgressContext';
import PullToRefresh from '@/components/PullToRefresh';

const annIcons = {
  new_program: Sparkles,
  update: Sun,
  info: Megaphone,
  event: Calendar,
  research: FlaskConical,
  speaking_club: Users,
  summer_projects: Sun,
  new_teachers: Users,
  default: Megaphone,
};

export default function Home() {
  const { joinedGroups, attendLesson } = useUserProgress();
  const [programs, setPrograms] = useState([]);
  const [announcements, setAnnouncements] = useState([]);
  const [loading, setLoading] = useState(true);
  const [userName, setUserName] = useState('');
  const [user, setUser] = useState(null);
  const [needsOnboarding, setNeedsOnboarding] = useState(false);

  const reload = () => {
    setLoading(true);
    return Promise.all([
      base44.entities.Program.list().catch(() => []),
      base44.entities.Announcement.list().catch(() => []),
    ]).then(([p, a]) => {
      setPrograms(p || []);
      setAnnouncements(a || []);
    }).finally(() => setLoading(false));
  };

  useEffect(() => {
    base44.auth.me().then(u => {
      setUser(u);
      setUserName(u?.full_name || '');
      if (!u?.onboarding_completed) setNeedsOnboarding(true);
    }).catch(() => {});
    reload();
  }, []);

  const hour = new Date().getHours();
  const greeting = hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening';
  const displayName = userName || (user?.email?.split('@')[0]) || 'there';
  const upcomingLesson = joinedGroups[0];
  const liveAnns = announcements.filter(isLive);
  const liveFeatured = liveAnns.filter((a) => a.featured);
  const liveOthers = liveAnns.filter((a) => !a.featured);

  if (needsOnboarding && !loading) {
    return (
      <div className="min-h-screen pb-28">
        <header className="px-5 pt-[calc(0.75rem+var(--safe-top))] pb-4 flex items-center justify-between">
          <div>
            <p className="text-xs font-semibold tracking-widest text-primary uppercase">UNIVOX</p>
            <h1 className="text-2xl font-bold mt-0.5">{greeting} 👋</h1>
          </div>
          <Link to="/notifications" className="relative w-11 h-11 rounded-full bg-card flex items-center justify-center shadow-soft no-tap-highlight">
            <Bell size={20} className="text-foreground/70" />
          </Link>
        </header>
        <div className="px-5">
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
            className="relative rounded-[2rem] overflow-hidden shadow-card bg-gradient-to-br from-primary via-primary to-secondary text-primary-foreground p-8 text-center"
          >
            <motion.div
              initial={{ scale: 0.6, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: 0.15, duration: 0.5, type: 'spring' }}
              className="text-6xl mb-4"
            >👋</motion.div>
            <p className="text-xs font-bold tracking-widest uppercase opacity-80">Welcome to UNIVOX</p>
            <h2 className="text-3xl font-extrabold mt-2 leading-tight">Start Learning Today!</h2>
            <p className="opacity-85 text-sm mt-3 max-w-xs mx-auto">Create your personalized learning journey in just 2 minutes.</p>
            <Link
              to="/onboarding"
              className="mt-6 inline-flex items-center gap-2 bg-white text-primary rounded-2xl px-6 py-3.5 text-base font-bold shadow-soft no-tap-highlight"
            >
              Start Learning Today <ChevronRight size={18} />
            </Link>
          </motion.div>
          <div className="mt-6 grid grid-cols-3 gap-3">
            {[
              { emoji: '🔬', label: 'Start Research' },
              { emoji: '🎓', label: '2 Live Lessons' },
              { emoji: '🧠', label: 'AI Tutor' },
            ].map((f) => (
              <div key={f.label} className="bg-card rounded-2xl p-4 text-center shadow-soft">
                <div className="text-2xl mb-1">{f.emoji}</div>
                <p className="text-xs font-semibold leading-tight">{f.label}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <PullToRefresh onRefresh={reload} className="min-h-screen pb-28">
      <header className="px-5 pt-[calc(0.75rem+var(--safe-top))] pb-4 flex items-center justify-between">
        <div>
          <p className="text-xs font-semibold tracking-widest text-primary uppercase">UNIVOX</p>
          <h1 className="text-2xl font-bold mt-0.5">{greeting}, {displayName} <span className="inline-block">✨</span></h1>
        </div>
        <Link to="/notifications" className="relative w-11 h-11 rounded-full bg-card flex items-center justify-center shadow-soft no-tap-highlight">
          <Bell size={20} className="text-foreground/70" />
          <span className="absolute top-2.5 right-2.5 w-2.5 h-2.5 bg-secondary rounded-full ring-2 ring-background" />
        </Link>
      </header>

      <div className="px-5">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="relative rounded-3xl overflow-hidden shadow-card h-44"
        >
          <img
            src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=800&q=80&auto=format"
            alt="Students"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-primary/80 via-primary/20 to-transparent" />
          <div className="absolute bottom-0 left-0 right-0 p-5">
            <p className="text-white/80 text-xs font-medium uppercase tracking-wider">Global Learning</p>
            <p className="text-white text-lg font-bold mt-0.5 leading-tight">Learn together with students worldwide</p>
          </div>
        </motion.div>
      </div>

      <div className="px-5 mt-5">
        <div className="grid grid-cols-2 gap-3">
          <Link to="/programs" className="bg-card rounded-2xl p-4 shadow-soft no-tap-highlight">
            <div className="w-10 h-10 rounded-xl bg-secondary/15 flex items-center justify-center mb-2">
              <Users size={18} className="text-secondary" />
            </div>
            <p className="font-bold text-sm leading-tight">Join the Community</p>
            <p className="text-xs text-muted-foreground mt-0.5">Meet students & teachers</p>
          </Link>
          <Link to="/ai-tutor" className="bg-card rounded-2xl p-4 shadow-soft no-tap-highlight">
            <div className="w-10 h-10 rounded-xl bg-primary/15 flex items-center justify-center mb-2">
              <Sparkles size={18} className="text-primary" />
            </div>
            <p className="font-bold text-sm leading-tight">AI Tutor</p>
            <p className="text-xs text-muted-foreground mt-0.5">Practice & guidance</p>
          </Link>
        </div>
      </div>

      <div className="px-5 mt-6">
        <h2 className="text-sm font-bold text-foreground/80 uppercase tracking-wide mb-3">Upcoming Lesson</h2>
        {loading ? (
          <div className="h-28 rounded-3xl skeleton" />
        ) : upcomingLesson ? (
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1, duration: 0.4 }}
            className="bg-primary rounded-3xl p-5 shadow-card text-primary-foreground relative overflow-hidden"
          >
            <div className="absolute -right-6 -top-6 w-24 h-24 rounded-full bg-white/10" />
            <div className="absolute -right-2 -bottom-8 w-20 h-20 rounded-full bg-white/5" />
            <div className="relative">
              <div className="flex items-center gap-2 mb-1">
                <span className="text-2xl">🇬🇧</span>
                <p className="font-bold text-lg">{upcomingLesson.name || 'English Group A'}</p>
              </div>
              <div className="flex items-center gap-3 text-white/80 text-sm">
                <span className="flex items-center gap-1"><Calendar size={14} /> Today • {upcomingLesson.time || '18:00'}</span>
                <span>•</span>
                <span>{upcomingLesson.teacher || 'Teacher Emma'}</span>
              </div>
              <a
                href={upcomingLesson.meet_link || '#'}
                target="_blank"
                rel="noopener noreferrer"
                onClick={(e) => {
                  attendLesson(upcomingLesson.program_title);
                  if (!upcomingLesson.meet_link) { e.preventDefault(); alert("Your teacher hasn't added the lesson link yet."); }
                }}
                className="mt-4 bg-white text-primary rounded-full px-5 py-2 text-sm font-bold flex items-center gap-1.5 hover:bg-white/90 transition-colors no-tap-highlight inline-flex"
              >
                <Video size={15} /> Join Lesson
              </a>
            </div>
          </motion.div>
        ) : (
          <div className="bg-card rounded-3xl p-5 text-center">
            <p className="font-semibold text-foreground/80">No lessons today</p>
            <p className="text-sm text-muted-foreground mt-1">Your next lesson is Friday.</p>
          </div>
        )}
      </div>

      <div className="mt-7">
        <div className="px-5 flex items-center justify-between mb-3">
          <h2 className="text-sm font-bold text-foreground/80 uppercase tracking-wide">Programs</h2>
          <Link to="/programs" className="text-xs font-semibold text-primary flex items-center gap-0.5">
            See all <ChevronRight size={14} />
          </Link>
        </div>
        <div className="flex gap-3 overflow-x-auto scrollbar-hide px-5 pb-1">
          {loading
            ? [1, 2, 3].map((i) => <div key={i} className="w-44 h-52 rounded-3xl skeleton flex-shrink-0" />)
            : programs.map((p, i) => (
              <motion.div
                key={p.id}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.08, duration: 0.4 }}
              >
                {(() => {
                  const cfg = programCfg.find((c) => c.title === p.title);
                  const Sil = cfg?.Silhouette;
                  const color = p.accent_color || cfg?.color || '#1E4DFF';
                  const flag = p.flag_emoji || cfg?.flag || '📚';
                  return (
                <Link to={`/program/${p.id}`} className="block w-44 flex-shrink-0 no-tap-highlight">
                  <div className="relative h-52 rounded-3xl overflow-hidden shadow-card" style={{ background: color }}>
                    <div className="absolute inset-0" style={{ background: 'linear-gradient(160deg, rgba(255,255,255,0.22), rgba(0,0,0,0.10))' }} />
                    {Sil && <Sil className="absolute -top-3 -right-3 w-24 h-24 text-black/55" />}
                    <div className="absolute top-3 left-3 text-4xl drop-shadow-lg">{flag}</div>
                    <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/35 to-transparent">
                      <p className="text-white font-extrabold text-lg leading-tight drop-shadow-lg">{p.title}</p>
                      <p className="text-white/80 text-xs mt-1 line-clamp-2">{p.description}</p>
                      <p className="text-white/90 text-xs font-semibold mt-2 flex items-center gap-0.5">
                        View Program <ChevronRight size={12} />
                      </p>
                    </div>
                  </div>
                </Link>
                  );
                })()}
              </motion.div>
            ))}
        </div>
      </div>

      {liveFeatured.length > 0 && (
        <div className="mt-7">
          <div className="px-5 mb-3">
            <h2 className="text-sm font-bold text-foreground/80 uppercase tracking-wide">Featured</h2>
          </div>
          <div className="flex gap-3 overflow-x-auto scrollbar-hide px-5 pb-1">
            {liveFeatured.map((a, i) => (
              <motion.div key={a.id} initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.08, duration: 0.4 }}>
                <Link to={`/announcement/${a.id}`} className="block w-72 flex-shrink-0 no-tap-highlight">
                  <div className="relative h-40 rounded-3xl overflow-hidden shadow-card">
                    {a.cover_image_url ? (
                      <img src={a.cover_image_url} alt="" className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-6xl">{categoryEmoji(a.category)}</div>
                    )}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-transparent" />
                    <div className="absolute top-3 left-3 flex gap-1.5 flex-wrap">
                      <span className="text-[10px] font-bold bg-white/90 text-foreground rounded-full px-2 py-0.5">{categoryLabel(a.category)}</span>
                      <span className="text-[10px] font-bold bg-accent text-accent-foreground rounded-full px-2 py-0.5">★</span>
                    </div>
                    <div className="absolute bottom-0 left-0 right-0 p-4">
                      <p className="text-white font-bold text-base leading-tight drop-shadow-lg">{a.title}</p>
                      {a.short_description && <p className="text-white/85 text-xs mt-1 line-clamp-2">{a.short_description}</p>}
                    </div>
                  </div>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      )}

      <div className="px-5 mt-7">
        <h2 className="text-sm font-bold text-foreground/80 uppercase tracking-wide mb-3">Announcements</h2>
        <div className="space-y-2.5">
          {loading
            ? [1, 2].map((i) => <div key={i} className="h-16 rounded-2xl skeleton" />)
            : liveOthers.slice(0, 4).map((a, i) => {
              const Icon = annIcons[a.category] || annIcons[a.type] || annIcons.default;
              return (
                <Link key={a.id} to={`/announcement/${a.id}`} className="block no-tap-highlight">
                  <motion.div
                    initial={{ opacity: 0, y: 12 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.1, duration: 0.3 }}
                    className="bg-card rounded-2xl p-4 flex items-center gap-3 shadow-soft"
                  >
                    <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <Icon size={18} className="text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-sm leading-tight">{a.title}</p>
                      {(a.short_description || a.description) && <p className="text-xs text-muted-foreground mt-0.5 line-clamp-1">{a.short_description || a.description}</p>}
                    </div>
                    <ChevronRight size={16} className="text-muted-foreground flex-shrink-0" />
                  </motion.div>
                </Link>
              );
            })}
          {!loading && liveAnns.length === 0 && (
            <div className="text-center py-8"><p className="text-sm text-muted-foreground">No announcements yet.</p></div>
          )}
        </div>
      </div>
    </PullToRefresh>
  );
}
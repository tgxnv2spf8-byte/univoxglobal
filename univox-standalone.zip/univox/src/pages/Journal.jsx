import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { PenLine, FileText, FlaskConical, ChevronRight } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { categories } from '@/components/journal/journalConfig';
import ArticleCard from '@/components/journal/ArticleCard';
import AIRecommendations from '@/components/journal/AIRecommendations';
import { useUserProgress } from '@/lib/UserProgressContext';
import PullToRefresh from '@/components/PullToRefresh';

export default function Journal() {
  const [articles, setArticles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeCategory, setActiveCategory] = useState('all');
  const { markJournalExplored } = useUserProgress();

  const reload = () => {
    setLoading(true);
    return base44.entities.JournalArticle.list('-created_date', 50)
      .then((data) => setArticles(data || []))
      .catch(() => {})
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    markJournalExplored();
    reload();
  }, []);

  const published = articles.filter((a) => a.status === 'published');
  const featured = published.find((a) => a.featured) || published[0];
  const filtered = activeCategory === 'all' ? published : published.filter((a) => a.category === activeCategory);
  const others = filtered.filter((a) => a.id !== featured?.id);

  return (
    <PullToRefresh onRefresh={reload} className="min-h-screen pb-28 bg-white">
      <div className="sticky top-0 z-40 glass-strong border-b border-border/50">
        <div className="px-5 pt-[calc(0.75rem+var(--safe-top))] pb-4">
          <div className="flex items-start justify-between gap-3">
            <div className="flex-1">
              <h1 className="font-editorial text-3xl font-bold tracking-tight">UNIVOX Journal</h1>
              <p className="text-sm text-muted-foreground mt-1 leading-relaxed">
                Ideas. Research. Creativity.<br />Written by the next generation.
              </p>
            </div>
            <div className="flex items-center gap-2 flex-shrink-0 mt-1">
              <Link to="/journal/submissions" className="no-tap-highlight">
                <div className="w-10 h-10 rounded-full bg-card border border-border flex items-center justify-center">
                  <FileText size={18} className="text-foreground" />
                </div>
              </Link>
              <Link to="/journal/submit" className="no-tap-highlight">
                <div className="w-10 h-10 rounded-full bg-foreground flex items-center justify-center text-background">
                  <PenLine size={18} />
                </div>
              </Link>
            </div>
          </div>
        </div>
      </div>

      <div className="px-5 mt-5">
        {loading ? (
          <div className="w-full aspect-[4/5] skeleton rounded-[2rem]" />
        ) : featured ? (
          <ArticleCard article={featured} variant="featured" />
        ) : null}
      </div>

      <div className="mt-6">
        <div className="flex gap-2 overflow-x-auto scrollbar-hide px-5 pb-1">
          <button
            onClick={() => setActiveCategory('all')}
            className={`flex-shrink-0 px-4 py-2 rounded-full text-xs font-bold transition-all no-tap-highlight ${
              activeCategory === 'all' ? 'bg-foreground text-background' : 'bg-card text-muted-foreground'
            }`}
          >
            All
          </button>
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`flex-shrink-0 px-4 py-2 rounded-full text-xs font-bold transition-all no-tap-highlight ${
                activeCategory === cat.id ? 'text-white' : 'bg-card text-muted-foreground'
              }`}
              style={activeCategory === cat.id ? { background: cat.color } : {}}
            >
              {cat.emoji} {cat.label}
            </button>
          ))}
        </div>
      </div>

      <div className="px-5 mt-5">
        {loading ? (
          <div className="grid grid-cols-2 gap-3">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="aspect-[4/5] skeleton rounded-2xl" />
            ))}
          </div>
        ) : others.length > 0 ? (
          <>
            <h2 className="font-editorial text-lg font-bold mb-3">
              {activeCategory === 'all' ? 'Latest Stories' : 'Explore'}
            </h2>
            <div className="grid grid-cols-2 gap-3">
              {others.map((article, i) => (
                <ArticleCard key={article.id} article={article} index={i} />
              ))}
            </div>
          </>
        ) : (
          <div className="text-center py-12">
            <p className="text-sm text-muted-foreground">No articles in this category yet.</p>
          </div>
        )}
      </div>

      <AIRecommendations articles={published} />

      <div className="px-5 mt-8">
        <Link to="/research" className="block no-tap-highlight">
          <div className="relative rounded-3xl overflow-hidden bg-gradient-to-br from-foreground to-primary p-6 text-white">
            <div className="absolute -top-8 -right-8 w-32 h-32 rounded-full bg-secondary/20" />
            <div className="absolute -bottom-4 -left-4 w-20 h-20 rounded-full bg-accent/20" />
            <div className="relative flex items-center gap-4">
              <div className="w-12 h-12 rounded-2xl bg-white/20 flex items-center justify-center flex-shrink-0">
                <FlaskConical size={22} />
              </div>
              <div className="flex-1">
                <h3 className="font-editorial text-xl font-bold">Start Your Research</h3>
                <p className="text-sm text-white/70 mt-0.5">Join the UNIVOX Research Program and publish your work.</p>
              </div>
              <ChevronRight size={20} className="text-white/60" />
            </div>
          </div>
        </Link>
      </div>
    </PullToRefresh>
  );
}
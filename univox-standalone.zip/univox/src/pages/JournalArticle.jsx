import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import ReactMarkdown from 'react-markdown';
import { ArrowLeft, Clock, Sparkles, Globe, ChevronRight } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { getCategory } from '@/components/journal/journalConfig';
import ReadingProgress from '@/components/journal/ReadingProgress';
import ArticleActions from '@/components/journal/ArticleActions';
import ArticleCard from '@/components/journal/ArticleCard';

const languages = ['Spanish', 'French', 'Portuguese', 'Japanese', 'Arabic', 'German'];

export default function JournalArticle() {
  const { id } = useParams();
  const [article, setArticle] = useState(null);
  const [related, setRelated] = useState([]);
  const [loading, setLoading] = useState(true);
  const [translated, setTranslated] = useState(null);
  const [translating, setTranslating] = useState(false);
  const [showLangs, setShowLangs] = useState(false);

  useEffect(() => {
    setLoading(true);
    setArticle(null);
    setTranslated(null);
    window.scrollTo(0, 0);
    base44.entities.JournalArticle.get(id)
      .then((data) => {
        setArticle(data);
        if (data?.category) {
          base44.entities.JournalArticle.filter({ category: data.category })
            .then((items) => setRelated((items || []).filter((a) => a.id !== id).slice(0, 4)))
            .catch(() => {});
        }
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [id]);

  const handleTranslate = async (lang) => {
    if (!article) return;
    setShowLangs(false);
    setTranslating(true);
    try {
      const res = await base44.integrations.Core.InvokeLLM({
        prompt: `Translate the following article into ${lang}. Keep all markdown formatting intact. Only return the translated text:\n\n${article.content}`,
      });
      setTranslated(res);
    } catch {
    } finally {
      setTranslating(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-border border-t-foreground rounded-full animate-spin" />
      </div>
    );
  }

  if (!article) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center px-6">
        <p className="text-muted-foreground">Article not found.</p>
        <Link to="/journal" className="mt-4 text-primary font-semibold">Back to Journal</Link>
      </div>
    );
  }

  const cat = getCategory(article.category);
  const content = translated || article.content || '';

  return (
    <div className="min-h-screen bg-white pb-24">
      <ReadingProgress />

      <div className="sticky top-0 z-40 glass-strong">
        <div className="px-4 py-3 flex items-center justify-between">
          <Link to="/journal" className="flex items-center gap-1 text-sm font-medium no-tap-highlight">
            <ArrowLeft size={18} /> Journal
          </Link>
          <div className="relative">
            <button
              onClick={() => (translated ? setTranslated(null) : setShowLangs(!showLangs))}
              disabled={translating}
              className="flex items-center gap-1.5 text-xs font-semibold text-primary px-3 py-1.5 rounded-full bg-primary/10 no-tap-highlight disabled:opacity-50"
            >
              <Globe size={14} /> {translating ? 'Translating...' : translated ? 'Show Original' : 'Translate'}
            </button>
            <AnimatePresence>
              {showLangs && (
                <motion.div
                  initial={{ opacity: 0, y: -8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  className="absolute right-0 top-full mt-1 bg-popover rounded-2xl shadow-float border border-border py-1 min-w-[140px] z-50"
                >
                  {languages.map((lang) => (
                    <button
                      key={lang}
                      onClick={() => handleTranslate(lang)}
                      className="w-full text-left px-4 py-2 text-sm hover:bg-accent/10 no-tap-highlight"
                    >
                      {lang}
                    </button>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>

      <div className="relative w-full aspect-[4/3] overflow-hidden">
        <img src={article.cover_image_url} alt={article.title} className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent" />
      </div>

      <div className="px-5 pt-6">
        <span
          className="inline-flex items-center gap-1 text-xs font-bold px-3 py-1 rounded-full text-white"
          style={{ background: cat.color }}
        >
          {cat.emoji} {cat.label}
        </span>
        <h1 className="font-editorial text-3xl font-bold leading-tight mt-4">{article.title}</h1>
        {article.subtitle && (
          <p className="text-lg text-muted-foreground mt-2 leading-relaxed">{article.subtitle}</p>
        )}

        <Link
          to={`/journal/author/${encodeURIComponent(article.author_name)}`}
          className="flex items-center gap-3 mt-5 no-tap-highlight"
        >
          <div className="w-11 h-11 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-white font-bold flex-shrink-0">
            {article.author_name?.[0]}
          </div>
          <div className="flex-1 min-w-0">
            <p className="font-semibold text-sm">{article.author_name}</p>
            <p className="text-xs text-muted-foreground truncate">
              {article.author_country} {article.author_flag} • {article.author_age} • {article.author_program}
            </p>
          </div>
          <div className="flex items-center gap-1 text-xs text-muted-foreground flex-shrink-0">
            <Clock size={12} /> {article.reading_time_minutes} min
          </div>
        </Link>
      </div>

      {article.ai_summary && (
        <div className="px-5 mt-6">
          <div className="bg-gradient-to-br from-primary/5 to-secondary/5 rounded-2xl p-4 border border-primary/10">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center">
                <Sparkles size={12} className="text-primary" />
              </div>
              <span className="text-xs font-bold text-primary">AI Summary • 30 sec read</span>
            </div>
            <p className="text-sm text-foreground/80 leading-relaxed">{article.ai_summary}</p>
          </div>
        </div>
      )}

      <div className="px-5 mt-6">
        <ReactMarkdown
          components={{
            h2: ({ node, ...props }) => <h2 className="font-editorial text-2xl font-bold mt-8 mb-3" {...props} />,
            h3: ({ node, ...props }) => <h3 className="font-editorial text-xl font-bold mt-6 mb-2" {...props} />,
            p: ({ node, ...props }) => <p className="text-[15px] leading-7 text-foreground/90 mb-4" {...props} />,
            img: ({ node, ...props }) => <img className="w-full rounded-2xl my-6" {...props} />,
            blockquote: ({ node, ...props }) => (
              <blockquote className="border-l-2 border-primary pl-4 italic text-muted-foreground my-4" {...props} />
            ),
            ul: ({ node, ...props }) => <ul className="list-disc pl-5 space-y-1 mb-4" {...props} />,
            ol: ({ node, ...props }) => <ol className="list-decimal pl-5 space-y-1 mb-4" {...props} />,
            li: ({ node, ...props }) => <li className="text-[15px] leading-7 text-foreground/90" {...props} />,
            strong: ({ node, ...props }) => <strong className="font-bold text-foreground" {...props} />,
            a: ({ node, ...props }) => <a className="text-primary underline" {...props} />,
          }}
        >
          {content}
        </ReactMarkdown>
      </div>

      {article.pull_quote && (
        <div className="px-5 mt-8">
          <div className="border-l-[3px] pl-5 py-2" style={{ borderColor: cat.color }}>
            <p className="font-editorial text-2xl font-medium italic leading-relaxed text-foreground">
              &ldquo;{article.pull_quote}&rdquo;
            </p>
          </div>
        </div>
      )}

      {article.references && (
        <div className="px-5 mt-8">
          <h3 className="font-editorial text-lg font-bold mb-3">References</h3>
          <div className="bg-card rounded-2xl p-4">
            <ReactMarkdown
              components={{
                p: ({ node, ...props }) => <p className="text-xs text-muted-foreground leading-6 mb-1" {...props} />,
              }}
            >
              {article.references}
            </ReactMarkdown>
          </div>
        </div>
      )}

      {related.length > 0 && (
        <div className="mt-10">
          <div className="px-5 mb-3 flex items-center justify-between">
            <h3 className="font-editorial text-lg font-bold">Related Articles</h3>
            <Link to="/journal" className="text-xs text-primary font-semibold flex items-center gap-0.5">
              All <ChevronRight size={14} />
            </Link>
          </div>
          <div className="flex gap-3 overflow-x-auto scrollbar-hide px-5 pb-2">
            {related.map((a, i) => (
              <div key={a.id} className="w-44 flex-shrink-0">
                <ArticleCard article={a} index={i} />
              </div>
            ))}
          </div>
        </div>
      )}

      <ArticleActions article={article} />
    </div>
  );
}
import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft, Users, TrendingUp, BookOpen } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import ArticleCard from '@/components/journal/ArticleCard';

const authorBadges = [
  { icon: '📰', label: 'First Published' },
  { icon: '🔬', label: 'Young Scientist' },
  { icon: '🌍', label: 'Global Journalist' },
  { icon: '💡', label: 'Innovation Award' },
  { icon: '🏆', label: "Editor's Choice" },
];

export default function JournalAuthor() {
  const { authorName } = useParams();
  const name = decodeURIComponent(authorName);
  const [articles, setArticles] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    base44.entities.JournalArticle.filter({ author_name: name })
      .then((data) => setArticles(data || []))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [name]);

  const published = articles.filter((a) => a.status === 'published');
  const totalLikes = published.reduce((sum, a) => sum + (a.likes || 0), 0);
  const researchScore = totalLikes * 10 + published.length * 50;
  const followers = Math.floor(researchScore / 5) + 120;
  const first = published[0];

  return (
    <div className="min-h-screen pb-28">
      <div className="sticky top-0 z-40 glass-strong">
        <div className="px-4 py-3">
          <Link to="/journal" className="flex items-center gap-1 text-sm font-medium no-tap-highlight">
            <ArrowLeft size={18} /> Journal
          </Link>
        </div>
      </div>

      <div className="relative h-32 bg-gradient-to-br from-primary via-secondary to-accent">
        <div className="absolute inset-0 bg-black/10" />
      </div>

      <div className="px-5 -mt-12 relative">
        <div className="w-24 h-24 rounded-full bg-white p-1 shadow-float">
          <div className="w-full h-full rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-white text-3xl font-bold">
            {name?.[0]}
          </div>
        </div>
      </div>

      <div className="px-5 mt-3">
        <h1 className="font-editorial text-2xl font-bold">{name}</h1>
        {first && (
          <p className="text-sm text-muted-foreground mt-1">
            {first.author_country} {first.author_flag} • {first.author_age} years old
          </p>
        )}
        {first?.author_program && (
          <span className="inline-block mt-2 text-xs font-semibold bg-primary/10 text-primary px-3 py-1 rounded-full">
            {first.author_program}
          </span>
        )}
      </div>

      <div className="px-5 mt-5 grid grid-cols-3 gap-3">
        {[
          { label: 'Articles', value: published.length, icon: BookOpen, color: '#1E4DFF' },
          { label: 'Followers', value: followers, icon: Users, color: '#FF6FAE' },
          { label: 'Research Score', value: researchScore, icon: TrendingUp, color: '#FF8A3D' },
        ].map((s, i) => (
          <motion.div
            key={s.label}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.08 }}
            className="bg-card rounded-2xl p-3 text-center shadow-soft"
          >
            <s.icon size={16} style={{ color: s.color }} className="mx-auto" />
            <p className="text-xl font-extrabold mt-1" style={{ color: s.color }}>
              {s.value}
            </p>
            <p className="text-[10px] text-muted-foreground font-medium">{s.label}</p>
          </motion.div>
        ))}
      </div>

      <div className="px-5 mt-5">
        <h2 className="text-sm font-bold text-foreground/80 uppercase tracking-wide mb-3">Achievements</h2>
        <div className="flex gap-3 overflow-x-auto scrollbar-hide pb-1">
          {authorBadges.map((b, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: i * 0.08 }}
              className="flex-shrink-0 w-20 flex flex-col items-center text-center"
            >
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-accent to-orange flex items-center justify-center text-2xl shadow-soft">
                {b.icon}
              </div>
              <p className="text-[10px] font-semibold mt-1.5 leading-tight">{b.label}</p>
            </motion.div>
          ))}
        </div>
      </div>

      <div className="px-5 mt-6">
        <h2 className="font-editorial text-lg font-bold mb-3">Published Articles</h2>
        {loading ? (
          [1, 2].map((i) => <div key={i} className="h-24 skeleton rounded-2xl mb-3" />)
        ) : published.length > 0 ? (
          <div className="space-y-3">
            {published.map((a, i) => (
              <ArticleCard key={a.id} article={a} variant="list" index={i} />
            ))}
          </div>
        ) : (
          <p className="text-sm text-muted-foreground text-center py-8">No published articles yet.</p>
        )}
      </div>
    </div>
  );
}
import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft, Clock, FileText, CheckCircle2, Loader, Newspaper } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { getCategory } from '@/components/journal/journalConfig';

const statusConfig = {
  under_review: { label: 'Under Review', icon: Loader, color: '#EAB308', bg: 'bg-accent/15' },
  approved: { label: 'Approved', icon: CheckCircle2, color: '#22C55E', bg: 'bg-green-500/15' },
  published: { label: 'Published', icon: Newspaper, color: '#1E4DFF', bg: 'bg-primary/15' },
};

export default function JournalMySubmissions() {
  const [articles, setArticles] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    base44.entities.JournalArticle.list('-created_date', 50)
      .then((data) => setArticles(data || []))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const counts = {
    under_review: articles.filter((a) => a.status === 'under_review').length,
    approved: articles.filter((a) => a.status === 'approved').length,
    published: articles.filter((a) => a.status === 'published').length,
  };

  return (
    <div className="min-h-screen pb-28">
      <div className="sticky top-0 z-40 glass-strong">
        <div className="px-4 py-3 flex items-center gap-2">
          <Link to="/journal" className="no-tap-highlight">
            <ArrowLeft size={20} />
          </Link>
          <h1 className="font-editorial text-xl font-bold">My Submissions</h1>
        </div>
      </div>

      <div className="px-5 mt-5 grid grid-cols-3 gap-3">
        {Object.entries(statusConfig).map(([key, cfg]) => (
          <div key={key} className="bg-card rounded-2xl p-3 text-center shadow-soft">
            <div className={`w-9 h-9 rounded-xl ${cfg.bg} flex items-center justify-center mx-auto`}>
              <cfg.icon size={16} style={{ color: cfg.color }} className={key === 'under_review' ? 'animate-spin' : ''} />
            </div>
            <p className="text-2xl font-extrabold mt-2" style={{ color: cfg.color }}>{counts[key]}</p>
            <p className="text-[10px] text-muted-foreground font-medium leading-tight mt-0.5">{cfg.label}</p>
          </div>
        ))}
      </div>

      <div className="px-5 mt-6">
        {loading ? (
          [1, 2, 3].map((i) => <div key={i} className="h-24 skeleton rounded-2xl mb-3" />)
        ) : articles.length === 0 ? (
          <div className="text-center py-16">
            <FileText size={40} className="text-muted-foreground/30 mx-auto" />
            <p className="text-sm text-muted-foreground mt-3">No submissions yet.</p>
            <Link
              to="/journal/submit"
              className="inline-block mt-4 bg-primary text-primary-foreground rounded-full px-5 py-2.5 text-xs font-bold no-tap-highlight"
            >
              Submit Your First Article
            </Link>
          </div>
        ) : (
          <div className="space-y-3">
            {articles.map((article, i) => {
              const cat = getCategory(article.category);
              const status = statusConfig[article.status] || statusConfig.under_review;
              const isPublished = article.status === 'published';
              return (
                <motion.div
                  key={article.id}
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.06 }}
                >
                  <Link
                    to={isPublished ? `/journal/article/${article.id}` : '#'}
                    className={`flex gap-3 bg-card rounded-2xl overflow-hidden shadow-soft no-tap-highlight ${isPublished ? '' : 'pointer-events-none'}`}
                  >
                    <div className="w-20 h-20 flex-shrink-0">
                      {article.cover_image_url ? (
                        <img src={article.cover_image_url} className="w-full h-full object-cover" alt="" />
                      ) : (
                        <div className="w-full h-full bg-muted flex items-center justify-center">
                          <FileText size={20} className="text-muted-foreground/50" />
                        </div>
                      )}
                    </div>
                    <div className="flex-1 py-2.5 pr-3 flex flex-col justify-center min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-bold" style={{ color: cat.color }}>
                          {cat.emoji} {cat.label}
                        </span>
                      </div>
                      <h3 className="font-editorial text-sm font-bold leading-tight line-clamp-2 mt-0.5">
                        {article.title}
                      </h3>
                      <div className="flex items-center gap-2 mt-1.5">
                        <span className={`inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full ${status.bg}`} style={{ color: status.color }}>
                          <status.icon size={9} className={article.status === 'under_review' ? 'animate-spin' : ''} />
                          {status.label}
                        </span>
                        {article.reading_time_minutes && (
                          <span className="text-[10px] text-muted-foreground flex items-center gap-0.5">
                            <Clock size={9} /> {article.reading_time_minutes}m
                          </span>
                        )}
                      </div>
                    </div>
                  </Link>
                </motion.div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
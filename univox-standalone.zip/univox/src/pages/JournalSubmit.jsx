import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowLeft, Sparkles, CheckCircle2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { categories } from '@/components/journal/journalConfig';

export default function JournalSubmit() {
  const navigate = useNavigate();
  const [form, setForm] = useState({
    title: '',
    subtitle: '',
    author_name: '',
    category: 'science',
    cover_image_url: '',
    content: '',
    references: '',
  });
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [aiLoading, setAiLoading] = useState(false);
  const [aiSuggestion, setAiSuggestion] = useState(null);

  const handleChange = (field) => (e) => setForm({ ...form, [field]: e.target.value });

  const handleAIAssist = async () => {
    if (!form.content || form.content.length < 20) return;
    setAiLoading(true);
    try {
      const res = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an AI writing assistant for a student magazine. Review this article draft and provide:
1. A suggested title (if the current one can be improved)
2. Top 3 grammar issues
3. Structure suggestions
4. A 2-sentence summary

Article title: ${form.title}
Article content: ${form.content}

Respond clearly and concisely.`,
      });
      setAiSuggestion(res);
    } catch {
    } finally {
      setAiLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.title || !form.content) return;
    setSubmitting(true);
    try {
      await base44.entities.JournalArticle.create({
        ...form,
        status: 'under_review',
        reading_time_minutes: Math.max(1, Math.ceil(form.content.split(/\s+/).length / 200)),
        author_name: form.author_name || 'Anonymous',
        likes: 0,
        comments_count: 0,
        saves: 0,
      });
      setSubmitted(true);
    } catch {
    } finally {
      setSubmitting(false);
    }
  };

  if (submitted) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center px-6 text-center">
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: 'spring', damping: 15 }}
          className="w-20 h-20 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-white shadow-float mb-6"
        >
          <CheckCircle2 size={40} />
        </motion.div>
        <h1 className="font-editorial text-2xl font-bold">Submitted!</h1>
        <p className="text-sm text-muted-foreground mt-2 max-w-xs">
          Your article is now under review. You will be notified when it is published.
        </p>
        <div className="mt-4 inline-flex items-center gap-2 bg-accent/20 text-accent-foreground px-4 py-2 rounded-full text-xs font-bold">
          <span className="w-2 h-2 rounded-full bg-accent animate-pulse" /> Status: Under Review
        </div>
        <button
          onClick={() => navigate('/journal')}
          className="mt-6 bg-primary text-primary-foreground rounded-full px-6 py-3 text-sm font-bold no-tap-highlight"
        >
          Back to Journal
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen pb-28">
      <div className="sticky top-0 z-40 glass-strong">
        <div className="px-4 py-3 flex items-center gap-2">
          <Link to="/journal" className="no-tap-highlight">
            <ArrowLeft size={20} />
          </Link>
          <h1 className="font-editorial text-xl font-bold">Submit Article</h1>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="px-5 mt-4 space-y-5">
        <div>
          <label className="text-xs font-bold text-muted-foreground uppercase tracking-wide">Title</label>
          <input
            value={form.title}
            onChange={handleChange('title')}
            placeholder="The Future of..."
            className="w-full mt-1.5 bg-card rounded-2xl px-4 py-3 text-base font-editorial font-semibold outline-none focus:ring-2 focus:ring-primary/30 no-tap-highlight"
            required
          />
        </div>

        <div>
          <label className="text-xs font-bold text-muted-foreground uppercase tracking-wide">Subtitle</label>
          <input
            value={form.subtitle}
            onChange={handleChange('subtitle')}
            placeholder="A brief description..."
            className="w-full mt-1.5 bg-card rounded-2xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-primary/30 no-tap-highlight"
          />
        </div>

        <div>
          <label className="text-xs font-bold text-muted-foreground uppercase tracking-wide">Your Name</label>
          <input
            value={form.author_name}
            onChange={handleChange('author_name')}
            placeholder="Your name"
            className="w-full mt-1.5 bg-card rounded-2xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-primary/30 no-tap-highlight"
          />
        </div>

        <div>
          <label className="text-xs font-bold text-muted-foreground uppercase tracking-wide">Category</label>
          <div className="flex gap-2 flex-wrap mt-1.5">
            {categories.map((cat) => (
              <button
                key={cat.id}
                type="button"
                onClick={() => setForm({ ...form, category: cat.id })}
                className={`px-3 py-1.5 rounded-full text-xs font-bold no-tap-highlight ${
                  form.category === cat.id ? 'text-white' : 'bg-card text-muted-foreground'
                }`}
                style={form.category === cat.id ? { background: cat.color } : {}}
              >
                {cat.emoji} {cat.label}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="text-xs font-bold text-muted-foreground uppercase tracking-wide">Cover Image URL</label>
          <input
            value={form.cover_image_url}
            onChange={handleChange('cover_image_url')}
            placeholder="https://..."
            className="w-full mt-1.5 bg-card rounded-2xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-primary/30 no-tap-highlight"
          />
          {form.cover_image_url && (
            <div className="mt-2 rounded-2xl overflow-hidden aspect-[4/3]">
              <img src={form.cover_image_url} className="w-full h-full object-cover" alt="Cover preview" />
            </div>
          )}
        </div>

        <div>
          <label className="text-xs font-bold text-muted-foreground uppercase tracking-wide">
            Article (Markdown supported)
          </label>
          <textarea
            value={form.content}
            onChange={handleChange('content')}
            placeholder={'## Your heading\n\nWrite your article here...'}
            rows={10}
            className="w-full mt-1.5 bg-card rounded-2xl px-4 py-3 text-sm leading-7 outline-none focus:ring-2 focus:ring-primary/30 resize-y no-tap-highlight"
            required
          />
        </div>

        <div>
          <button
            type="button"
            onClick={handleAIAssist}
            disabled={aiLoading || !form.content}
            className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-primary/10 to-secondary/10 text-primary rounded-2xl py-3 text-sm font-bold no-tap-highlight disabled:opacity-50"
          >
            <Sparkles size={16} /> {aiLoading ? 'Analyzing...' : 'AI Writing Assistant'}
          </button>
          <AnimatePresence>
            {aiSuggestion && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="mt-2 bg-gradient-to-br from-primary/5 to-secondary/5 rounded-2xl p-4 border border-primary/10 overflow-hidden"
              >
                <p className="text-xs font-bold text-primary mb-2 flex items-center gap-1">
                  <Sparkles size={12} /> AI Suggestions
                </p>
                <div className="text-sm text-foreground/80 whitespace-pre-wrap leading-7">{aiSuggestion}</div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <div>
          <label className="text-xs font-bold text-muted-foreground uppercase tracking-wide">References</label>
          <textarea
            value={form.references}
            onChange={handleChange('references')}
            placeholder="1. Author, Title, Year..."
            rows={4}
            className="w-full mt-1.5 bg-card rounded-2xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-primary/30 resize-y no-tap-highlight"
          />
        </div>

        <button
          type="submit"
          disabled={submitting || !form.title || !form.content}
          className="w-full bg-foreground text-background rounded-2xl py-4 text-sm font-bold no-tap-highlight disabled:opacity-50"
        >
          {submitting ? 'Submitting...' : 'Submit for Review'}
        </button>
      </form>
    </div>
  );
}
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ChevronLeft, Clock, Video, MessageCircle, Award, CheckCircle, FileText, Megaphone, Bell } from 'lucide-react';
import { base44 } from '@/api/base44Client';

const notifIcons = {
  lesson: Clock,
  live: Video,
  message: MessageCircle,
  certificate: Award,
  application: CheckCircle,
  materials: FileText,
  announcement: Megaphone,
  default: Bell,
};

const notifColors = {
  lesson: '#1E4DFF',
  live: '#1E4DFF',
  message: '#FF6FAE',
  certificate: '#FFD84D',
  application: '#FF8A3D',
  materials: '#1E4DFF',
  announcement: '#FF6FAE',
  default: '#9ca3af',
};

export default function Notifications() {
  const navigate = useNavigate();
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    base44.entities.AppNotification.list('-created_date').then(setNotifications).catch(() => {}).finally(() => setLoading(false));
  }, []);

  return (
    <div className="min-h-screen pb-28">
      <header className="px-5 pt-[calc(0.75rem+var(--safe-top))] pb-3 flex items-center gap-3">
        <button onClick={() => navigate('/home')} className="w-9 h-9 flex items-center justify-center no-tap-highlight">
          <ChevronLeft size={24} />
        </button>
        <div>
          <h1 className="text-2xl font-extrabold tracking-tight">Notifications</h1>
        </div>
      </header>

      <div className="px-5 mt-2 space-y-2">
        {loading
          ? [1, 2, 3, 4, 5].map(i => <div key={i} className="h-20 rounded-2xl skeleton" />)
          : notifications.length === 0
          ? (
            <div className="text-center py-16">
              <div className="w-16 h-16 rounded-full bg-card flex items-center justify-center mx-auto mb-3">
                <Bell size={28} className="text-muted-foreground/50" />
              </div>
              <p className="text-sm text-muted-foreground">No notifications yet.</p>
            </div>
          )
          : notifications.map((n, i) => {
              const Icon = notifIcons[n.type] || notifIcons.default;
              const color = notifColors[n.type] || notifColors.default;
              return (
                <motion.div
                  key={n.id}
                  initial={{ opacity: 0, x: -16 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.06, duration: 0.3 }}
                  className={`rounded-2xl p-4 flex items-start gap-3 shadow-soft ${n.read ? 'bg-card' : 'bg-card border-l-4'}`}
                  style={!n.read ? { borderLeftColor: color } : {}}
                >
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: `${color}15` }}>
                    <Icon size={18} style={{ color }} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-sm leading-tight">{n.title}</p>
                    {n.description && <p className="text-xs text-muted-foreground mt-0.5">{n.description}</p>}
                    {n.timestamp && <p className="text-[10px] text-muted-foreground/70 mt-1">{n.timestamp}</p>}
                  </div>
                  {!n.read && <div className="w-2 h-2 rounded-full bg-primary flex-shrink-0 mt-2" />}
                </motion.div>
              );
            })}
      </div>
    </div>
  );
}
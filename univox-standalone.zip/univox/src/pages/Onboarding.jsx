import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowLeft, Check, Sparkles, GraduationCap, BookOpen, Globe2, Star, Brain } from 'lucide-react';
import { useUserProgress } from '@/lib/UserProgressContext';

const PROGRAMS = [
  { id: 'English', label: 'English', flag: '🇬🇧', color: '#1E4DFF', icon: Globe2, description: "The world's language. Connect anywhere, with anyone." },
  { id: 'Italian', label: 'Italian', flag: '🇮🇹', color: '#FF6FAE', icon: Globe2, description: 'The language of art, music and la dolce vita.' },
  { id: 'French', label: 'French', flag: '🇫🇷', color: '#FF6FAE', icon: Globe2, description: 'The language of love, art and elegance.' },
  { id: 'Spanish', label: 'Spanish', flag: '🇪🇸', color: '#FFD84D', icon: Globe2, description: 'Vibrant and warm, spoken across two continents.' },
  { id: 'Korean', label: 'Korean', flag: '🇰🇷', color: '#1E4DFF', icon: Globe2, description: 'The language of K-pop, drama and technology.' },
  { id: 'German', label: 'German', flag: '🇩🇪', color: '#FF8A3D', icon: Globe2, description: 'The language of engineering, philosophy and science.' },
];

const CEFR_LEVELS = [
  { id: 'A1', label: 'A1', sub: 'Beginner', emoji: '🌱' },
  { id: 'A2', label: 'A2', sub: 'Elementary', emoji: '🌿' },
  { id: 'B1', label: 'B1', sub: 'Intermediate', emoji: '🚀' },
  { id: 'B2', label: 'B2', sub: 'Upper-Int.', emoji: '⭐' },
  { id: 'C1', label: 'C1', sub: 'Advanced', emoji: '🏆' },
  { id: 'C2', label: 'C2', sub: 'Mastery', emoji: '👑' },
];

const QUIZ = [
  {
    q: 'How well do you understand materials in your chosen language?',
    options: [
      { label: 'Only basic words', level: 'A2' },
      { label: 'Understand general meaning', level: 'B1' },
      { label: 'Read articles and discuss fluently', level: 'C1' },
    ],
  },
  {
    q: 'What is your previous experience with the language?',
    options: [
      { label: 'Just starting out', level: 'A2' },
      { label: 'Can hold simple conversations', level: 'B1' },
      { label: 'Comfortable in complex discussions', level: 'C1' },
    ],
  },
  {
    q: 'How often do you use the language?',
    options: [
      { label: 'Rarely', level: 'A2' },
      { label: 'Read posts and watch videos', level: 'B1' },
      { label: 'Learn / study in it regularly', level: 'C1' },
    ],
  },
];

const LEVEL_LABEL = { A1: 'A1', A2: 'A2', B1: 'B1', B2: 'B2', C1: 'C1', C2: 'C2' };

export default function Onboarding() {
  const navigate = useNavigate();
  const { completeOnboarding } = useUserProgress();
  const [step, setStep] = useState(0); // 0 role, 1 program, 2 level
  const [role, setRole] = useState('');
  const [program, setProgram] = useState('');
  const [showQuiz, setShowQuiz] = useState(false);
  const [quizAnswers, setQuizAnswers] = useState([null, null, null]);
  const [resultLevel, setResultLevel] = useState(null);
  const [finishing, setFinishing] = useState(false);

  const finish = async (level) => {
    setFinishing(true);
    try {
      await completeOnboarding({ role: 'student', program, level });
    } catch (e) {}
    setFinishing(false);
    navigate('/home', { replace: true });
  };

  const computeLevel = () => {
    const counts = { A2: 0, B1: 0, C1: 0 };
    quizAnswers.forEach((a) => { if (a) counts[a] = (counts[a] || 0) + 1; });
    let best = 'B1';
    let max = -1;
    ['C1', 'B1', 'A2'].forEach((l) => {
      if (counts[l] > max) { max = counts[l]; best = l; }
    });
    return best;
  };

  const back = () => {
    if (showQuiz) { setShowQuiz(false); return; }
    if (resultLevel) { setResultLevel(null); return; }
    setStep((s) => Math.max(0, s - 1));
  };

  return (
    <div className="min-h-screen max-w-md mx-auto bg-gradient-to-b from-background via-background to-primary/5 flex flex-col relative">
      <div className="pt-[calc(3.5rem+var(--safe-top))] px-5">
        <div className="flex items-center gap-3">
          {step > 0 && !showQuiz && !resultLevel && (
            <button onClick={back} className="w-9 h-9 rounded-full bg-card flex items-center justify-center shadow-soft no-tap-highlight">
              <ArrowLeft size={16} className="text-foreground/70" />
            </button>
          )}
          {(showQuiz || resultLevel) && (
            <button onClick={back} className="w-9 h-9 rounded-full bg-card flex items-center justify-center shadow-soft no-tap-highlight">
              <ArrowLeft size={16} className="text-foreground/70" />
            </button>
          )}
          <div className="flex-1 h-1.5 bg-muted rounded-full overflow-hidden">
            <motion.div
              className="h-full bg-gradient-to-r from-primary to-secondary rounded-full"
              animate={{ width: `${((step + (showQuiz ? 0.5 : 0) + (resultLevel ? 1 : 0)) / 3) * 100}%` }}
              transition={{ duration: 0.4, ease: 'easeOut' }}
            />
          </div>
          <span className="text-xs font-semibold text-muted-foreground">{step + 1}/3</span>
        </div>
      </div>

      <div className="flex-1 px-6 pt-8 pb-8 flex flex-col">
        <AnimatePresence mode="wait">
          {/* STEP 1 — ROLE */}
          {step === 0 && (
            <motion.div
              key="role"
              initial={{ opacity: 0, x: 24 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -24 }}
              transition={{ duration: 0.3 }}
              className="flex-1 flex flex-col"
            >
              <h1 className="text-3xl font-extrabold tracking-tight">Who are you?</h1>
              <p className="text-muted-foreground text-sm mt-2 mb-7">Tell us a bit about yourself so we can personalize your experience.</p>
              <div className="space-y-3">
                <RoleButton
                  active={role === 'student'}
                  onClick={() => setRole('student')}
                  emoji="🎓"
                  icon={GraduationCap}
                  title="I am a Student"
                  subtitle="Join groups, attend live lessons, track your progress."
                  color="#1E4DFF"
                />
                <RoleButton
                  active={role === 'teacher'}
                  onClick={() => setRole('teacher')}
                  emoji="👩‍🏫"
                  icon={BookOpen}
                  title="I am a Teacher"
                  subtitle="Lead groups, share materials, guide learners."
                  color="#FF6FAE"
                />
              </div>
              <button
                onClick={() => {
                  if (role === 'teacher') { navigate('/teacher-application'); return; }
                  if (role === 'student') setStep(1);
                }}
                disabled={!role}
                className="mt-7 w-full bg-primary text-primary-foreground rounded-2xl py-4 text-base font-bold shadow-card disabled:opacity-40 no-tap-highlight"
              >
                Continue
              </button>
            </motion.div>
          )}

          {/* STEP 2 — PROGRAM */}
          {step === 1 && (
            <motion.div
              key="program"
              initial={{ opacity: 0, x: 24 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -24 }}
              transition={{ duration: 0.3 }}
              className="flex-1 flex flex-col"
            >
              <h1 className="text-3xl font-extrabold tracking-tight">Select your program</h1>
              <p className="text-muted-foreground text-sm mt-2 mb-1">Choose a track to begin your journey.</p>
              <p className="text-xs italic text-muted-foreground/80 mb-6">(Select one program to start with, you can always add more later in your profile)</p>
              <div className="grid grid-cols-2 gap-3">
                {PROGRAMS.map((p) => {
                  const active = program === p.id;
                  const I = p.icon;
                  return (
                    <button
                      key={p.id}
                      onClick={() => setProgram(p.id)}
                      className={`relative rounded-3xl p-5 text-left overflow-hidden border-2 transition-all no-tap-highlight shadow-soft ${active ? 'border-primary' : 'border-transparent bg-card'}`}
                      style={active ? { background: `${p.color}12` } : undefined}
                    >
                      <div className="text-4xl mb-2">{p.flag}</div>
                      <div className="flex items-center gap-1.5">
                        <I size={15} style={{ color: p.color }} />
                        <p className="font-bold text-base">{p.label}</p>
                      </div>
                      <p className="text-[11px] text-muted-foreground mt-1 leading-snug">{p.description}</p>
                      {active && (
                        <div className="absolute top-3 right-3 w-6 h-6 rounded-full bg-primary flex items-center justify-center">
                          <Check size={13} className="text-primary-foreground" />
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>
              <button
                onClick={() => program && setStep(2)}
                disabled={!program}
                className="mt-7 w-full bg-primary text-primary-foreground rounded-2xl py-4 text-base font-bold shadow-card disabled:opacity-40 no-tap-highlight"
              >
                Continue
              </button>
            </motion.div>
          )}

          {/* STEP 3 — LEVEL */}
          {step === 2 && !showQuiz && !resultLevel && (
            <motion.div
              key="level"
              initial={{ opacity: 0, x: 24 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -24 }}
              transition={{ duration: 0.3 }}
              className="flex-1 flex flex-col"
            >
              <h1 className="text-3xl font-extrabold tracking-tight">Choose your current level</h1>
              <p className="text-muted-foreground text-sm mt-2 mb-6">Pick the CEFR level that best describes you right now.</p>
              <p className="text-xs font-bold text-muted-foreground uppercase tracking-wide mb-2">Select your CEFR level</p>
              <div className="grid grid-cols-3 gap-2.5 mb-4">
                {CEFR_LEVELS.map((l) => (
                  <button
                    key={l.id}
                    onClick={() => finish(l.id)}
                    disabled={finishing}
                    className="rounded-2xl p-4 text-center border-2 border-transparent bg-card shadow-soft no-tap-highlight disabled:opacity-50"
                  >
                    <div className="text-2xl mb-1">{l.emoji}</div>
                    <p className="font-bold text-base">{l.label}</p>
                    <p className="text-[10px] text-muted-foreground mt-0.5">{l.sub}</p>
                  </button>
                ))}
              </div>
              <div className="h-px bg-border/50 my-4" />
              <p className="text-xs font-bold text-muted-foreground uppercase tracking-wide mb-2">Not sure?</p>
              <button
                onClick={() => setShowQuiz(true)}
                className="w-full flex items-center gap-3 p-4 rounded-2xl bg-gradient-to-br from-primary/10 to-secondary/10 border border-primary/20 no-tap-highlight"
              >
                <div className="w-11 h-11 rounded-xl bg-primary/15 flex items-center justify-center">
                  <Brain size={20} className="text-primary" />
                </div>
                <div className="flex-1 text-left">
                  <p className="font-bold text-sm">I don't know my level</p>
                  <p className="text-xs text-muted-foreground">Take a quick 3-question test</p>
                </div>
                <Sparkles size={16} className="text-primary" />
              </button>
            </motion.div>
          )}

          {/* QUIZ */}
          {step === 2 && showQuiz && !resultLevel && (
            <motion.div
              key="quiz"
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -16 }}
              transition={{ duration: 0.3 }}
              className="flex-1 flex flex-col"
            >
              <h1 className="text-2xl font-extrabold tracking-tight">Quick Level Test</h1>
              <p className="text-muted-foreground text-sm mt-1 mb-5">Answer 3 short questions — we'll find your level.</p>
              <div className="space-y-4 flex-1">
                {QUIZ.map((q, qi) => (
                  <div key={qi}>
                    <p className="font-semibold text-sm mb-2">{qi + 1}. {q.q}</p>
                    <div className="space-y-2">
                      {q.options.map((opt) => {
                        const selected = quizAnswers[qi] === opt.level;
                        return (
                          <button
                            key={opt.label}
                            onClick={() => setQuizAnswers((a) => a.map((v, i) => (i === qi ? opt.level : v)))}
                            className={`w-full text-left p-3 rounded-xl border-2 text-sm font-medium no-tap-highlight transition-all ${selected ? 'border-primary bg-primary/5' : 'border-transparent bg-card'}`}
                          >
                            {opt.label}
                            {selected && <Check size={15} className="inline ml-2 text-primary" />}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
              <button
                onClick={() => setResultLevel(computeLevel())}
                disabled={quizAnswers.some((a) => !a)}
                className="mt-5 w-full bg-primary text-primary-foreground rounded-2xl py-4 text-base font-bold shadow-card disabled:opacity-40 no-tap-highlight"
              >
                See my level
              </button>
            </motion.div>
          )}

          {/* RESULT */}
          {step === 2 && resultLevel && (
            <motion.div
              key="result"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              transition={{ duration: 0.35 }}
              className="flex-1 flex flex-col items-center justify-center text-center"
            >
              <motion.div
                initial={{ scale: 0.5, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ type: 'spring', damping: 12, stiffness: 200 }}
                className="w-24 h-24 rounded-3xl bg-gradient-to-br from-primary to-secondary flex items-center justify-center mb-5 shadow-float"
              >
                <Star size={42} className="text-white" />
              </motion.div>
              <p className="text-xs font-bold tracking-widest text-primary uppercase">Based on your answers</p>
              <h2 className="text-3xl font-extrabold mt-2">Your Level: {LEVEL_LABEL[resultLevel]}!</h2>
              <p className="text-muted-foreground text-sm mt-3 max-w-xs">We've tailored your starting point. You can adjust anytime as you grow.</p>
              <button
                onClick={() => finish(resultLevel)}
                disabled={finishing}
                className="mt-8 w-full max-w-sm bg-gradient-to-r from-primary to-secondary text-primary-foreground rounded-2xl py-4 text-base font-bold shadow-card no-tap-highlight disabled:opacity-60"
              >
                {finishing ? 'Setting up…' : 'Start Learning'}
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

function RoleButton({ active, onClick, emoji, icon: Icon, title, subtitle, color }) {
  return (
    <button
      onClick={onClick}
      className={`w-full flex items-center gap-4 p-4 rounded-3xl border-2 transition-all text-left no-tap-highlight shadow-soft ${active ? 'border-primary bg-primary/5' : 'border-transparent bg-card'}`}
    >
      <div className="w-14 h-14 rounded-2xl flex items-center justify-center text-3xl" style={{ background: active ? `${color}15` : 'hsl(var(--muted))' }}>
        {emoji}
      </div>
      <div className="flex-1">
        <div className="flex items-center gap-1.5">
          <Icon size={16} style={{ color }} />
          <p className="font-bold text-base">{title}</p>
        </div>
        <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">{subtitle}</p>
      </div>
      <div className={`w-6 h-6 rounded-full flex items-center justify-center ${active ? 'bg-primary text-primary-foreground' : 'border-2 border-border'}`}>
        {active && <Check size={14} />}
      </div>
    </button>
  );
}
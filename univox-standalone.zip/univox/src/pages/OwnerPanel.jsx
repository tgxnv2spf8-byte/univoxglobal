import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ChevronLeft, ChevronRight, Users, GraduationCap, Check, X, Crown, Loader2, Plus, Layers, BarChart3, ClipboardList, Megaphone, Trash2, Newspaper } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { isOwner } from '@/lib/roles';
import IOSSelect from '@/components/IOSSelect';
import { CURRENCIES, SUBSCRIPTION_TYPES } from '@/lib/payments';

const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

export default function OwnerPanel() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [tab, setTab] = useState('applications');
  const [apps, setApps] = useState([]);
  const [users, setUsers] = useState([]);
  const [groups, setGroups] = useState([]);
  const [programs, setPrograms] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    base44.auth.me().then((u) => {
      setUser(u);
      if (!isOwner(u)) navigate('/home');
    }).catch(() => navigate('/home'));
    loadAll();
  }, []);

  const loadAll = async () => {
    setLoading(true);
    const [a, u, g, p] = await Promise.all([
      base44.entities.TeacherApplication.list().catch(() => []),
      base44.entities.User.list().catch(() => []),
      base44.entities.Group.list().catch(() => []),
      base44.entities.Program.list().catch(() => []),
    ]);
    setApps(a || []); setUsers(u || []); setGroups(g || []); setPrograms(p || []);
    setLoading(false);
  };

  const approve = async (app) => {
    const u = await base44.entities.User.get(app.created_by_id).catch(() => null);
    const roles = Array.from(new Set([...(u?.roles || ['student']), 'teacher']));
    await base44.entities.User.update(app.created_by_id, { teacher_status: 'approved', roles }).catch(() => {});
    await base44.entities.TeacherApplication.update(app.id, { status: 'approved' });
    loadAll();
  };
  const reject = async (app) => {
    await base44.entities.User.update(app.created_by_id, { teacher_status: 'rejected' }).catch(() => {});
    await base44.entities.TeacherApplication.update(app.id, { status: 'rejected' });
    loadAll();
  };
  const assignGroup = async (app, groupId) => {
    if (!groupId) return;
    const g = groups.find((x) => x.id === groupId);
    await base44.entities.Group.update(groupId, { assigned_teacher_id: app.created_by_id, assigned_teacher_email: app.email, teacher: app.full_name }).catch(() => {});
    const prev = (app.assigned_group_ids || '').split(',').filter(Boolean);
    if (!prev.includes(groupId)) prev.push(groupId);
    await base44.entities.TeacherApplication.update(app.id, { assigned_group_ids: prev.join(',') });
    loadAll();
  };
  const deleteUser = async (id) => {
    if (!confirm('Delete this user?')) return;
    await base44.entities.User.delete(id).catch(() => {});
    loadAll();
  };

  const stats = [
    { label: 'Users', value: users.length, icon: Users, color: '#1E4DFF' },
    { label: 'Communities', value: groups.length, icon: Layers, color: '#FF6FAE' },
    { label: 'Programs', value: programs.length, icon: GraduationCap, color: '#FFD84D' },
    { label: 'Pending', value: apps.filter((a) => a.status === 'pending').length, icon: ClipboardList, color: '#FF8A3D' },
  ];

  if (!user) return null;

  return (
    <div className="min-h-screen pb-28">
      <header className="px-5 pt-[calc(0.75rem+var(--safe-top))] pb-3 flex items-center gap-3">
        <button onClick={() => navigate('/profile')} className="w-10 h-10 rounded-full bg-card flex items-center justify-center no-tap-highlight"><ChevronLeft size={22} /></button>
        <div>
          <h1 className="text-2xl font-extrabold tracking-tight flex items-center gap-2"><Crown size={20} className="text-accent-foreground" style={{ color: '#FFD84D' }} /> Owner Panel</h1>
          <p className="text-muted-foreground text-xs">Manage UNIVOX</p>
        </div>
      </header>

      <div className="px-5 mt-3 grid grid-cols-4 gap-2.5">
        {stats.map((s) => (
          <div key={s.label} className="bg-card rounded-2xl p-3 text-center shadow-soft">
            <s.icon size={16} className="mx-auto" style={{ color: s.color }} />
            <p className="text-xl font-extrabold mt-1" style={{ color: s.color }}>{s.value}</p>
            <p className="text-[9px] text-muted-foreground font-medium">{s.label}</p>
          </div>
        ))}
      </div>

      <div className="px-5 mt-3 grid grid-cols-2 gap-3">
        <button onClick={() => navigate('/announcements-manager')} className="bg-gradient-to-br from-primary to-secondary text-primary-foreground rounded-2xl p-3.5 flex flex-col gap-2 shadow-card no-tap-highlight">
          <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center"><Megaphone size={18} /></div>
          <div className="text-left">
            <p className="font-bold text-xs">Announcements</p>
            <p className="text-[10px] opacity-80">Create & schedule</p>
          </div>
        </button>
        <button onClick={() => navigate('/article-manager')} className="bg-gradient-to-br from-foreground to-primary text-white rounded-2xl p-3.5 flex flex-col gap-2 shadow-card no-tap-highlight">
          <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center"><Newspaper size={18} /></div>
          <div className="text-left">
            <p className="font-bold text-xs">Articles</p>
            <p className="text-[10px] opacity-80">Research magazine</p>
          </div>
        </button>
      </div>

      <div className="px-5 mt-5 flex gap-1.5">
        {[['applications', 'Applications'], ['users', 'Users'], ['programs', 'Programs']].map(([k, l]) => (
          <button key={k} onClick={() => setTab(k)} className={`flex-1 py-2 rounded-xl text-xs font-bold no-tap-highlight ${tab === k ? 'bg-primary text-primary-foreground' : 'bg-card text-muted-foreground'}`}>{l}</button>
        ))}
      </div>

      <div className="px-5 mt-4">
        {loading ? <div className="h-24 skeleton rounded-3xl" /> : tab === 'applications' && <ApplicationsTab apps={apps} groups={groups} approve={approve} reject={reject} assignGroup={assignGroup} />}
        {!loading && tab === 'users' && <UsersTab users={users} onDelete={deleteUser} />}
        {!loading && tab === 'programs' && <ProgramsTab programs={programs} apps={apps} groups={groups} onUpdated={loadAll} />}
      </div>
    </div>
  );
}

function ApplicationsTab({ apps, groups, approve, reject, assignGroup }) {
  if (!apps.length) return <Empty label="No applications" />;
  const unassigned = (app) => groups.filter((g) => !((app.assigned_group_ids || '').split(',').includes(g.id)));
  return (
    <div className="space-y-3">
      {apps.map((app) => (
        <motion.div key={app.id} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="bg-card rounded-3xl p-4 shadow-soft">
          <div className="flex items-center gap-3">
            {app.photo_url ? <img src={app.photo_url} alt="" className="w-12 h-12 rounded-2xl object-cover" /> : <div className="w-12 h-12 rounded-2xl bg-primary/15 flex items-center justify-center"><GraduationCap size={20} className="text-primary" /></div>}
            <div className="flex-1 min-w-0">
              <p className="font-bold text-sm truncate">{app.full_name}</p>
              <p className="text-xs text-muted-foreground truncate">{app.email}</p>
            </div>
            <StatusBadge status={app.status} />
          </div>
          <div className="mt-3 space-y-1 text-xs text-muted-foreground">
            <p><b className="text-foreground/70">Languages:</b> {app.languages}</p>
            <p><b className="text-foreground/70">Proficiency:</b> {app.proficiency} · <b className="text-foreground/70">Experience:</b> {app.experience}</p>
            {app.about && <p><b className="text-foreground/70">About:</b> {app.about}</p>}
            <p><b className="text-foreground/70">Availability:</b> {app.availability} · <b className="text-foreground/70">TZ:</b> {app.timezone}</p>
          </div>
          {app.status === 'pending' && (
            <div className="flex gap-2 mt-3">
              <button onClick={() => approve(app)} className="flex-1 bg-green-500 text-white rounded-xl py-2 text-xs font-bold flex items-center justify-center gap-1 no-tap-highlight"><Check size={14} /> Approve</button>
              <button onClick={() => reject(app)} className="flex-1 bg-destructive text-destructive-foreground rounded-xl py-2 text-xs font-bold flex items-center justify-center gap-1 no-tap-highlight"><X size={14} /> Reject</button>
            </div>
          )}
          {app.status === 'approved' && (
            <div className="mt-3">
              <p className="text-[11px] font-bold text-foreground/60 uppercase mb-1.5">Assign to group</p>
              <IOSSelect
                value=""
                onChange={(groupId) => assignGroup(app, groupId)}
                placeholder="Select a group…"
                className="w-full text-xs"
                options={unassigned(app).map((g) => ({ value: g.id, label: `${g.name} · ${g.program_title}` }))}
              />
              {app.assigned_group_ids && <p className="text-[10px] text-green-600 mt-1.5">Assigned: {app.assigned_group_ids.split(',').length} group(s)</p>}
            </div>
          )}
        </motion.div>
      ))}
    </div>
  );
}

function UsersTab({ users, onDelete }) {
  if (!users.length) return <Empty label="No users" />;
  return (
    <div className="space-y-2">
      {users.map((u) => (
        <div key={u.id} className="bg-card rounded-2xl p-3.5 flex items-center gap-3 shadow-soft">
          <div className="w-10 h-10 rounded-xl bg-primary/15 flex items-center justify-center text-primary font-bold text-sm">{(u.full_name || u.email || '?')[0]}</div>
          <div className="flex-1 min-w-0">
            <p className="font-semibold text-sm truncate">{u.full_name || '—'}</p>
            <p className="text-xs text-muted-foreground truncate">{u.email}</p>
            <div className="flex gap-1 mt-1 flex-wrap">
              {(u.roles || []).map((r) => <span key={r} className="text-[9px] font-bold bg-primary/10 text-primary rounded-full px-2 py-0.5">{r}</span>)}
              {u.teacher_status && u.teacher_status !== 'none' && <span className="text-[9px] font-bold bg-secondary/10 text-secondary rounded-full px-2 py-0.5">{u.teacher_status}</span>}
            </div>
          </div>
          <button onClick={() => onDelete(u.id)} className="w-8 h-8 rounded-lg bg-destructive/10 text-destructive flex items-center justify-center no-tap-highlight"><X size={15} /></button>
        </div>
      ))}
    </div>
  );
}

function ProgramsTab({ programs, apps, groups, onUpdated }) {
  const [editingId, setEditingId] = useState(null);
  const [edit, setEdit] = useState({});
  const [form, setForm] = useState({ title: '', description: '', category: 'language', flag: '📚', color: '#1E4DFF', image: '', teacher_id: '' });
  const [creating, setCreating] = useState(false);

  const [editGroupId, setEditGroupId] = useState(null);
  const [gEdit, setGEdit] = useState({});
  const [addProgramId, setAddProgramId] = useState(null);
  const [newGroup, setNewGroup] = useState({ name: '', level: 'B1', day: 'Monday', time: '18:00', description: '', flag: '', research: '' });
  const [savingGroup, setSavingGroup] = useState(false);

  const approved = apps.filter((a) => a.status === 'approved');

  const teacherNameFor = (teacherId) => {
    const a = approved.find((x) => x.created_by_id === teacherId);
    return a ? a.full_name : '';
  };

  const communitiesOf = (p) => groups.filter((g) => g.program_title === p.title);

  const startEdit = (p) => {
    setEditingId(p.id);
    setEdit({
      title: p.title || '',
      description: p.description || '',
      category: p.category || 'language',
      flag_emoji: p.flag_emoji || '',
      accent_color: p.accent_color || '#1E4DFF',
      image_url: p.image_url || '',
      teacher_id: p.teacher_id || '',
      is_free: p.is_free !== false,
      price: p.price || 0,
      currency: p.currency || 'USD',
      free_trial: p.free_trial || false,
      trial_days: p.trial_days || 0,
      stripe_product_id: p.stripe_product_id || '',
      stripe_price_id: p.stripe_price_id || '',
      subscription_type: p.subscription_type || 'monthly',
      research_hero_image: p.research_hero_image || '',
      research_benefits: p.research_benefits || '',
      research_requirements: p.research_requirements || '',
      research_timeline: p.research_timeline || '',
      research_mentors: p.research_mentors || '',
      research_outcomes: p.research_outcomes || '',
    });
  };

  const saveEdit = async (p) => {
    const newTitle = edit.title.trim() || p.title;
    const teacherName = teacherNameFor(edit.teacher_id);
    await base44.entities.Program.update(p.id, {
      title: newTitle,
      description: edit.description,
      category: edit.category,
      flag_emoji: edit.flag_emoji,
      accent_color: edit.accent_color,
      image_url: edit.image_url,
      teacher_id: edit.teacher_id || '',
      teacher_name: teacherName,
      is_free: edit.is_free,
      price: Number(edit.price) || 0,
      currency: edit.currency,
      free_trial: edit.free_trial,
      trial_days: Number(edit.trial_days) || 0,
      stripe_product_id: edit.stripe_product_id,
      stripe_price_id: edit.stripe_price_id,
      subscription_type: edit.subscription_type,
      research_hero_image: edit.research_hero_image,
      research_benefits: edit.research_benefits,
      research_requirements: edit.research_requirements,
      research_timeline: edit.research_timeline,
      research_mentors: edit.research_mentors,
      research_outcomes: edit.research_outcomes,
    });
    try {
      const linked = await base44.entities.Group.filter({ program_title: p.title });
      await Promise.all((linked || []).map((g) =>
        base44.entities.Group.update(g.id, {
          program_title: newTitle,
          flag_emoji: edit.flag_emoji,
          description: edit.description,
          teacher: teacherName || g.teacher,
        })
      ));
    } catch (e) {}
    setEditingId(null);
    onUpdated();
  };

  const remove = async (p) => {
    if (!confirm(`Delete program "${p.title}"?`)) return;
    await base44.entities.Program.delete(p.id).catch(() => {});
    onUpdated();
  };

  const create = async () => {
    if (!form.title.trim()) return;
    setCreating(true);
    const teacherName = teacherNameFor(form.teacher_id);
    await base44.entities.Program.create({
      title: form.title.trim(),
      description: form.description,
      category: form.category,
      flag_emoji: form.flag,
      accent_color: form.color,
      image_url: form.image,
      teacher_id: form.teacher_id || '',
      teacher_name: teacherName,
      is_free: true,
      currency: 'USD',
      subscription_type: 'monthly',
      price: 0,
    });
    await base44.entities.Group.create({
      name: `${form.title.trim()} Community`,
      program_title: form.title.trim(),
      teacher: teacherName,
      day_of_week: 'Monday',
      time: '18:00',
      level: 'B1',
      member_count: 0,
      capacity: 20,
      meet_link: '',
      flag_emoji: form.flag,
      description: form.description,
      is_archived: false,
      member_ids: [],
    }).catch(() => {});
    setForm({ title: '', description: '', category: 'language', flag: '📚', color: '#1E4DFF', image: '', teacher_id: '' });
    setCreating(false);
    onUpdated();
  };

  const startGroupEdit = (g) => {
    setEditGroupId(g.id);
    setGEdit({
      name: g.name || '',
      level: g.level || '',
      day_of_week: g.day_of_week || 'Monday',
      time: g.time || '18:00',
      flag_emoji: g.flag_emoji || '',
      description: g.description || '',
      research_opportunities: g.research_opportunities || '',
    });
  };

  const saveGroupEdit = async (g) => {
    await base44.entities.Group.update(g.id, {
      name: gEdit.name.trim() || g.name,
      level: gEdit.level,
      day_of_week: gEdit.day_of_week,
      time: gEdit.time,
      flag_emoji: gEdit.flag_emoji,
      description: gEdit.description,
      research_opportunities: gEdit.research_opportunities,
    });
    setEditGroupId(null);
    onUpdated();
  };

  const toggleArchive = async (g) => {
    await base44.entities.Group.update(g.id, { is_archived: !g.is_archived });
    onUpdated();
  };

  const startAdd = (p) => {
    setAddProgramId(p.id);
    setNewGroup({ name: `${p.title} `, level: 'B1', day: 'Monday', time: '18:00', description: p.description || '', flag: p.flag_emoji || '', research: '' });
  };

  const createGroup = async (p) => {
    if (!newGroup.name.trim()) return;
    setSavingGroup(true);
    await base44.entities.Group.create({
      name: newGroup.name.trim(),
      program_title: p.title,
      teacher: p.teacher_name || '',
      day_of_week: newGroup.day,
      time: newGroup.time,
      level: newGroup.level,
      member_count: 0,
      capacity: 20,
      flag_emoji: newGroup.flag,
      description: newGroup.description,
      is_archived: false,
      member_ids: [],
      research_opportunities: newGroup.research,
    });
    setAddProgramId(null);
    setSavingGroup(false);
    onUpdated();
  };

  return (
    <div className="space-y-4">
      <div className="bg-card rounded-3xl p-4 shadow-soft space-y-3">
        <p className="text-xs font-bold text-foreground/70 uppercase tracking-wide flex items-center gap-1.5"><Plus size={13} /> Create Program</p>
        <input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="Program title (e.g. English)" className="w-full bg-background rounded-xl px-3 py-2.5 text-sm font-medium border border-border/50" />
        <textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="Description" className="w-full bg-background rounded-xl px-3 py-2.5 text-xs font-medium border border-border/50 min-h-[60px]" />
        <div className="grid grid-cols-2 gap-2">
          <IOSSelect value={form.category} onChange={(v) => setForm({ ...form, category: v })} className="text-xs" options={[{ value: 'language', label: 'Language' }, { value: 'science', label: 'Science' }, { value: 'research', label: 'Research' }]} />
          <input value={form.flag} onChange={(e) => setForm({ ...form, flag: e.target.value })} placeholder="🇬🇧" className="bg-background rounded-xl px-3 py-2.5 text-xs font-medium border border-border/50" />
        </div>
        <div className="grid grid-cols-2 gap-2">
          <input value={form.color} onChange={(e) => setForm({ ...form, color: e.target.value })} placeholder="#1E4DFF" className="bg-background rounded-xl px-3 py-2.5 text-xs font-medium border border-border/50" />
          <input value={form.image} onChange={(e) => setForm({ ...form, image: e.target.value })} placeholder="Cover image URL (optional)" className="bg-background rounded-xl px-3 py-2.5 text-xs font-medium border border-border/50" />
        </div>
        <IOSSelect value={form.teacher_id} onChange={(v) => setForm({ ...form, teacher_id: v })} placeholder="No teacher assigned" className="w-full text-xs" options={approved.map((a) => ({ value: a.created_by_id, label: a.full_name }))} />
        <button onClick={create} disabled={creating || !form.title.trim()} className="w-full bg-primary text-primary-foreground rounded-xl py-2.5 text-xs font-bold disabled:opacity-40 no-tap-highlight">{creating ? 'Creating...' : 'Create Program'}</button>
      </div>

      <div className="space-y-3">
        {programs.map((p) => {
          const comms = communitiesOf(p);
          return (
          <div key={p.id} className="bg-card rounded-2xl p-3.5 shadow-soft">
            {editingId === p.id ? (
              <div className="space-y-2">
                <input value={edit.title} onChange={(e) => setEdit({ ...edit, title: e.target.value })} className="w-full bg-background rounded-xl px-3 py-2 text-sm font-bold border border-border/50" />
                <textarea value={edit.description} onChange={(e) => setEdit({ ...edit, description: e.target.value })} placeholder="Description" className="w-full bg-background rounded-xl px-3 py-2 text-xs font-medium border border-border/50 min-h-[50px]" />
                <div className="grid grid-cols-2 gap-2">
                  <IOSSelect value={edit.category} onChange={(v) => setEdit({ ...edit, category: v })} className="text-xs" options={[{ value: 'language', label: 'Language' }, { value: 'science', label: 'Science' }, { value: 'research', label: 'Research' }]} />
                  <input value={edit.flag_emoji} onChange={(e) => setEdit({ ...edit, flag_emoji: e.target.value })} placeholder="🇬🇧" className="bg-background rounded-xl px-2 py-2 text-xs font-medium border border-border/50" />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <input value={edit.accent_color} onChange={(e) => setEdit({ ...edit, accent_color: e.target.value })} placeholder="#1E4DFF" className="bg-background rounded-xl px-2 py-2 text-xs font-medium border border-border/50" />
                  <input value={edit.image_url} onChange={(e) => setEdit({ ...edit, image_url: e.target.value })} placeholder="Cover image URL" className="bg-background rounded-xl px-2 py-2 text-xs font-medium border border-border/50" />
                </div>
                <IOSSelect value={edit.teacher_id} onChange={(v) => setEdit({ ...edit, teacher_id: v })} placeholder="No teacher assigned" className="w-full text-xs" options={approved.map((a) => ({ value: a.created_by_id, label: a.full_name }))} />

                <div className="pt-2 border-t border-border/50 space-y-2">
                  <p className="text-[11px] font-bold text-foreground/60 uppercase">Payment</p>
                  <label className="flex items-center gap-2 text-xs font-medium">
                    <input type="checkbox" checked={edit.is_free} onChange={(e) => setEdit({ ...edit, is_free: e.target.checked })} /> Free program
                  </label>
                  {!edit.is_free && (
                    <>
                      <div className="grid grid-cols-2 gap-2">
                        <input type="number" value={edit.price} onChange={(e) => setEdit({ ...edit, price: Number(e.target.value) })} placeholder="Price" className="bg-background rounded-xl px-2 py-2 text-xs font-medium border border-border/50" />
                        <IOSSelect value={edit.currency} onChange={(v) => setEdit({ ...edit, currency: v })} className="text-xs" options={CURRENCIES.map((c) => ({ value: c, label: c }))} />
                      </div>
                      <IOSSelect value={edit.subscription_type} onChange={(v) => setEdit({ ...edit, subscription_type: v })} className="text-xs" options={SUBSCRIPTION_TYPES} />
                      <div className="grid grid-cols-2 gap-2">
                        <input value={edit.stripe_product_id} onChange={(e) => setEdit({ ...edit, stripe_product_id: e.target.value })} placeholder="Stripe Product ID" className="bg-background rounded-xl px-2 py-2 text-xs font-medium border border-border/50" />
                        <input value={edit.stripe_price_id} onChange={(e) => setEdit({ ...edit, stripe_price_id: e.target.value })} placeholder="Stripe Price ID" className="bg-background rounded-xl px-2 py-2 text-xs font-medium border border-border/50" />
                      </div>
                    </>
                  )}
                  <label className="flex items-center gap-2 text-xs font-medium">
                    <input type="checkbox" checked={edit.free_trial} onChange={(e) => setEdit({ ...edit, free_trial: e.target.checked })} /> Free trial
                  </label>
                  {edit.free_trial && <input type="number" value={edit.trial_days} onChange={(e) => setEdit({ ...edit, trial_days: Number(e.target.value) })} placeholder="Trial days" className="bg-background rounded-xl px-2 py-2 text-xs font-medium border border-border/50" />}
                </div>

                {edit.category === 'research' && (
                  <div className="pt-2 border-t border-border/50 space-y-2">
                    <p className="text-[11px] font-bold text-foreground/60 uppercase">Research content</p>
                    <input value={edit.research_hero_image} onChange={(e) => setEdit({ ...edit, research_hero_image: e.target.value })} placeholder="Hero image URL" className="w-full bg-background rounded-xl px-2 py-2 text-xs font-medium border border-border/50" />
                    <textarea value={edit.research_benefits} onChange={(e) => setEdit({ ...edit, research_benefits: e.target.value })} placeholder="Benefits (one per line)" className="w-full bg-background rounded-xl px-2 py-2 text-xs font-medium border border-border/50 min-h-[50px]" />
                    <textarea value={edit.research_requirements} onChange={(e) => setEdit({ ...edit, research_requirements: e.target.value })} placeholder="Requirements (one per line)" className="w-full bg-background rounded-xl px-2 py-2 text-xs font-medium border border-border/50 min-h-[50px]" />
                    <textarea value={edit.research_timeline} onChange={(e) => setEdit({ ...edit, research_timeline: e.target.value })} placeholder="Timeline (one per line)" className="w-full bg-background rounded-xl px-2 py-2 text-xs font-medium border border-border/50 min-h-[50px]" />
                    <textarea value={edit.research_mentors} onChange={(e) => setEdit({ ...edit, research_mentors: e.target.value })} placeholder="Mentors (one per line)" className="w-full bg-background rounded-xl px-2 py-2 text-xs font-medium border border-border/50 min-h-[50px]" />
                    <textarea value={edit.research_outcomes} onChange={(e) => setEdit({ ...edit, research_outcomes: e.target.value })} placeholder="Outcomes (one per line)" className="w-full bg-background rounded-xl px-2 py-2 text-xs font-medium border border-border/50 min-h-[50px]" />
                  </div>
                )}

                <div className="flex gap-2">
                  <button onClick={() => saveEdit(p)} className="flex-1 bg-primary text-primary-foreground rounded-xl py-2 text-xs font-bold no-tap-highlight">Save</button>
                  <button onClick={() => setEditingId(null)} className="flex-1 bg-muted text-muted-foreground rounded-xl py-2 text-xs font-bold no-tap-highlight">Cancel</button>
                </div>
              </div>
            ) : (
              <>
                <div className="flex items-center gap-2.5">
                  <span className="text-2xl">{p.flag_emoji || '📚'}</span>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-sm truncate">{p.title}</p>
                    <p className="text-xs text-muted-foreground">{p.category} · {p.teacher_name ? `Teacher: ${p.teacher_name}` : 'No teacher yet'}</p>
                  </div>
                </div>
                {p.description && <p className="text-xs text-muted-foreground mt-1.5 line-clamp-2">{p.description}</p>}
                <div className="flex items-center justify-between mt-2">
                  <span className="text-[10px] text-muted-foreground">{comms.length} community(ies){p.image_url ? ' · Has cover' : ''}</span>
                  <div className="flex gap-1.5">
                    <button onClick={() => startEdit(p)} className="text-[10px] font-bold bg-primary/10 text-primary rounded-lg px-2.5 py-1 no-tap-highlight">Edit</button>
                    <button onClick={() => remove(p)} className="text-[10px] font-bold bg-destructive/10 text-destructive rounded-lg px-2.5 py-1 no-tap-highlight flex items-center gap-1"><Trash2 size={11} /> Delete</button>
                  </div>
                </div>

                <div className="mt-3 pt-3 border-t border-border/50 space-y-2">
                  <p className="text-[11px] font-bold text-foreground/60 uppercase">Communities</p>
                  {comms.map((g) => (
                    <div key={g.id} className="bg-background/60 rounded-xl p-2.5">
                      {editGroupId === g.id ? (
                        <div className="space-y-2">
                          <input value={gEdit.name} onChange={(e) => setGEdit({ ...gEdit, name: e.target.value })} className="w-full bg-background rounded-lg px-2 py-1.5 text-xs font-bold border border-border/50" />
                          <div className="grid grid-cols-3 gap-1.5">
                            <input value={gEdit.flag_emoji} onChange={(e) => setGEdit({ ...gEdit, flag_emoji: e.target.value })} placeholder="🇬🇧" className="bg-background rounded-lg px-2 py-1.5 text-xs border border-border/50" />
                            <input value={gEdit.level} onChange={(e) => setGEdit({ ...gEdit, level: e.target.value })} placeholder="B2" className="bg-background rounded-lg px-2 py-1.5 text-xs border border-border/50" />
                            <input value={gEdit.time} onChange={(e) => setGEdit({ ...gEdit, time: e.target.value })} placeholder="18:00" className="bg-background rounded-lg px-2 py-1.5 text-xs border border-border/50" />
                          </div>
                          <IOSSelect value={gEdit.day_of_week} onChange={(v) => setGEdit({ ...gEdit, day_of_week: v })} className="w-full text-xs" options={DAYS.map((d) => ({ value: d, label: d }))} />
                          <textarea value={gEdit.description} onChange={(e) => setGEdit({ ...gEdit, description: e.target.value })} placeholder="Description" className="w-full bg-background rounded-lg px-2 py-1.5 text-xs border border-border/50 min-h-[40px]" />
                          <textarea value={gEdit.research_opportunities} onChange={(e) => setGEdit({ ...gEdit, research_opportunities: e.target.value })} placeholder="Research opportunities (optional)" className="w-full bg-background rounded-lg px-2 py-1.5 text-xs border border-border/50 min-h-[34px]" />
                          <div className="flex gap-1.5">
                            <button onClick={() => saveGroupEdit(g)} className="flex-1 bg-primary text-primary-foreground rounded-lg py-1.5 text-[11px] font-bold no-tap-highlight">Save</button>
                            <button onClick={() => setEditGroupId(null)} className="flex-1 bg-muted text-muted-foreground rounded-lg py-1.5 text-[11px] font-bold no-tap-highlight">Cancel</button>
                          </div>
                        </div>
                      ) : (
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-lg">{g.flag_emoji || '🌐'}</span>
                            <div className="flex-1 min-w-0">
                              <p className="font-semibold text-xs truncate">{g.name}</p>
                              <p className="text-[10px] text-muted-foreground">{g.level} · {g.day_of_week} {g.time} · {g.member_count || 0} members</p>
                            </div>
                            {g.is_archived && <span className="text-[8px] font-bold bg-muted text-muted-foreground rounded-full px-1.5 py-0.5">Archived</span>}
                          </div>
                          <div className="flex gap-1.5 mt-1.5">
                            <button onClick={() => startGroupEdit(g)} className="text-[10px] font-bold bg-primary/10 text-primary rounded-lg px-2 py-1 no-tap-highlight">Edit</button>
                            <button onClick={() => toggleArchive(g)} className="text-[10px] font-bold bg-muted text-muted-foreground rounded-lg px-2 py-1 no-tap-highlight">{g.is_archived ? 'Restore' : 'Archive'}</button>
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                  {!comms.length && <p className="text-[11px] text-muted-foreground">No communities yet.</p>}

                  {addProgramId === p.id ? (
                    <div className="bg-background/60 rounded-xl p-2.5 space-y-2">
                      <input value={newGroup.name} onChange={(e) => setNewGroup({ ...newGroup, name: e.target.value })} placeholder="Community name" className="w-full bg-background rounded-lg px-2 py-1.5 text-xs font-bold border border-border/50" />
                      <div className="grid grid-cols-3 gap-1.5">
                        <input value={newGroup.flag} onChange={(e) => setNewGroup({ ...newGroup, flag: e.target.value })} placeholder="🇬🇧" className="bg-background rounded-lg px-2 py-1.5 text-xs border border-border/50" />
                        <input value={newGroup.level} onChange={(e) => setNewGroup({ ...newGroup, level: e.target.value })} placeholder="B2" className="bg-background rounded-lg px-2 py-1.5 text-xs border border-border/50" />
                        <input value={newGroup.time} onChange={(e) => setNewGroup({ ...newGroup, time: e.target.value })} placeholder="18:00" className="bg-background rounded-lg px-2 py-1.5 text-xs border border-border/50" />
                      </div>
                      <div className="grid grid-cols-2 gap-1.5">
                        <IOSSelect value={newGroup.day} onChange={(v) => setNewGroup({ ...newGroup, day: v })} className="text-xs" options={DAYS.map((d) => ({ value: d, label: d }))} />
                        <input value={newGroup.research} onChange={(e) => setNewGroup({ ...newGroup, research: e.target.value })} placeholder="Research (optional)" className="bg-background rounded-lg px-2 py-1.5 text-xs border border-border/50" />
                      </div>
                      <textarea value={newGroup.description} onChange={(e) => setNewGroup({ ...newGroup, description: e.target.value })} placeholder="Description" className="w-full bg-background rounded-lg px-2 py-1.5 text-xs border border-border/50 min-h-[40px]" />
                      <div className="flex gap-1.5">
                        <button onClick={() => createGroup(p)} disabled={savingGroup || !newGroup.name.trim()} className="flex-1 bg-primary text-primary-foreground rounded-lg py-1.5 text-[11px] font-bold disabled:opacity-40 no-tap-highlight">{savingGroup ? '...' : 'Add'}</button>
                        <button onClick={() => setAddProgramId(null)} className="flex-1 bg-muted text-muted-foreground rounded-lg py-1.5 text-[11px] font-bold no-tap-highlight">Cancel</button>
                      </div>
                    </div>
                  ) : (
                    <button onClick={() => startAdd(p)} className="w-full text-[11px] font-bold bg-primary/10 text-primary rounded-lg py-1.5 no-tap-highlight flex items-center justify-center gap-1"><Plus size={12} /> Add community</button>
                  )}
                </div>
              </>
            )}
          </div>
          );
        })}
        {!programs.length && <Empty label="No programs yet — create one above" />}
      </div>
    </div>
  );
}

function StatusBadge({ status }) {
  const map = { pending: ['Pending', 'bg-accent/20 text-accent-foreground', '#FFD84D'], approved: ['Approved', 'bg-green-500/15 text-green-600', '#22c55e'], rejected: ['Rejected', 'bg-destructive/15 text-destructive', '#ef4444'] };
  const [label, cls] = map[status] || map.pending;
  return <span className={`text-[10px] font-bold rounded-full px-2.5 py-1 ${cls}`}>{label}</span>;
}

function Empty({ label }) {
  return <div className="text-center py-12"><p className="text-sm text-muted-foreground">{label}</p></div>;
}
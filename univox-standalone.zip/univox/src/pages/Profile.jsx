import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Bell, Globe, Lock, UserCircle, HelpCircle, ChevronRight, ChevronDown, Award, Crown, LogOut, Sparkles, GraduationCap, Lock as LockIcon, Sun, FlaskConical } from 'lucide-react';
import SettingPanelContent from '@/components/profile/SettingsSection';
import { isOwner, isApprovedTeacher, isPendingTeacher, isStudent, getActiveMode, setActiveMode } from '@/lib/roles';
import { base44 } from '@/api/base44Client';
import ProfileAvatar from '@/components/profile/ProfileAvatar';
import { useUserProgress } from '@/lib/UserProgressContext';
import { CERTIFICATES } from '@/lib/achievements';
import CertificateModal from '@/components/CertificateModal';
import AchievementInfoModal from '@/components/AchievementInfoModal';

const settings = [
  { label: 'Notifications', icon: Bell, color: '#1E4DFF' },
  { label: 'Language', icon: Globe, color: '#FF6FAE' },
  { label: 'Appearance', icon: Sun, color: '#FF8A3D' },
  { label: 'Privacy', icon: Lock, color: '#FFD84D' },
  { label: 'Account', icon: UserCircle, color: '#FF8A3D' },
  { label: 'Help', icon: HelpCircle, color: '#1E4DFF' },
];

export default function Profile() {
  const navigate = useNavigate();
  const progress = useUserProgress();
  const [user, setUser] = useState(null);
  const [openSetting, setOpenSetting] = useState(null);
  const [activeMode, setActiveModeState] = useState(getActiveMode());
  const [certModal, setCertModal] = useState(null);
  const [lockedCert, setLockedCert] = useState(null);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const handleLogout = async () => {
    await base44.auth.logout();
    window.location.href = '/';
  };

  return (
    <div className="min-h-screen pb-28">
      <div className="relative h-[calc(8rem+var(--safe-top))] pt-[var(--safe-top)] bg-gradient-to-br from-primary via-primary to-secondary overflow-hidden">
        <div className="absolute -right-8 -top-4 w-32 h-32 rounded-full bg-white/10" />
        <div className="absolute right-12 bottom-2 w-20 h-20 rounded-full bg-white/5" />
      </div>

      <div className="px-5 -mt-14 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="flex flex-col items-center text-center"
        >
          <ProfileAvatar user={user} onUpdated={setUser} />
          <h1 className="text-2xl font-extrabold mt-3">{user?.full_name || 'Sofia'}</h1>
          <div className="flex items-center gap-2 mt-1">
            {user?.country && <span className="text-sm text-muted-foreground">{user.country}</span>}
            {!user?.country && <span className="text-sm text-muted-foreground">🇪🇸 Spain</span>}
            <span className="text-muted-foreground/40">•</span>
            <span className="text-sm text-muted-foreground">{user?.age ? `${user.age} years old` : '16 years old'}</span>
          </div>
          <div className="flex items-center gap-1.5 mt-2 justify-center">
            {(user?.roles || ['student']).filter(r => r !== 'owner').map(r => (
              <span key={r} className="text-[10px] font-bold bg-primary/10 text-primary rounded-full px-2.5 py-0.5 capitalize">{r}</span>
            ))}
          </div>
        </motion.div>
      </div>

      {isPendingTeacher(user) && (
        <div className="px-5 mt-4">
          <div className="rounded-2xl p-3.5 text-xs font-medium flex items-center gap-2" style={{ background: 'hsl(48 100% 65% / 0.18)', color: '#a07a00' }}>
            <Sparkles size={14} /> Your teacher application is under review.
          </div>
        </div>
      )}

      {(isApprovedTeacher(user) || isOwner(user)) && (
        <div className="px-5 mt-5 grid gap-3" style={{ gridTemplateColumns: isApprovedTeacher(user) && isOwner(user) ? '1fr 1fr' : '1fr' }}>
          {isApprovedTeacher(user) && (
            <Link to="/teacher-panel" className="block no-tap-highlight">
              <div className="bg-card rounded-3xl p-4 shadow-soft flex items-center gap-3">
                <div className="w-11 h-11 rounded-2xl bg-primary/15 flex items-center justify-center"><GraduationCap size={20} className="text-primary" /></div>
                <div className="flex-1">
                  <p className="font-bold text-sm">Teacher Panel</p>
                  <p className="text-xs text-muted-foreground">Manage your groups</p>
                </div>
                <ChevronRight size={18} className="text-muted-foreground/50" />
              </div>
            </Link>
          )}
          {isOwner(user) && (
            <Link to="/owner" className="block no-tap-highlight">
              <div className="bg-card rounded-3xl p-4 shadow-soft flex items-center gap-3">
                <div className="w-11 h-11 rounded-2xl flex items-center justify-center" style={{ background: 'hsl(48 100% 65% / 0.2)' }}><Crown size={20} style={{ color: '#FFD84D' }} /></div>
                <div className="flex-1">
                  <p className="font-bold text-sm">Owner Panel</p>
                  <p className="text-xs text-muted-foreground">Manage UNIVOX</p>
                </div>
                <ChevronRight size={18} className="text-muted-foreground/50" />
              </div>
            </Link>
          )}
        </div>
      )}

      {isStudent(user) && isApprovedTeacher(user) && (
        <div className="px-5 mt-5">
          <div className="bg-card rounded-2xl p-1.5 flex shadow-soft">
            {['student','teacher'].map((m) => (
              <button key={m} onClick={() => { setActiveMode(m); setActiveModeState(m); }} className={`flex-1 py-2 rounded-xl text-xs font-bold capitalize no-tap-highlight ${activeMode === m ? 'bg-primary text-primary-foreground' : 'text-muted-foreground'}`}>{m} mode</button>
            ))}
          </div>
        </div>
      )}

      <div className="px-5 mt-6">
        <h2 className="text-sm font-bold text-foreground/80 uppercase tracking-wide mb-3">My Programs</h2>
        {progress.activePrograms && progress.activePrograms.length > 0 ? (
          <div className="flex gap-2 flex-wrap">
            {progress.activePrograms.map((p, i) => (
              <motion.span
                key={p}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: i * 0.06 }}
                className="bg-card rounded-full px-4 py-2 text-sm font-semibold shadow-soft"
              >
                {p}
              </motion.span>
            ))}
          </div>
        ) : (
          <div className="bg-card rounded-2xl p-5 text-center">
            <p className="text-sm text-muted-foreground">No programs yet. Join one to see it here!</p>
          </div>
        )}
      </div>

      <div className="px-5 mt-6">
        <h2 className="text-sm font-bold text-foreground/80 uppercase tracking-wide mb-3">Certificates</h2>
        <div className="space-y-2.5">
          {CERTIFICATES.map((c, i) => {
            const unlocked = c.isUnlocked(progress);
            return (
              <motion.button
                key={c.id}
                initial={{ opacity: 0, x: -16 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.08 }}
                onClick={() => (unlocked ? setCertModal(c) : setLockedCert(c))}
                className={`w-full text-left rounded-2xl p-4 flex items-center gap-3 relative no-tap-highlight ${unlocked ? 'shadow-soft bg-gradient-to-r from-accent/20 to-orange/20' : 'bg-muted/50'}`}
              >
                <div className={`w-11 h-11 rounded-xl flex items-center justify-center text-white flex-shrink-0 ${unlocked ? 'bg-gradient-to-br from-accent to-orange' : 'bg-muted grayscale'}`}>
                  {unlocked ? <Award size={20} /> : <LockIcon size={18} />}
                </div>
                <div className="flex-1">
                  <p className={`font-semibold text-sm ${unlocked ? '' : 'text-muted-foreground/60'}`}>{c.title}</p>
                  {c.program && <p className="text-xs text-muted-foreground">{c.program} Program</p>}
                  <p className={`text-[10px] mt-0.5 ${unlocked ? 'text-accent-foreground/60 font-semibold' : 'text-muted-foreground/50'}`}>{unlocked ? 'Earned · tap to view' : 'Locked'}</p>
                </div>
                {unlocked ? (
                  <ChevronRight size={18} className="text-accent-foreground/60 flex-shrink-0" />
                ) : (
                  <span className="text-[9px] font-bold px-2 py-0.5 rounded-full bg-muted text-muted-foreground/60 flex-shrink-0">LOCKED</span>
                )}
              </motion.button>
            );
          })}
        </div>
      </div>

      <div className="px-5 mt-6">
        <Link to="/research" className="block no-tap-highlight">
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-gradient-to-br from-primary to-secondary rounded-3xl p-5 text-primary-foreground shadow-card relative overflow-hidden"
          >
            <div className="absolute -right-4 -top-4 w-24 h-24 rounded-full bg-white/10" />
            <div className="relative flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-white/20 flex items-center justify-center flex-shrink-0">
                <FlaskConical size={22} />
              </div>
              <div className="flex-1">
                <p className="font-bold text-base">Start Your Research</p>
                <p className="text-xs text-white/80 mt-0.5">Join the UNIVOX Research Program</p>
              </div>
              <ChevronRight size={20} className="text-white/60" />
            </div>
          </motion.div>
        </Link>
      </div>

      <div className="px-5 mt-6">
        <h2 className="text-sm font-bold text-foreground/80 uppercase tracking-wide mb-3">Settings</h2>
        <div className="bg-card rounded-3xl shadow-soft overflow-hidden">
          {settings.map((s, i) => (
            <div key={s.label} className={i !== settings.length - 1 || openSetting === s.label ? 'border-b border-border/40' : ''}>
              <button
                onClick={() => setOpenSetting(openSetting === s.label ? null : s.label)}
                className="w-full flex items-center gap-3 p-4 hover:bg-muted/50 transition-colors no-tap-highlight"
              >
                <div className="w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0" style={{ background: `${s.color}15` }}>
                  <s.icon size={17} style={{ color: s.color }} />
                </div>
                <span className="flex-1 text-left text-sm font-medium">{s.label}</span>
                {openSetting === s.label
                  ? <ChevronDown size={18} className="text-muted-foreground/50" />
                  : <ChevronRight size={18} className="text-muted-foreground/50" />}
              </button>
              <AnimatePresence>
                {openSetting === s.label && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="overflow-hidden"
                  >
                    <div className="px-4 pb-4 pl-16">
                      <SettingPanelContent type={s.label} userEmail={user?.email} />
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ))}
        </div>
      </div>

      <div className="px-5 mt-6">
        <button
          onClick={handleLogout}
          className="w-full flex items-center justify-center gap-2 text-destructive font-semibold text-sm py-3.5 rounded-2xl border border-destructive/20 hover:bg-destructive/5 transition-colors no-tap-highlight"
        >
          <LogOut size={16} /> Log Out
        </button>
      </div>

      <CertificateModal certificate={certModal} userName={user?.full_name} onClose={() => setCertModal(null)} />
      <AchievementInfoModal item={lockedCert} onClose={() => setLockedCert(null)} />
    </div>
  );
}
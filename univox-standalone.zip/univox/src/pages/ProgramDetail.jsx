import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ChevronLeft, Clock, User, Users, GraduationCap, MessageCircle, Loader2, UserCheck, FlaskConical } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useUserProgress } from '@/lib/UserProgressContext';
import { programColor } from '@/lib/achievements';
import { useTimezone, convertLesson } from '@/lib/timezone';
import TrialAccessCard from '@/components/program/TrialAccessCard';
import { isProgramFree, priceLabel, ctaLabel } from '@/lib/payments';

export default function ProgramDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { joinGroup, joinedGroups } = useUserProgress();
  const { tz } = useTimezone();
  const [program, setProgram] = useState(null);
  const [groups, setGroups] = useState([]);
  const [loading, setLoading] = useState(true);
  const [joining, setJoining] = useState(null);

  useEffect(() => {
    let active = true;
    setLoading(true);
    setProgram(null);
    base44.entities.Program.get(id)
      .then((p) => {
        if (!active) return;
        setProgram(p);
        const title = p?.title;
        if (title) {
          base44.entities.Group.filter({ program_title: title })
            .then((g) => setGroups((g || []).filter((x) => !x.is_archived)))
            .catch(() => setGroups([]))
            .finally(() => { if (active) setLoading(false); });
        } else {
          if (active) setLoading(false);
        }
      })
      .catch(() => { if (active) { setProgram(null); setLoading(false); } });
    return () => { active = false; };
  }, [id]);

  const accent = program?.accent_color || programColor(program?.title) || '#1E4DFF';
  const flag = program?.flag_emoji || '📚';

  const handleJoin = async (group) => {
    if (joining) return;
    const already = (joinedGroups || []).find((g) => g.id === group.id);
    if (already && already.chatId) { navigate(`/chat/${already.chatId}`); return; }
    setJoining(group.id);
    try { const chatId = await joinGroup(group); navigate(`/chat/${chatId || ''}`); } catch (e) {}
    setJoining(null);
  };

  if (!loading && !program) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center px-5 text-center">
        <div className="w-16 h-16 rounded-full bg-card flex items-center justify-center mb-4">
          <GraduationCap size={28} className="text-muted-foreground/50" />
        </div>
        <p className="font-bold text-lg">Program not found</p>
        <p className="text-sm text-muted-foreground mt-1">This program may have been moved or deleted.</p>
        <button onClick={() => navigate('/programs')} className="mt-5 bg-primary text-primary-foreground rounded-2xl px-5 py-2.5 text-sm font-bold no-tap-highlight">
          Back to Programs
        </button>
      </div>
    );
  }
  if (!program) return null;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.35 }}
      className="min-h-screen pb-28"
    >
      <div className="relative h-64 overflow-hidden" style={{ background: accent }}>
        {program.image_url && <img src={program.image_url} alt="" className="absolute inset-0 w-full h-full object-cover" />}
        <div className="absolute inset-0" style={{ background: 'linear-gradient(160deg, rgba(255,255,255,0.18), rgba(0,0,0,0.45))' }} />
        <button
          onClick={() => navigate(-1)}
          className="absolute top-12 left-5 w-10 h-10 rounded-full glass flex items-center justify-center no-tap-highlight"
        >
          <ChevronLeft size={22} />
        </button>
        <motion.div
          initial={{ opacity: 0, y: 18 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15, duration: 0.45 }}
          className="absolute bottom-0 left-0 right-0 p-6"
        >
          <div className="text-3xl mb-2">{flag}</div>
          <h1 className="text-4xl font-extrabold tracking-tight text-white drop-shadow-lg">{program.title}</h1>
          {program.description && <p className="text-white/80 text-sm mt-2 max-w-xs leading-relaxed">{program.description}</p>}
        </motion.div>
      </div>

      <div className="px-5 mt-5">
        <div className="bg-card rounded-3xl p-4 shadow-soft flex items-center gap-3">
          <div className="w-11 h-11 rounded-2xl flex items-center justify-center flex-shrink-0" style={{ background: `${accent}18` }}>
            {program.teacher_name ? <UserCheck size={20} style={{ color: accent }} /> : <User size={20} className="text-muted-foreground" />}
          </div>
          <div className="min-w-0">
            <p className="text-xs text-muted-foreground">Teacher</p>
            <p className="font-bold text-sm truncate">{program.teacher_name || 'Teacher will be announced soon.'}</p>
          </div>
        </div>
      </div>

      <div className="px-5 mt-4">
        <TrialAccessCard />
      </div>

      <div className="px-5 mt-4">
        <div className="bg-card rounded-3xl p-4 shadow-soft flex items-center gap-3">
          <div className="w-11 h-11 rounded-2xl flex items-center justify-center flex-shrink-0" style={{ background: `${accent}18` }}>
            <FlaskConical size={20} style={{ color: accent }} />
          </div>
          <div className="min-w-0">
            <p className="text-xs text-muted-foreground">{isProgramFree(program) ? 'Access' : 'Pricing'}</p>
            <p className="font-bold text-sm truncate">{priceLabel(program)}{program.free_trial ? ` · ${program.trial_days || 14}-day trial` : ''}</p>
          </div>
        </div>
      </div>

      <div className="px-5 mt-7">
        <div className="flex items-center gap-2 mb-4">
          <h2 className="text-sm font-bold text-foreground/80 uppercase tracking-wide">Available Groups</h2>
          <div className="flex-1 h-px bg-border/40" />
          <span className="text-xs text-muted-foreground">{groups.length}</span>
        </div>

        {loading ? (
          <div className="space-y-3">
            {[1, 2, 3].map((i) => <div key={i} className="h-24 skeleton rounded-3xl" />)}
          </div>
        ) : groups.length === 0 ? (
          <div className="bg-card rounded-3xl p-8 text-center">
            <p className="text-sm text-muted-foreground">No groups available yet. Check back soon!</p>
          </div>
        ) : (
          <div className="space-y-3">
            {groups.map((group, i) => {
              const isMember = (joinedGroups || []).find((g) => g.id === group.id);
              const conv = convertLesson(group.day_of_week || 'Monday', group.time || '18:00', tz);
              const seats = Math.max(0, (group.capacity || 20) - (group.member_count || 0));
              return (
                <motion.div
                  key={group.id}
                  initial={{ opacity: 0, y: 16 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.07, duration: 0.35 }}
                  className="w-full bg-card rounded-3xl p-4 shadow-soft no-tap-highlight"
                >
                  <div className="flex items-center gap-3.5">
                    <div className="w-14 h-14 rounded-2xl flex flex-col items-center justify-center flex-shrink-0" style={{ background: `${accent}18` }}>
                      <GraduationCap size={18} style={{ color: accent }} />
                      <span className="text-[11px] font-extrabold mt-0.5" style={{ color: accent }}>{group.level || 'B1'}</span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-bold text-sm truncate">{group.name}</p>
                      <div className="flex items-center gap-2 mt-1 text-xs text-muted-foreground">
                        <span>{conv.day}</span>
                        <span className="text-muted-foreground/40">•</span>
                        <span className="flex items-center gap-1"><Clock size={11} /> {conv.time}</span>
                      </div>
                      <div className="flex items-center gap-3 mt-1.5 flex-wrap">
                        <span className="text-[11px] text-muted-foreground/80 flex items-center gap-1"><User size={10} /> {group.teacher || 'Teacher TBA'}</span>
                        <span className="text-[11px] text-muted-foreground/80 flex items-center gap-1"><Users size={10} /> {group.member_count || 0}</span>
                        <span className={`text-[11px] flex items-center gap-1 ${seats > 0 ? 'text-green-600' : 'text-destructive'}`}>🪑 {seats > 0 ? `${seats} seats left` : 'Full'}</span>
                      </div>
                    </div>
                  </div>
                  <button
                    onClick={() => handleJoin(group)}
                    disabled={joining === group.id}
                    className="mt-3 w-full flex items-center justify-center gap-2 rounded-2xl py-3 text-sm font-bold no-tap-highlight disabled:opacity-50"
                    style={{ background: accent, color: '#fff' }}
                  >
                    {joining === group.id ? (
                      <><Loader2 size={16} className="animate-spin" /> Joining…</>
                    ) : isMember ? (
                      <><MessageCircle size={16} /> Open Chat</>
                    ) : (
                      <><MessageCircle size={16} /> {ctaLabel(program)}</>
                    )}
                  </button>
                </motion.div>
              );
            })}
          </div>
        )}
      </div>
    </motion.div>
  );
}
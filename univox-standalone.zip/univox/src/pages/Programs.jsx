import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { GraduationCap } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { programColor } from '@/lib/achievements';

const heroImage = 'https://media.base44.com/images/public/6a51768d9b73d617045c18ee/9ce250134_IMG_1509.jpg';

const pixelColors = ['#1E4DFF', '#FF6FAE', '#FFD84D', '#FF8A3D', '#1E4DFF', '#FF6FAE', '#FFD84D', '#FF8A3D', '#1E4DFF', '#FF6FAE', '#FFD84D', '#FF8A3D'];

export default function Programs() {
  const [programs, setPrograms] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    base44.entities.Program.list()
      .then((p) => setPrograms(p || []))
      .catch(() => setPrograms([]))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="min-h-screen pb-28">
      <header className="px-5 pt-[calc(0.75rem+var(--safe-top))] pb-3">
        <h1 className="text-3xl font-extrabold tracking-tight">Programs</h1>
        <p className="text-muted-foreground text-sm mt-1">Choose your subject and join a group</p>
      </header>

      <div className="px-5">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="relative rounded-3xl overflow-hidden shadow-card h-44"
        >
          <img src={heroImage} alt="" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-br from-primary/40 via-secondary/30 to-accent/30 mix-blend-multiply" />
          <div className="absolute inset-0 bg-black/15" />
          <div className="absolute top-0 left-0 right-0 flex h-2">
            {pixelColors.map((c, i) => <div key={i} className="flex-1" style={{ background: c }} />)}
          </div>
          <div className="absolute bottom-0 left-0 right-0 flex h-2">
            {pixelColors.slice().reverse().map((c, i) => <div key={i} className="flex-1" style={{ background: c }} />)}
          </div>
          <div className="absolute bottom-0 left-0 right-0 p-5">
            <p className="text-white/80 text-xs font-semibold uppercase tracking-[0.25em]">Global Learning</p>
            <p className="text-white text-lg font-bold mt-0.5 leading-tight drop-shadow-lg">Join a worldwide community of learners</p>
          </div>
        </motion.div>
      </div>

      <div className="px-5 mt-5">
        {loading ? (
          <div className="grid grid-cols-2 gap-3">
            {[1, 2, 3, 4].map((i) => <div key={i} className="aspect-square rounded-3xl skeleton" />)}
          </div>
        ) : programs.length === 0 ? (
          <div className="bg-card rounded-3xl p-10 text-center shadow-soft">
            <div className="w-20 h-20 rounded-full bg-gradient-to-br from-primary/10 to-secondary/10 flex items-center justify-center mx-auto mb-4">
              <GraduationCap size={34} className="text-primary/70" />
            </div>
            <p className="text-base font-bold text-foreground/80">No programs yet</p>
            <p className="text-sm text-muted-foreground mt-1.5 max-w-xs mx-auto">New programs will appear here as soon as they're created by the admin.</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3">
            {programs.map((p, i) => {
              const color = p.accent_color || programColor(p.title) || '#1E4DFF';
              const flag = p.flag_emoji || '📚';
              return (
                <motion.div
                  key={p.id}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: i * 0.07, duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
                >
                  <Link to={`/program/${p.id}`} className="block no-tap-highlight">
                    <div className="aspect-square rounded-3xl relative overflow-hidden shadow-card group" style={{ background: color }}>
                      {p.image_url && <img src={p.image_url} alt="" className="absolute inset-0 w-full h-full object-cover opacity-40 group-hover:opacity-50 transition-opacity" />}
                      <div className="absolute inset-0" style={{ background: 'linear-gradient(160deg, rgba(255,255,255,0.22), rgba(0,0,0,0.10))' }} />
                      <div className="absolute top-3 left-3 text-lg drop-shadow">{flag}</div>
                      <div className="absolute bottom-0 inset-x-0 h-20 bg-gradient-to-t from-black/40 to-transparent" />
                      <div className="absolute bottom-0 left-0 right-0 p-4">
                        <p className="text-white font-extrabold text-2xl leading-none drop-shadow-lg">{p.title}</p>
                        {p.description && <p className="text-white/65 text-[11px] mt-1.5 leading-snug line-clamp-2">{p.description}</p>}
                      </div>
                    </div>
                  </Link>
                </motion.div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
import { useState } from 'react';
import { motion } from 'framer-motion';
import { BookOpen, Award, Clock, Layers, TrendingUp, Calendar } from 'lucide-react';
import GrowthChart from '@/components/progress/GrowthChart';
import { useUserProgress } from '@/lib/UserProgressContext';
import { BADGES, CERTIFICATES } from '@/lib/achievements';
import AchievementInfoModal from '@/components/AchievementInfoModal';

export default function Progress() {
  const progress = useUserProgress();
  const [lockedItem, setLockedItem] = useState(null);

  const stats = [
    { label: 'Lessons Attended', value: progress.lessonsAttended || 0, icon: BookOpen, color: '#1E4DFF' },
    { label: 'Certificates', value: 0, icon: Award, color: '#FF6FAE' },
    { label: 'Learning Hours', value: progress.learningHours || 0, icon: Clock, color: '#FFD84D' },
    { label: 'Active Programs', value: (progress.activePrograms || []).length, icon: Layers, color: '#FF8A3D' },
  ];
  const unlockedCerts = CERTIFICATES.filter((c) => c.isUnlocked(progress)).length;
  stats[1].value = unlockedCerts;

  const chartData = (progress.learningHoursByMonth || []).map((m) => ({ month: m.month, hours: m.hours || 0 }));
  const totalHours = progress.learningHours || 0;
  const earnedBadges = BADGES.filter((b) => b.isUnlocked(progress)).length;

  return (
    <div className="min-h-screen pb-28">
      <header className="px-5 pt-12 pb-2">
        <h1 className="text-3xl font-extrabold tracking-tight">Progress</h1>
        <p className="text-muted-foreground text-sm mt-1">Track your learning journey</p>
      </header>

      <div className="px-5 mt-5">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="bg-gradient-to-br from-primary to-secondary rounded-3xl p-5 text-white shadow-card relative overflow-hidden"
        >
          <div className="absolute -right-6 -top-6 w-28 h-28 rounded-full bg-white/10" />
          <div className="absolute -left-4 -bottom-6 w-20 h-20 rounded-full bg-white/5" />
          <div className="relative flex items-center justify-between">
            <div>
              <p className="text-white/70 text-xs font-semibold uppercase tracking-wider">Learning Journey</p>
              <p className="text-4xl font-extrabold mt-0.5">{earnedBadges} <span className="text-lg font-bold opacity-80">/ {BADGES.length} badges</span></p>
            </div>
            <div className="w-14 h-14 rounded-2xl bg-white/20 flex items-center justify-center">
              <TrendingUp size={26} />
            </div>
          </div>
          <div className="relative mt-4">
            <div className="flex justify-between text-xs text-white/80 mb-1.5">
              <span className="font-semibold">{totalHours} hrs learned</span>
              <span>{progress.lessonsAttended || 0} lessons attended</span>
            </div>
            <div className="h-2.5 rounded-full bg-white/20 overflow-hidden">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${Math.min(100, ((earnedBadges / BADGES.length) * 100) || 0)}%` }}
                transition={{ duration: 0.8, delay: 0.2 }}
                className="h-full rounded-full bg-white"
              />
            </div>
          </div>
        </motion.div>
      </div>

      <div className="px-5 mt-5 grid grid-cols-2 gap-3">
        {stats.map((s, i) => (
          <motion.div
            key={s.label}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.08, duration: 0.3 }}
            className="bg-card rounded-3xl p-4 shadow-soft relative overflow-hidden"
          >
            <div className="absolute -right-3 -top-3 w-16 h-16 rounded-full opacity-10" style={{ background: s.color }} />
            <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: `${s.color}15` }}>
              <s.icon size={18} style={{ color: s.color }} />
            </div>
            <p className="text-3xl font-extrabold mt-3" style={{ color: s.color }}>{s.value}</p>
            <p className="text-xs text-muted-foreground font-medium mt-0.5">{s.label}</p>
          </motion.div>
        ))}
      </div>

      <div className="px-5 mt-6">
        <div className="flex items-center gap-2 mb-3">
          <h2 className="text-sm font-bold text-foreground/80 uppercase tracking-wide">Learning Hours</h2>
          <span className="text-[10px] font-bold bg-secondary/15 text-secondary rounded-full px-2 py-0.5 flex items-center gap-0.5">
            <TrendingUp size={11} /> {totalHours}h total
          </span>
        </div>
        <div className="bg-card rounded-3xl p-5 shadow-soft">
          {chartData.some((d) => d.hours > 0) ? (
            <GrowthChart data={chartData} />
          ) : (
            <div className="h-[200px] flex flex-col items-center justify-center text-center">
              <div className="w-14 h-14 rounded-full bg-muted flex items-center justify-center mb-3">
                <Clock size={24} className="text-muted-foreground/60" />
              </div>
              <p className="text-sm text-muted-foreground">No learning hours yet.</p>
              <p className="text-xs text-muted-foreground/70 mt-1">Join a lesson to start your chart.</p>
            </div>
          )}
        </div>
      </div>

      <div className="px-5 mt-6">
        <h2 className="text-sm font-bold text-foreground/80 uppercase tracking-wide mb-3">Timeline</h2>
        <div className="bg-card rounded-3xl p-8 shadow-soft text-center">
          <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mx-auto mb-3">
            <Calendar size={26} className="text-muted-foreground/50" />
          </div>
          <p className="text-sm text-muted-foreground">Your milestones will appear here.</p>
          <p className="text-xs text-muted-foreground/70 mt-1">Attend lessons and earn badges to fill your timeline.</p>
        </div>
      </div>

      <div className="px-5 mt-6">
        <h2 className="text-sm font-bold text-foreground/80 uppercase tracking-wide mb-3">Badges</h2>
        <div className="flex gap-3 overflow-x-auto scrollbar-hide pb-1">
          {BADGES.map((badge, i) => {
            const unlocked = badge.isUnlocked(progress);
            const Icon = badge.icon;
            return (
              <motion.button
                key={badge.id}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: i * 0.06, duration: 0.3 }}
                onClick={() => !unlocked && setLockedItem(badge)}
                className={`w-28 flex-shrink-0 rounded-3xl p-4 flex flex-col items-center text-center relative no-tap-highlight ${unlocked ? 'bg-card shadow-soft' : 'bg-muted/50'}`}
              >
                <div
                  className={`w-14 h-14 rounded-2xl flex items-center justify-center shadow-lg ${unlocked ? '' : 'grayscale opacity-40'}`}
                  style={{ background: `linear-gradient(135deg, ${badge.color}, ${badge.color}99)` }}
                >
                  {unlocked ? (
                    <Icon size={24} className="text-white" />
                  ) : (
                    <span className="text-2xl opacity-50">🔒</span>
                  )}
                </div>
                <p className={`font-bold text-xs mt-3 leading-tight ${unlocked ? '' : 'text-muted-foreground/50'}`}>{badge.title}</p>
                {unlocked ? (
                  <span className="text-[9px] font-bold mt-1 px-2 py-0.5 rounded-full" style={{ background: `${badge.color}15`, color: badge.color }}>EARNED</span>
                ) : (
                  <span className="text-[9px] font-bold mt-1 px-2 py-0.5 rounded-full bg-muted text-muted-foreground/60">LOCKED</span>
                )}
              </motion.button>
            );
          })}
        </div>
      </div>

      <AchievementInfoModal item={lockedItem} onClose={() => setLockedItem(null)} />
    </div>
  );
}
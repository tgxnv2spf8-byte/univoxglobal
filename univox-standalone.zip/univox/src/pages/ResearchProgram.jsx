import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronLeft, FlaskConical, Check, Clock, Users, Award, ArrowRight } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { isProgramFree, priceLabel, ctaLabel } from '@/lib/payments';

const split = (s) => (s || '').split('\n').map((x) => x.trim()).filter(Boolean);

export default function ResearchProgram() {
  const navigate = useNavigate();
  const [program, setProgram] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    base44.entities.Program.filter({ category: 'research' })
      .then((list) => setProgram((list || [])[0] || null))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return <div className="min-h-screen"><div className="h-40 skeleton" /></div>;
  }

  if (!program) {
    return (
      <div className="min-h-screen pb-28">
        <header className="px-5 pt-[calc(0.75rem+var(--safe-top))] pb-3 flex items-center gap-3">
          <button onClick={() => navigate(-1)} className="w-10 h-10 rounded-full bg-card flex items-center justify-center no-tap-highlight"><ChevronLeft size={22} /></button>
          <div><h1 className="text-2xl font-extrabold tracking-tight">Research Program</h1></div>
        </header>
        <div className="px-5 mt-10 text-center">
          <div className="w-16 h-16 rounded-3xl bg-card flex items-center justify-center mx-auto mb-4"><FlaskConical size={28} className="text-muted-foreground/50" /></div>
          <p className="font-bold">Research program coming soon</p>
          <p className="text-sm text-muted-foreground mt-1">The Creator will publish the Research Program here soon.</p>
        </div>
      </div>
    );
  }

  const accent = program.accent_color || '#1E4DFF';
  const benefits = split(program.research_benefits);
  const requirements = split(program.research_requirements);
  const timeline = split(program.research_timeline);
  const mentors = split(program.research_mentors);
  const outcomes = split(program.research_outcomes);
  const hero = program.research_hero_image || program.image_url;

  return (
    <div className="min-h-screen pb-28">
      <div className="relative h-64 overflow-hidden" style={{ background: accent }}>
        {hero && <img src={hero} alt="" className="absolute inset-0 w-full h-full object-cover" />}
        <div className="absolute inset-0" style={{ background: 'linear-gradient(160deg, rgba(255,255,255,0.18), rgba(0,0,0,0.5))' }} />
        <button onClick={() => navigate(-1)} className="absolute top-[calc(0.75rem+var(--safe-top))] left-5 w-10 h-10 rounded-full glass flex items-center justify-center no-tap-highlight"><ChevronLeft size={22} /></button>
        <div className="absolute bottom-0 left-0 right-0 p-6">
          <div className="inline-flex items-center gap-2 bg-white/20 backdrop-blur-sm rounded-full px-3 py-1 mb-2">
            <FlaskConical size={14} className="text-white" />
            <span className="text-white text-xs font-bold uppercase tracking-wide">Research Program</span>
          </div>
          <h1 className="text-3xl font-extrabold tracking-tight text-white drop-shadow-lg">{program.title}</h1>
          {program.description && <p className="text-white/85 text-sm mt-2 max-w-sm leading-relaxed">{program.description}</p>}
        </div>
      </div>

      <div className="px-5 mt-5">
        <div className="bg-card rounded-3xl p-4 shadow-soft flex items-center gap-3">
          <div className="w-11 h-11 rounded-2xl flex items-center justify-center" style={{ background: `${accent}18` }}><Award size={20} style={{ color: accent }} /></div>
          <div className="flex-1">
            <p className="text-xs text-muted-foreground">{isProgramFree(program) ? 'Access' : 'Pricing'}</p>
            <p className="font-bold text-sm">{priceLabel(program)}{program.free_trial ? ` · ${program.trial_days || 14}-day free trial` : ''}</p>
          </div>
        </div>
      </div>

      {benefits.length > 0 && (
        <Section title="Benefits" icon={Check}>
          <ul className="space-y-2">
            {benefits.map((b, i) => (
              <li key={i} className="flex items-start gap-2 text-sm"><Check size={16} className="text-primary flex-shrink-0 mt-0.5" /><span>{b}</span></li>
            ))}
          </ul>
        </Section>
      )}

      {requirements.length > 0 && (
        <Section title="Requirements" icon={Users}>
          <ul className="space-y-2">
            {requirements.map((b, i) => <li key={i} className="flex items-start gap-2 text-sm"><span className="w-1.5 h-1.5 rounded-full bg-muted-foreground mt-2 flex-shrink-0" /><span>{b}</span></li>)}
          </ul>
        </Section>
      )}

      {timeline.length > 0 && (
        <Section title="Timeline" icon={Clock}>
          <ol className="space-y-3">
            {timeline.map((b, i) => (
              <li key={i} className="flex gap-3 text-sm">
                <span className="w-6 h-6 rounded-full bg-primary/15 text-primary font-bold text-xs flex items-center justify-center flex-shrink-0">{i + 1}</span>
                <span className="pt-0.5">{b}</span>
              </li>
            ))}
          </ol>
        </Section>
      )}

      {mentors.length > 0 && (
        <Section title="Mentors" icon={Users}>
          <div className="space-y-2">
            {mentors.map((b, i) => <div key={i} className="bg-card rounded-xl p-3 text-sm font-medium">{b}</div>)}
          </div>
        </Section>
      )}

      {outcomes.length > 0 && (
        <Section title="Outcomes" icon={Award}>
          <ul className="space-y-2">
            {outcomes.map((b, i) => <li key={i} className="flex items-start gap-2 text-sm"><Check size={16} className="text-primary flex-shrink-0 mt-0.5" /><span>{b}</span></li>)}
          </ul>
        </Section>
      )}

      <div className="px-5 mt-8">
        <button onClick={() => navigate(`/program/${program.id}`)} className="w-full flex items-center justify-center gap-2 rounded-2xl py-4 text-sm font-bold text-white no-tap-highlight shadow-card" style={{ background: accent }}>
          {ctaLabel(program)} <ArrowRight size={16} />
        </button>
      </div>
    </div>
  );
}

function Section({ title, icon: Icon, children }) {
  return (
    <div className="px-5 mt-6">
      <div className="flex items-center gap-2 mb-3">
        <Icon size={16} className="text-primary" />
        <h2 className="text-sm font-bold text-foreground/80 uppercase tracking-wide">{title}</h2>
        <div className="flex-1 h-px bg-border/40" />
      </div>
      {children}
    </div>
  );
}
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Clock, ChevronRight, List, Grid3x3, Calendar as CalendarIcon, Globe } from 'lucide-react';
import { useUserProgress } from '@/lib/UserProgressContext';
import { programColor } from '@/lib/achievements';
import { useTimezone, convertLesson, TIMEZONES, timezoneLabel, detectTimezone } from '@/lib/timezone';
import IOSSelect from '@/components/IOSSelect';

const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
const DAY_SHORT = { Monday: 'Mon', Tuesday: 'Tue', Wednesday: 'Wed', Thursday: 'Thu', Friday: 'Fri', Saturday: 'Sat', Sunday: 'Sun' };

const PROGRAM_FLAGS = {
  English: '🇬🇧', Italian: '🇮🇹', French: '🇫🇷', Spanish: '🇪🇸', Portuguese: '🇵🇹', Korean: '🇰🇷', German: '🇩🇪', Chinese: '🇨🇳', Russian: '🇷🇺', Science: '🔬', Research: '🔬',
};

export default function Schedule() {
  const navigate = useNavigate();
  const { joinedGroups } = useUserProgress();
  const { tz, setTz } = useTimezone();
  const [view, setView] = useState('list');
  const [selectedDay, setSelectedDay] = useState(null);
  const [opening, setOpening] = useState(null);

  const lessons = (joinedGroups || []).map((g) => {
    const conv = convertLesson(g.day_of_week || 'Monday', g.time || '18:00', tz);
    return {
      id: g.id,
      title: g.name,
      day_of_week: conv.day,
      time: conv.time,
      program_name: g.program_title || '',
      teacher: g.teacher || '',
      flag_emoji: g.flag_emoji || PROGRAM_FLAGS[g.program_title] || '📚',
      color: g.color || programColor(g.program_title),
      chatId: g.chatId,
    };
  });

  let today;
  try {
    today = new Intl.DateTimeFormat('en-US', { timeZone: tz, weekday: 'long' }).format(new Date());
  } catch (e) {
    today = DAYS[(new Date().getDay() + 6) % 7];
  }

  const openChat = (lesson) => {
    if (!lesson.chatId) return;
    setOpening(lesson.id);
    navigate(`/chat/${lesson.chatId}`);
  };

  const sortedLessons = [...lessons].sort((a, b) => {
    const dayDiff = DAYS.indexOf(a.day_of_week) - DAYS.indexOf(b.day_of_week);
    if (dayDiff !== 0) return dayDiff;
    return (a.time || '').localeCompare(b.time || '');
  });

  const lessonsByDay = DAYS.map((day) => ({ day, lessons: sortedLessons.filter((l) => l.day_of_week === day) }));
  const displayDays = selectedDay ? lessonsByDay.filter((d) => d.day === selectedDay) : lessonsByDay;
  const timeSlots = [...new Set(lessons.map((l) => l.time))].sort();

  return (
    <div className="min-h-screen pb-28">
      <header className="px-5 pt-[calc(0.75rem+var(--safe-top))] pb-2">
        <h1 className="text-3xl font-extrabold tracking-tight">Schedule</h1>
        <p className="text-muted-foreground text-sm mt-1">Your weekly lesson calendar</p>
      </header>

      <div className="px-5 mt-4">
        <div className="bg-card rounded-2xl p-3.5 shadow-soft">
          <div className="flex items-center gap-2">
            <Globe size={16} className="text-primary flex-shrink-0" />
            <div className="flex-1 min-w-0">
              <p className="text-[10px] text-muted-foreground uppercase tracking-wide">Your Time Zone</p>
              <p className="text-xs font-bold truncate">🕒 {timezoneLabel(tz)}</p>
            </div>
            <IOSSelect
              value={tz}
              onChange={setTz}
              placeholder="Time zone"
              className="max-w-[150px] text-xs"
              options={[
                ...(!TIMEZONES.find((t) => t.id === tz) ? [{ value: tz, label: timezoneLabel(tz) }] : []),
                ...TIMEZONES.map((t) => ({ value: t.id, label: t.label })),
              ]}
            />
          </div>
          <button onClick={() => setTz(detectTimezone())} className="mt-2 text-[10px] font-bold text-primary no-tap-highlight">
            📍 Auto-detect my time zone
          </button>
        </div>
      </div>

      <div className="px-5 mt-4 flex items-center gap-2">
        <div className="flex-1 flex gap-1 overflow-x-auto scrollbar-hide">
          {DAYS.map((day) => {
            const count = lessonsByDay.find((d) => d.day === day)?.lessons.length || 0;
            const isToday = day === today;
            const isSelected = selectedDay === day;
            return (
              <button
                key={day}
                onClick={() => setSelectedDay(isSelected ? null : day)}
                className={`flex-shrink-0 flex flex-col items-center gap-1 px-3 py-2.5 rounded-2xl transition-all no-tap-highlight min-w-[60px] ${
                  isSelected ? 'bg-primary text-primary-foreground shadow-lg shadow-primary/25' : isToday ? 'bg-secondary/15 text-secondary' : 'bg-card text-foreground/70'
                }`}
              >
                <span className="text-xs font-bold">{DAY_SHORT[day]}</span>
                {count > 0 && (
                  <span className={`text-[10px] font-semibold ${isSelected ? 'text-white/80' : 'text-muted-foreground'}`}>
                    {count} {count === 1 ? 'lesson' : 'lessons'}
                  </span>
                )}
                {isToday && !isSelected && <div className="w-1 h-1 rounded-full bg-secondary" />}
              </button>
            );
          })}
        </div>
      </div>

      <div className="px-5 mt-4 flex items-center justify-between">
        <div className="flex gap-1 bg-card rounded-xl p-1">
          <button onClick={() => setView('list')} className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors no-tap-highlight ${view === 'list' ? 'bg-primary text-primary-foreground' : 'text-muted-foreground'}`}>
            <List size={14} /> List
          </button>
          <button onClick={() => setView('grid')} className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors no-tap-highlight ${view === 'grid' ? 'bg-primary text-primary-foreground' : 'text-muted-foreground'}`}>
            <Grid3x3 size={14} /> Grid
          </button>
        </div>
        {selectedDay && (
          <button onClick={() => setSelectedDay(null)} className="text-xs font-semibold text-primary no-tap-highlight">
            All days
          </button>
        )}
      </div>

      <div className="px-5 mt-4">
        {lessons.length === 0 ? (
          <div className="bg-card rounded-3xl p-10 text-center shadow-soft">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="w-20 h-20 rounded-full bg-gradient-to-br from-primary/10 to-secondary/10 flex items-center justify-center mx-auto mb-4"
            >
              <CalendarIcon size={34} className="text-primary/70" />
            </motion.div>
            <p className="text-base font-bold text-foreground/80">Your calendar is empty.</p>
            <p className="text-sm text-muted-foreground mt-1.5 max-w-xs mx-auto">Join a program to schedule your first lesson!</p>
          </div>
        ) : view === 'list' ? (
          <div className="space-y-5">
            {displayDays.map((dayGroup) => (
              dayGroup.lessons.length > 0 && (
                <div key={dayGroup.day}>
                  <div className="flex items-center gap-2 mb-2.5">
                    <h2 className={`text-sm font-bold uppercase tracking-wide ${dayGroup.day === today ? 'text-secondary' : 'text-foreground/60'}`}>
                      {dayGroup.day}
                    </h2>
                    {dayGroup.day === today && (
                      <span className="text-[10px] font-bold bg-secondary/15 text-secondary rounded-full px-2 py-0.5">TODAY</span>
                    )}
                    <div className="flex-1 h-px bg-border/40" />
                  </div>
                  <div className="space-y-2.5">
                    {dayGroup.lessons.map((lesson) => (
                      <motion.button
                        key={lesson.id}
                        initial={{ opacity: 0, y: 12 }}
                        animate={{ opacity: 1, y: 0 }}
                        onClick={() => openChat(lesson)}
                        disabled={opening === lesson.id || !lesson.chatId}
                        className="w-full text-left bg-card rounded-2xl p-4 shadow-soft flex items-center gap-3 no-tap-highlight disabled:opacity-50"
                      >
                        <div className="flex flex-col items-center justify-center w-14 h-14 rounded-2xl flex-shrink-0" style={{ background: `${lesson.color}18` }}>
                          <span className="text-xl">{lesson.flag_emoji}</span>
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-bold text-sm truncate">{lesson.title}</p>
                          <div className="flex items-center gap-2 mt-1 text-xs text-muted-foreground">
                            <span className="flex items-center gap-1"><Clock size={12} /> {lesson.time}</span>
                          </div>
                          {lesson.program_name && <p className="text-[10px] text-muted-foreground/70 mt-0.5">{lesson.program_name}</p>}
                        </div>
                        <ChevronRight size={18} className="text-muted-foreground/50 flex-shrink-0" />
                      </motion.button>
                    ))}
                  </div>
                </div>
              )
            ))}
          </div>
        ) : (
          <div className="overflow-x-auto -mx-5 px-5 scrollbar-hide">
            <div className="min-w-[680px]">
              <div className="grid gap-1" style={{ gridTemplateColumns: '52px repeat(7, 1fr)' }}>
                <div className="py-2" />
                {DAYS.map((d) => (
                  <div key={d} className={`text-center text-[10px] font-bold py-2 ${d === today ? 'text-secondary' : 'text-foreground/60'}`}>
                    {DAY_SHORT[d]}
                  </div>
                ))}
                {timeSlots.map((t) => (
                  <div key={t} className="contents">
                    <div className="text-[10px] text-muted-foreground text-right pr-1 py-1 self-center">{t}</div>
                    {DAYS.map((d) => {
                      const cell = lessonsByDay.find((x) => x.day === d).lessons.filter((l) => l.time === t);
                      return (
                        <div key={d} className="min-h-[48px] bg-card/50 rounded-lg p-1 flex flex-col gap-1">
                          {cell.map((l) => (
                            <button
                              key={l.id}
                              onClick={() => openChat(l)}
                              disabled={!l.chatId}
                              className="text-left rounded-md px-1.5 py-1 text-[10px] font-semibold text-white leading-tight truncate no-tap-highlight disabled:opacity-50"
                              style={{ background: l.color }}
                              title={`${l.title} • ${l.time} • ${l.day_of_week}`}
                            >
                              {l.title}
                            </button>
                          ))}
                        </div>
                      );
                    })}
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ChevronLeft, Camera, Loader2, GraduationCap, Check } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import IOSSelect from '@/components/IOSSelect';

const LEVELS = ['A1', 'A2', 'B1', 'B2', 'C1', 'C2', 'Native'];
const TIMEZONES = ['UTC', 'GMT+1', 'GMT+2', 'GMT+3', 'GMT-5 (EST)', 'GMT-8 (PST)', 'GMT+5:30', 'GMT+8', 'GMT+9'];

export default function TeacherApplication() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [form, setForm] = useState({ languages: '', proficiency: 'B2', experience: '', about: '', availability: '', timezone: 'UTC' });
  const [photo, setPhoto] = useState(null);
  const [photoPreview, setPhotoPreview] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    base44.auth.me().then((u) => {
      setUser(u);
      if (u?.full_name) setForm((f) => ({ ...f, languages: f.languages }));
    }).catch(() => navigate('/home'));
  }, []);

  const pickPhoto = (e) => {
    const f = e.target.files?.[0];
    if (!f) return;
    setPhoto(f);
    setPhotoPreview(URL.createObjectURL(f));
  };

  const submit = async () => {
    if (!form.languages.trim() || !form.experience.trim()) return;
    setSubmitting(true);
    try {
      let photo_url = '';
      if (photo) {
        const res = await base44.integrations.Core.UploadFile({ file: photo });
        photo_url = res.file_url;
      }
      await base44.entities.TeacherApplication.create({
        full_name: user?.full_name || '',
        email: user?.email || '',
        photo_url,
        languages: form.languages.trim(),
        proficiency: form.proficiency,
        experience: form.experience.trim(),
        about: form.about.trim(),
        availability: form.availability.trim(),
        timezone: form.timezone,
        status: 'pending',
      });
      await base44.auth.updateMe({ teacher_status: 'pending' });
      navigate('/home');
    } catch (err) {
      console.error(err);
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen pb-28">
      <header className="px-5 pt-[calc(0.75rem+var(--safe-top))] pb-3 flex items-center gap-3">
        <button onClick={() => navigate(-1)} className="w-10 h-10 rounded-full bg-card flex items-center justify-center no-tap-highlight">
          <ChevronLeft size={22} />
        </button>
        <div>
          <h1 className="text-2xl font-extrabold tracking-tight">Teacher Application</h1>
          <p className="text-muted-foreground text-xs">Tell us about your teaching experience</p>
        </div>
      </header>

      <div className="px-5 mt-3">
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="bg-gradient-to-br from-primary/10 to-secondary/10 rounded-3xl p-4 flex items-center gap-3 mb-5">
          <div className="w-12 h-12 rounded-2xl bg-primary flex items-center justify-center text-white"><GraduationCap size={22} /></div>
          <p className="text-xs text-muted-foreground leading-relaxed">Your application will be reviewed by UNIVOX. Once approved, you'll get access to the Teacher Panel.</p>
        </motion.div>

        {/* Photo */}
        <div className="flex flex-col items-center mb-6">
          <label className="relative w-24 h-24 rounded-full bg-card flex items-center justify-center overflow-hidden cursor-pointer no-tap-highlight shadow-soft">
            {photoPreview ? <img src={photoPreview} alt="" className="w-full h-full object-cover" /> : <Camera size={26} className="text-muted-foreground" />}
            <input type="file" accept="image/*" className="hidden" onChange={pickPhoto} />
          </label>
          <p className="text-xs text-muted-foreground mt-2">Profile photo</p>
        </div>

        <Field label="Languages you teach">
          <input value={form.languages} onChange={(e) => setForm({ ...form, languages: e.target.value })} placeholder="e.g. English, Spanish" className="input" />
        </Field>

        <Field label="Proficiency">
          <div className="flex gap-1.5 flex-wrap">
            {LEVELS.map((l) => (
              <button key={l} onClick={() => setForm({ ...form, proficiency: l })} className={`px-3 py-1.5 rounded-full text-xs font-bold no-tap-highlight ${form.proficiency === l ? 'bg-primary text-primary-foreground' : 'bg-card text-muted-foreground'}`}>{l}</button>
            ))}
          </div>
        </Field>

        <Field label="Teaching experience">
          <textarea value={form.experience} onChange={(e) => setForm({ ...form, experience: e.target.value })} placeholder="e.g. 3 years teaching teens online" rows={2} className="input resize-none" />
        </Field>

        <Field label="About you">
          <textarea value={form.about} onChange={(e) => setForm({ ...form, about: e.target.value })} placeholder="A short bio for your students" rows={3} className="input resize-none" />
        </Field>

        <Field label="Available days & time">
          <input value={form.availability} onChange={(e) => setForm({ ...form, availability: e.target.value })} placeholder="e.g. Mon/Wed 16:00-18:00" className="input" />
        </Field>

        <Field label="Time zone">
          <IOSSelect value={form.timezone} onChange={(v) => setForm({ ...form, timezone: v })} options={TIMEZONES.map((t) => ({ value: t, label: t }))} className="input" />
        </Field>

        <button onClick={submit} disabled={submitting || !form.languages.trim() || !form.experience.trim()} className="mt-6 w-full bg-primary text-primary-foreground rounded-2xl py-4 font-bold text-sm flex items-center justify-center gap-2 disabled:opacity-40 no-tap-highlight">
          {submitting ? <><Loader2 size={18} className="animate-spin" /> Submitting...</> : <><Check size={18} /> Submit Application</>}
        </button>
      </div>

      <style>{`.input{width:100%;background:hsl(var(--card));border-radius:1rem;padding:0.75rem 1rem;font-size:0.875rem;font-weight:500;outline:none;border:1px solid transparent}.input:focus{border-color:hsl(var(--primary)/0.3)}`}</style>
    </div>
  );
}

function Field({ label, children }) {
  return (
    <div className="mb-4">
      <label className="text-xs font-bold text-foreground/70 uppercase tracking-wide block mb-2">{label}</label>
      {children}
    </div>
  );
}
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ChevronLeft, GraduationCap, Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { isApprovedTeacher, isOwner } from '@/lib/roles';
import ManagedGroupCard from '@/components/teacher/ManagedGroupCard';

export default function TeacherPanel() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [groups, setGroups] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    base44.auth.me().then((u) => {
      setUser(u);
      if (!isApprovedTeacher(u) && !isOwner(u)) navigate('/home');
    }).catch(() => navigate('/home'));
  }, []);

  useEffect(() => {
    if (!user) return;
    base44.entities.Group.filter({ assigned_teacher_id: user.id })
      .then((g) => setGroups(g || []))
      .catch(() => setGroups([]))
      .finally(() => setLoading(false));
  }, [user]);

  if (!user) return null;

  return (
    <div className="min-h-screen pb-28">
      <header className="px-5 pt-[calc(0.75rem+var(--safe-top))] pb-3 flex items-center gap-3">
        <button onClick={() => navigate('/profile')} className="w-10 h-10 rounded-full bg-card flex items-center justify-center no-tap-highlight"><ChevronLeft size={22} /></button>
        <div>
          <h1 className="text-2xl font-extrabold tracking-tight flex items-center gap-2"><GraduationCap size={20} className="text-primary" /> Teacher Panel</h1>
          <p className="text-muted-foreground text-xs">Manage your assigned groups</p>
        </div>
      </header>

      <div className="px-5 mt-4">
        {loading ? (
          [1, 2].map((i) => <div key={i} className="h-28 skeleton rounded-3xl mb-3" />)
        ) : groups.length === 0 ? (
          <div className="text-center py-16">
            <div className="w-16 h-16 rounded-3xl bg-card flex items-center justify-center mx-auto mb-4"><GraduationCap size={26} className="text-muted-foreground/50" /></div>
            <p className="font-semibold text-foreground/80">No groups assigned yet</p>
            <p className="text-sm text-muted-foreground mt-1">Wait for the Owner to assign you to a group.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {groups.map((g, i) => (
              <motion.div key={g.id} initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.06 }}>
                <ManagedGroupCard group={g} />
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Camera, MapPin, X, Plus, Plane, Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { programs as programCfg } from '@/components/program/programConfig';
import SnapStory from '@/components/vacation/SnapStory';
import PullToRefresh from '@/components/PullToRefresh';

const FLAGS = ['🇪🇸', '🇫🇷', '🇬🇧', '🇮🇹', '🇵🇹', '🇨🇳', '🇯🇵', '🇷🇺', '🇧🇷', '🇲🇽', '🇬🇷', '🇩🇪', '🇪🇬', '🇺🇸', '🌍'];

export default function Vacation() {
  const [snaps, setSnaps] = useState([]);
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState(null);
  const [posting, setPosting] = useState(false);
  const [viewing, setViewing] = useState(null);

  const load = () => {
    setLoading(true);
    base44.entities.VacationSnap.list('-created_date', 50)
      .then(setSnaps)
      .catch(() => {})
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
    load();
  }, []);

  return (
    <PullToRefresh onRefresh={load} className="min-h-screen pb-28">
      <header className="px-5 pt-[calc(0.75rem+var(--safe-top))] pb-3 flex items-center gap-3">
        <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-white shadow-soft">
          <Plane size={22} />
        </div>
        <div>
          <h1 className="text-2xl font-extrabold tracking-tight">Vacation</h1>
          <p className="text-muted-foreground text-xs">Where is everyone right now?</p>
        </div>
      </header>

      {/* Feed */}
      <div className="px-5 mt-2 space-y-4">
        {loading
          ? [1, 2, 3].map((i) => <div key={i} className="rounded-3xl skeleton h-80" />)
          : snaps.map((snap, i) => {
              const photos = (snap.photo_urls || '').split(',').filter(Boolean);
              const cover = photos[0];
              return (
                <motion.div
                  key={snap.id}
                  initial={{ opacity: 0, y: 16 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.06 }}
                  className="bg-card rounded-3xl overflow-hidden shadow-card"
                >
                  <div className="flex items-center gap-2 px-4 pt-3 pb-2">
                    <span className="text-2xl">{snap.author_flag || '🌍'}</span>
                    <div className="flex-1 min-w-0">
                      <p className="font-bold text-sm truncate">{snap.author_name || 'Traveler'}</p>
                      <p className="text-xs text-muted-foreground flex items-center gap-1 truncate"><MapPin size={11} /> {snap.location}</p>
                    </div>
                  </div>
                  {photos.length > 0 && (
                    <div className={`grid gap-1 px-3 pb-3 ${photos.length === 1 ? 'grid-cols-1' : photos.length === 2 ? 'grid-cols-2' : 'grid-cols-3'}`}>
                      {photos.map((src, pi) => (
                        <button
                          key={pi}
                          onClick={() => setViewing({ ...snap, _start: pi })}
                          className="relative block overflow-hidden rounded-xl no-tap-highlight"
                        >
                          <img
                            src={src}
                            alt=""
                            className={`w-full object-cover ${photos.length === 1 ? 'aspect-square' : 'aspect-square'}`}
                          />
                          {photos.length > 1 && pi === photos.length - 1 && (
                            <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                              <span className="text-white text-sm font-bold">+{photos.length - 1}</span>
                            </div>
                          )}
                        </button>
                      ))}
                    </div>
                  )}
                  {snap.caption && (
                    <p className="px-4 py-3 text-sm font-medium leading-relaxed">{snap.caption}</p>
                  )}
                </motion.div>
              );
            })}
      </div>

      {!loading && snaps.length === 0 && (
        <div className="text-center py-20 px-6">
          <div className="w-16 h-16 rounded-3xl bg-card flex items-center justify-center mx-auto mb-4">
            <Plane size={28} className="text-muted-foreground/50" />
          </div>
          <p className="font-semibold text-foreground/80">No snaps yet</p>
          <p className="text-sm text-muted-foreground mt-1">Share where you are with the world ✈️</p>
        </div>
      )}

      {/* Floating post button */}
      <button
        onClick={() => setPosting(true)}
        className="fixed bottom-24 right-5 w-14 h-14 rounded-full bg-primary text-primary-foreground flex items-center justify-center shadow-float no-tap-highlight"
        aria-label="Post a snap"
      >
        <Camera size={24} />
      </button>

      <AnimatePresence>
        {posting && (
          <PostSheet
            user={user}
            onClose={() => setPosting(false)}
            onPosted={() => { setPosting(false); load(); }}
          />
        )}
        {viewing && <SnapStory snap={viewing} onClose={() => setViewing(null)} />}
      </AnimatePresence>
    </PullToRefresh>
  );
}

function PostSheet({ user, onClose, onPosted }) {
  const [files, setFiles] = useState([]);
  const [previews, setPreviews] = useState([]);
  const [location, setLocation] = useState('');
  const [caption, setCaption] = useState('');
  const [flag, setFlag] = useState('🌍');
  const [submitting, setSubmitting] = useState(false);

  const pickFiles = (e) => {
    const selected = Array.from(e.target.files || []);
    if (!selected.length) return;
    setFiles((prev) => [...prev, ...selected]);
    setPreviews((prev) => [...prev, ...selected.map((f) => URL.createObjectURL(f))]);
    e.target.value = '';
  };

  const removePreview = (i) => {
    setPreviews((prev) => prev.filter((_, idx) => idx !== i));
    setFiles((prev) => prev.filter((_, idx) => idx !== i));
  };

  const submit = async () => {
    if (!files.length || !location.trim()) return;
    setSubmitting(true);
    try {
      const urls = [];
      for (const f of files) {
        const { file_url } = await base44.integrations.Core.UploadFile({ file: f });
        urls.push(file_url);
      }
      await base44.entities.VacationSnap.create({
        author_name: user?.full_name || 'Traveler',
        author_flag: flag,
        location: location.trim(),
        caption: caption.trim(),
        photo_urls: urls.join(','),
      });
      onPosted();
    } catch (err) {
      console.error(err);
      setSubmitting(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[100] flex items-end justify-center"
      style={{ background: 'rgba(0,0,0,0.5)' }}
      onClick={onClose}
    >
      <motion.div
        initial={{ y: '100%' }}
        animate={{ y: 0 }}
        exit={{ y: '100%' }}
        transition={{ type: 'spring', damping: 28, stiffness: 300 }}
        onClick={(e) => e.stopPropagation()}
        className="bg-background w-full max-w-md rounded-t-[2rem] p-5 pb-8 max-h-[90vh] overflow-y-auto"
      >
        <div className="w-10 h-1 rounded-full bg-border mx-auto mb-4" />
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-extrabold">New Snap</h2>
          <button onClick={onClose} className="w-9 h-9 rounded-full bg-card flex items-center justify-center no-tap-highlight">
            <X size={18} />
          </button>
        </div>

        {/* Photo picker + previews */}
        <div className="flex gap-2 overflow-x-auto scrollbar-hide pb-2">
          <button
            onClick={() => document.getElementById('snap-file')?.click()}
            className="w-24 h-24 flex-shrink-0 rounded-2xl border-2 border-dashed border-border flex flex-col items-center justify-center text-muted-foreground no-tap-highlight"
          >
            <Plus size={22} />
            <span className="text-[10px] font-medium mt-1">Add photo</span>
          </button>
          {previews.map((src, i) => (
            <div key={i} className="relative w-24 h-24 flex-shrink-0 rounded-2xl overflow-hidden">
              <img src={src} alt="" className="w-full h-full object-cover" />
              <button
                onClick={() => removePreview(i)}
                className="absolute top-1 right-1 w-6 h-6 rounded-full bg-black/60 flex items-center justify-center no-tap-highlight"
              >
                <X size={12} className="text-white" />
              </button>
            </div>
          ))}
        </div>
        <input id="snap-file" type="file" accept="image/*" multiple className="hidden" onChange={pickFiles} />

        {/* Flag picker */}
        <div className="mt-4">
          <label className="text-xs font-bold text-foreground/70 uppercase tracking-wide">Flag</label>
          <div className="flex gap-1.5 flex-wrap mt-2">
            {FLAGS.map((f) => (
              <button
                key={f}
                onClick={() => setFlag(f)}
                className={`w-10 h-10 rounded-xl flex items-center justify-center text-xl no-tap-highlight transition-all ${flag === f ? 'bg-primary/15 ring-2 ring-primary' : 'bg-card'}`}
              >
                {f}
              </button>
            ))}
          </div>
        </div>

        {/* Location */}
        <div className="mt-4">
          <label className="text-xs font-bold text-foreground/70 uppercase tracking-wide">Where are you?</label>
          <div className="relative mt-2">
            <MapPin size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-primary" />
            <input
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              placeholder="e.g. Barcelona, Spain"
              className="w-full bg-card rounded-2xl pl-10 pr-4 py-3 text-sm font-medium outline-none border border-transparent focus:border-primary/30 transition-colors"
            />
          </div>
        </div>

        {/* Caption */}
        <div className="mt-4">
          <label className="text-xs font-bold text-foreground/70 uppercase tracking-wide">Caption</label>
          <textarea
            value={caption}
            onChange={(e) => setCaption(e.target.value)}
            placeholder="What are you up to?"
            rows={2}
            className="w-full bg-card rounded-2xl px-4 py-3 text-sm font-medium outline-none border border-transparent focus:border-primary/30 transition-colors resize-none mt-2"
          />
        </div>

        <button
          onClick={submit}
          disabled={!files.length || !location.trim() || submitting}
          className="mt-5 w-full bg-primary text-primary-foreground rounded-2xl py-3.5 font-bold text-sm flex items-center justify-center gap-2 disabled:opacity-40 no-tap-highlight"
        >
          {submitting ? <><Loader2 size={16} className="animate-spin" /> Posting...</> : <><Plane size={16} /> Post Snap</>}
        </button>
      </motion.div>
    </motion.div>
  );
}
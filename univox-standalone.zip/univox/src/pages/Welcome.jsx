import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';
import NeonBackground from '@/components/NeonBackground';

const pixelColors = ['#1E4DFF', '#FF6FAE', '#FFD84D', '#FF8A3D', '#1E4DFF', '#FF6FAE', '#FFD84D', '#FF8A3D', '#1E4DFF', '#FF6FAE', '#FFD84D', '#FF8A3D', '#1E4DFF', '#FF6FAE', '#FFD84D', '#FF8A3D', '#1E4DFF', '#FF6FAE', '#FFD84D', '#FF8A3D', '#1E4DFF', '#FF6FAE', '#FFD84D', '#FF8A3D'];

export default function Welcome() {
  return (
    <div className="min-h-screen bg-white flex flex-col relative overflow-hidden">
      {/* Animated neon background (crossfading frames) */}
      <NeonBackground />

      {/* Pixel color bars top & bottom */}
      <div className="absolute top-0 left-0 right-0 flex gap-0 h-3 z-10">
        {pixelColors.map((c, i) => (
          <div key={i} className="flex-1" style={{ background: c }} />
        ))}
      </div>
      <div className="absolute bottom-0 left-0 right-0 flex gap-0 h-3 z-10">
        {pixelColors.slice().reverse().map((c, i) => (
          <div key={i} className="flex-1" style={{ background: c }} />
        ))}
      </div>

      {/* Content overlay */}
      <div className="relative z-20 flex-1 flex flex-col justify-end px-7 pb-12 pt-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6, duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
        >
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.8 }}
            className="text-xs font-bold uppercase tracking-[0.3em] text-white/80 mb-3"
          >
            Welcome to
          </motion.p>
          <h1 className="text-6xl font-extrabold tracking-tight text-white leading-none drop-shadow-2xl">
            UNI<span className="text-gradient-warm">VOX</span>
          </h1>
          <p className="text-lg text-white/90 mt-3 font-medium tracking-wide drop-shadow-lg">
            Connect. Learn. Explore.
          </p>
          <p className="text-sm text-white/70 mt-4 leading-relaxed max-w-xs drop-shadow">
            Join a global community of teenage learners. Study together, attend live lessons, and earn certificates from anywhere in the world.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1, duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
          className="mt-8 space-y-4"
        >
          <Link
            to="/register"
            className="w-full flex items-center justify-center gap-2 bg-white text-foreground rounded-2xl py-4 font-bold text-base shadow-2xl hover:scale-[1.02] transition-transform no-tap-highlight"
          >
            Get Started
            <ArrowRight size={18} strokeWidth={2.5} />
          </Link>
          <p className="text-sm text-center text-white/80 drop-shadow">
            Already have an account?{' '}
            <Link to="/login" className="text-white font-bold underline underline-offset-2">Sign In</Link>
          </p>
        </motion.div>
      </div>
    </div>
  );
}
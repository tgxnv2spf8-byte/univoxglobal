-- UNIVOX — Supabase schema
-- Run this once in your Supabase project's SQL editor (Database > SQL Editor).
-- Replaces the Base44-hosted entities/auth/storage this app used to depend on.
--
-- Notes:
--   * Every table has: id, created_date, updated_date, created_by_id, created_by_name
--     to match the fields the app already reads/writes (see src/api/base44Client.js).
--   * RLS policies below are translated from the original base44/entities/*.jsonc
--     access rules as closely as possible. A few entities (Badge, Certificate,
--     Lesson, TimelineEvent) had no explicit rules in the source project — sensible
--     defaults are used for those; review them for your actual access requirements.

create extension if not exists "pgcrypto";

-- ---------------------------------------------------------------------------
-- Helper: is the given user an admin/owner?
-- ---------------------------------------------------------------------------
create or replace function public.is_admin(uid uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.profiles p
    where p.id = uid
      and (p.role = 'admin' or 'owner' = any(p.roles) or 'admin' = any(p.roles))
  );
$$;

-- ---------------------------------------------------------------------------
-- profiles  (extends auth.users — this is the "User" entity)
-- ---------------------------------------------------------------------------
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  full_name text,
  avatar_url text,
  age int,
  country text,
  role text default 'user' check (role in ('admin', 'user')),
  roles text[] default array['student'],
  teacher_status text default 'none' check (teacher_status in ('none', 'pending', 'approved', 'rejected')),
  language_level text,
  target_language text,
  timezone text,
  onboarding_completed boolean default false,
  created_date timestamptz default now(),
  updated_date timestamptz default now()
);

alter table public.profiles enable row level security;

create policy "profiles are readable by any authenticated user"
  on public.profiles for select
  using (auth.role() = 'authenticated');

create policy "users can update their own profile"
  on public.profiles for update
  using (auth.uid() = id or public.is_admin(auth.uid()));

create policy "users can insert their own profile"
  on public.profiles for insert
  with check (auth.uid() = id);

-- Auto-create a profile row whenever a new auth user signs up (covers Google OAuth too)
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, email, full_name)
  values (new.id, new.email, new.raw_user_meta_data->>'full_name')
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ---------------------------------------------------------------------------
-- Generic columns shared by every content table below:
--   id uuid pk, created_date, updated_date, created_by_id, created_by_name
-- ---------------------------------------------------------------------------

-- announcements
create table if not exists public.announcements (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  short_description text,
  full_description text,
  cover_image_url text,
  category text default 'info' check (category in ('info','event','research','speaking_club','new_program','update')),
  language text default 'en',
  teacher text,
  event_date text,
  location_or_link text,
  join_button_label text default 'Join',
  join_target_group_id uuid,
  status text not null default 'draft' check (status in ('draft','published','archived','scheduled')),
  featured boolean default false,
  scheduled_for text,
  published_date text,
  views numeric default 0,
  joins numeric default 0,
  active_participants numeric default 0,
  group_id uuid,
  description text,
  type text,
  date text,
  created_by_id uuid references auth.users(id),
  created_by_name text,
  created_date timestamptz default now(),
  updated_date timestamptz default now()
);
alter table public.announcements enable row level security;
create policy "announcements insert admin only" on public.announcements for insert with check (public.is_admin(auth.uid()));
create policy "announcements select" on public.announcements for select using (
  status = 'published'
  or (status in ('draft','archived','scheduled') and created_by_id = auth.uid())
  or public.is_admin(auth.uid())
);
create policy "announcements update" on public.announcements for update using (
  created_by_id = auth.uid() or public.is_admin(auth.uid())
);
create policy "announcements delete admin only" on public.announcements for delete using (public.is_admin(auth.uid()));

-- app_notifications
create table if not exists public.app_notifications (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  type text default 'info',
  timestamp text,
  read boolean default false,
  created_by_id uuid references auth.users(id),
  created_by_name text,
  created_date timestamptz default now(),
  updated_date timestamptz default now()
);
alter table public.app_notifications enable row level security;
create policy "app_notifications admin only" on public.app_notifications for all using (public.is_admin(auth.uid())) with check (public.is_admin(auth.uid()));

-- applications
create table if not exists public.applications (
  id uuid primary key default gen_random_uuid(),
  group_name text not null,
  teacher text,
  status text default 'pending' check (status in ('pending','approved','rejected')),
  program_name text,
  day_of_week text,
  time text,
  created_by_id uuid references auth.users(id),
  created_by_name text,
  created_date timestamptz default now(),
  updated_date timestamptz default now()
);
alter table public.applications enable row level security;
create policy "applications insert own" on public.applications for insert with check (created_by_id = auth.uid());
create policy "applications select own or admin" on public.applications for select using (created_by_id = auth.uid() or public.is_admin(auth.uid()));
create policy "applications update own or admin" on public.applications for update using (created_by_id = auth.uid() or public.is_admin(auth.uid()));
create policy "applications delete own or admin" on public.applications for delete using (created_by_id = auth.uid() or public.is_admin(auth.uid()));

-- badges (no explicit rules upstream — treated as personal achievement records)
create table if not exists public.badges (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  icon_name text,
  earned_date text,
  created_by_id uuid references auth.users(id),
  created_by_name text,
  created_date timestamptz default now(),
  updated_date timestamptz default now()
);
alter table public.badges enable row level security;
create policy "badges select own or admin" on public.badges for select using (created_by_id = auth.uid() or public.is_admin(auth.uid()));
create policy "badges write own or admin" on public.badges for all using (created_by_id = auth.uid() or public.is_admin(auth.uid())) with check (created_by_id = auth.uid() or public.is_admin(auth.uid()));

-- certificates (same defaults as badges)
create table if not exists public.certificates (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  program_name text,
  date_received text,
  created_by_id uuid references auth.users(id),
  created_by_name text,
  created_date timestamptz default now(),
  updated_date timestamptz default now()
);
alter table public.certificates enable row level security;
create policy "certificates select own or admin" on public.certificates for select using (created_by_id = auth.uid() or public.is_admin(auth.uid()));
create policy "certificates write own or admin" on public.certificates for all using (created_by_id = auth.uid() or public.is_admin(auth.uid())) with check (created_by_id = auth.uid() or public.is_admin(auth.uid()));

-- chats
create table if not exists public.chats (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  chat_type text default 'group' check (chat_type in ('group','vacation','general')),
  avatar_color text,
  unread_count numeric default 0,
  last_message text,
  last_message_time text,
  teacher text,
  next_lesson_day text,
  next_lesson_time text,
  created_by_id uuid references auth.users(id),
  created_by_name text,
  created_date timestamptz default now(),
  updated_date timestamptz default now()
);
alter table public.chats enable row level security;
create policy "chats insert admin only" on public.chats for insert with check (public.is_admin(auth.uid()));
create policy "chats select" on public.chats for select using (chat_type = 'general' or public.is_admin(auth.uid()));
create policy "chats update admin only" on public.chats for update using (public.is_admin(auth.uid()));
create policy "chats delete admin only" on public.chats for delete using (public.is_admin(auth.uid()));

-- groups
create table if not exists public.groups (
  id uuid primary key default gen_random_uuid(),
  program_title text,
  name text not null,
  teacher text not null,
  day_of_week text,
  time text,
  level text default 'B1',
  member_count numeric default 0,
  capacity numeric default 20,
  meet_link text,
  assigned_teacher_id uuid,
  assigned_teacher_email text,
  flag_emoji text,
  description text,
  is_archived boolean default false,
  research_opportunities text,
  member_ids text[] default array[]::text[],
  created_by_id uuid references auth.users(id),
  created_by_name text,
  created_date timestamptz default now(),
  updated_date timestamptz default now()
);
alter table public.groups enable row level security;
create policy "groups insert admin only" on public.groups for insert with check (public.is_admin(auth.uid()));
create policy "groups select" on public.groups for select using (
  is_archived = false
  or auth.uid()::text = any(member_ids)
  or assigned_teacher_id = auth.uid()
  or public.is_admin(auth.uid())
);
create policy "groups update" on public.groups for update using (
  assigned_teacher_id = auth.uid() or public.is_admin(auth.uid())
);
create policy "groups delete admin only" on public.groups for delete using (public.is_admin(auth.uid()));

-- group_materials
create table if not exists public.group_materials (
  id uuid primary key default gen_random_uuid(),
  group_id uuid references public.groups(id) on delete cascade,
  title text not null,
  file_url text not null,
  type text default 'File',
  created_by_id uuid references auth.users(id),
  created_by_name text,
  created_date timestamptz default now(),
  updated_date timestamptz default now()
);
alter table public.group_materials enable row level security;
create policy "group_materials admin only" on public.group_materials for all using (public.is_admin(auth.uid())) with check (public.is_admin(auth.uid()));

-- journal_articles
create table if not exists public.journal_articles (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  subtitle text,
  author_name text not null,
  author_country text,
  author_flag text,
  author_age numeric,
  author_program text,
  category text not null default 'science' check (category in ('science','fashion','culture','technology','environment','art_design','languages','psychology')),
  cover_image_url text,
  content text,
  excerpt text,
  reading_time_minutes numeric default 5,
  status text default 'published' check (status in ('under_review','approved','published')),
  likes numeric default 0,
  comments_count numeric default 0,
  saves numeric default 0,
  "references" text,
  ai_summary text,
  pull_quote text,
  featured boolean default false,
  created_by_id uuid references auth.users(id),
  created_by_name text,
  created_date timestamptz default now(),
  updated_date timestamptz default now()
);
alter table public.journal_articles enable row level security;
create policy "journal_articles insert" on public.journal_articles for insert with check (auth.role() = 'authenticated');
create policy "journal_articles select" on public.journal_articles for select using (
  status = 'published' or created_by_id = auth.uid() or public.is_admin(auth.uid())
);
create policy "journal_articles update" on public.journal_articles for update using (
  created_by_id = auth.uid() or public.is_admin(auth.uid())
);
create policy "journal_articles delete" on public.journal_articles for delete using (
  created_by_id = auth.uid() or public.is_admin(auth.uid())
);

-- lessons (no explicit rules upstream — schedule info, public read)
create table if not exists public.lessons (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  teacher text,
  day_of_week text not null check (day_of_week in ('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday')),
  time text not null,
  program_name text,
  flag_emoji text,
  duration_minutes numeric default 60,
  color text,
  level text default 'B1',
  created_by_id uuid references auth.users(id),
  created_by_name text,
  created_date timestamptz default now(),
  updated_date timestamptz default now()
);
alter table public.lessons enable row level security;
create policy "lessons select all" on public.lessons for select using (true);
create policy "lessons write admin only" on public.lessons for insert with check (public.is_admin(auth.uid()));
create policy "lessons update admin only" on public.lessons for update using (public.is_admin(auth.uid()));
create policy "lessons delete admin only" on public.lessons for delete using (public.is_admin(auth.uid()));

-- programs
create table if not exists public.programs (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text not null,
  category text default 'language' check (category in ('language','science','research')),
  image_url text,
  flag_emoji text,
  accent_color text,
  teacher_id uuid,
  teacher_name text,
  is_free boolean default true,
  price numeric default 0,
  currency text default 'USD',
  free_trial boolean default false,
  trial_days numeric default 0,
  stripe_product_id text,
  stripe_price_id text,
  subscription_type text default 'monthly' check (subscription_type in ('monthly','yearly','one_time')),
  research_hero_image text,
  research_benefits text,
  research_requirements text,
  research_timeline text,
  research_mentors text,
  research_outcomes text,
  created_by_id uuid references auth.users(id),
  created_by_name text,
  created_date timestamptz default now(),
  updated_date timestamptz default now()
);
alter table public.programs enable row level security;
create policy "programs select all" on public.programs for select using (true);
create policy "programs insert admin only" on public.programs for insert with check (public.is_admin(auth.uid()));
create policy "programs update admin only" on public.programs for update using (public.is_admin(auth.uid()));
create policy "programs delete admin only" on public.programs for delete using (public.is_admin(auth.uid()));

-- teacher_applications
create table if not exists public.teacher_applications (
  id uuid primary key default gen_random_uuid(),
  full_name text not null,
  email text not null,
  photo_url text,
  languages text not null,
  proficiency text,
  experience text,
  about text,
  availability text,
  timezone text,
  status text default 'pending' check (status in ('pending','approved','rejected')),
  assigned_group_ids text,
  created_by_id uuid references auth.users(id),
  created_by_name text,
  created_date timestamptz default now(),
  updated_date timestamptz default now()
);
alter table public.teacher_applications enable row level security;
create policy "teacher_applications insert own" on public.teacher_applications for insert with check (created_by_id = auth.uid());
create policy "teacher_applications select own or admin" on public.teacher_applications for select using (created_by_id = auth.uid() or public.is_admin(auth.uid()));
create policy "teacher_applications update admin only" on public.teacher_applications for update using (public.is_admin(auth.uid()));
create policy "teacher_applications delete admin only" on public.teacher_applications for delete using (public.is_admin(auth.uid()));

-- timeline_events (no explicit rules upstream — app-wide roadmap, public read)
create table if not exists public.timeline_events (
  id uuid primary key default gen_random_uuid(),
  date text not null,
  event_description text not null,
  icon_name text,
  color text,
  created_by_id uuid references auth.users(id),
  created_by_name text,
  created_date timestamptz default now(),
  updated_date timestamptz default now()
);
alter table public.timeline_events enable row level security;
create policy "timeline_events select all" on public.timeline_events for select using (true);
create policy "timeline_events write admin only" on public.timeline_events for insert with check (public.is_admin(auth.uid()));
create policy "timeline_events update admin only" on public.timeline_events for update using (public.is_admin(auth.uid()));
create policy "timeline_events delete admin only" on public.timeline_events for delete using (public.is_admin(auth.uid()));

-- vacation_snaps
create table if not exists public.vacation_snaps (
  id uuid primary key default gen_random_uuid(),
  author_name text,
  author_flag text,
  location text not null,
  caption text,
  photo_urls text not null,
  created_by_id uuid references auth.users(id),
  created_by_name text,
  created_date timestamptz default now(),
  updated_date timestamptz default now()
);
alter table public.vacation_snaps enable row level security;
create policy "vacation_snaps select all" on public.vacation_snaps for select using (true);
create policy "vacation_snaps insert authenticated" on public.vacation_snaps for insert with check (auth.role() = 'authenticated');
create policy "vacation_snaps update own or admin" on public.vacation_snaps for update using (created_by_id = auth.uid() or public.is_admin(auth.uid()));
create policy "vacation_snaps delete own or admin" on public.vacation_snaps for delete using (created_by_id = auth.uid() or public.is_admin(auth.uid()));

-- ---------------------------------------------------------------------------
-- Storage bucket for file uploads (photos, materials, avatars, etc.)
-- ---------------------------------------------------------------------------
insert into storage.buckets (id, name, public)
values ('uploads', 'uploads', true)
on conflict (id) do nothing;

create policy "uploads are publicly readable"
  on storage.objects for select
  using (bucket_id = 'uploads');

create policy "authenticated users can upload"
  on storage.objects for insert
  with check (bucket_id = 'uploads' and auth.role() = 'authenticated');
